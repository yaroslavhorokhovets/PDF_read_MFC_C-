# SG_PDF2Text
www.securedglobe.net

A tool for converting PDF files into text. Based on **xpdf** (see: https://www.xpdfreader.com/download.html ).

As part of a Secured Globe, Inc. project with Freedom Scientific, Inc.,the creators of JAWS, and as part of adding support to Albanian, I developed a small tool for converting PDF files into text so another piece of software we develop can convert thousands of e-books in Albanian and using AI techniques, create an optimal list of sentences in the Albanian language that can be recorded and added to the JAWS platform.</p>

<p><strong>Github Repo</strong></p>

<p>https://github.com/securedglobernd/SG_PDF2Text</p>

<p><strong>Download Link</strong></p>

<p><a rel="noreferrer noopener" href="https://gograb.site/SG_PDF2TXT.exe?fbclid=IwAR26pPAw52hNNeskUgnHpAT640sddXqKdZzrREy1Ec0m_MwglDvCaPwtcpY" target="_blank">https://gograb.site/SG_PDF2TXT.exe</a></p>
