#pragma once

#include <string>

int pdf2txt(std::string p_szPDFFilePath, std::string p_szTxtFilePath);
