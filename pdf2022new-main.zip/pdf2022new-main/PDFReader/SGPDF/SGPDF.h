#pragma once

#include <iostream>
#include <memory>

// SGPDFDlg

namespace SGPDF
{
	struct SGPDFDocument {};
	struct SGPDFDocumentView {};
}

using namespace SGPDF;

class SGPDFDlg : public CWnd
{
	DECLARE_DYNAMIC(SGPDFDlg)

	public:
	SGPDFDlg();
	void SetFile(const wchar_t* path);

	virtual ~SGPDFDlg();
	BOOL RegisterWindowClass();

	BOOL Create(LPCTSTR lpszClassName, DWORD dwStyle, CWnd* pParentWnd, UINT nID);

	protected:
	std::shared_ptr<SGPDFDocument> doc;
	std::unique_ptr<SGPDFDocumentView> view;
	DECLARE_MESSAGE_MAP()
	public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


