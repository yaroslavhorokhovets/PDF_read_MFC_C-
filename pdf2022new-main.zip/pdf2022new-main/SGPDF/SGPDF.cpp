// SGPDFDlg.cpp : implementation file
//

#include "pch.h"
#include "SGPDF.h"

#undef min
#undef max

// SGPDFDlg

IMPLEMENT_DYNAMIC(SGPDFDlg, CWnd)

SGPDFDlg::SGPDFDlg()
{
	SGPDFLibrary::Module(AfxGetInstanceHandle());
	RegisterWindowClass();
}

void SGPDFDlg::SetFile(const wchar_t* path)
{
	if (view != nullptr)
	{
		view->Destroy();
	}

	int error = 0;
	doc = std::make_shared<SGPDFDocument>(path);
	doc->OpenWithPassword(nullptr, error);
	view = std::make_unique<SGPDFDocumentView>(doc);

	CRect rect;
	GetWindowRect(&rect);
	view->Create(m_hWnd, 0, 0, rect.Width(), rect.Height());
}

SGPDFDlg::~SGPDFDlg()
{
}


BOOL SGPDFDlg::RegisterWindowClass()
{
	WNDCLASS wndcls;
	HINSTANCE hInst = AfxGetInstanceHandle();

	if (!(::GetClassInfo(hInst, _T("SGPDFDlg"), &wndcls)))
	{
		wndcls.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
		wndcls.lpfnWndProc = ::DefWindowProc;
		wndcls.cbClsExtra = wndcls.cbWndExtra = 0;
		wndcls.hInstance = hInst;
		wndcls.hIcon = NULL;
		wndcls.hCursor = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
		wndcls.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
		wndcls.lpszMenuName = NULL;
		wndcls.lpszClassName = _T("SGPDFDlg");

		if (!AfxRegisterClass(&wndcls))
		{
			AfxThrowResourceException();
			return FALSE;
		}
	}

	return TRUE;
}

BOOL SGPDFDlg::Create(LPCTSTR lpszClassName, DWORD dwStyle, CWnd* pParentWnd, UINT nID)
{
	return CWnd::Create(lpszClassName, _T("SGPDFDlg"), dwStyle, CRect(0, 0, 100, 100), pParentWnd, nID, NULL);
}


BEGIN_MESSAGE_MAP(SGPDFDlg, CWnd)
	ON_WM_SIZE()
END_MESSAGE_MAP()

void SGPDFDlg::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	SetWindowPos(GetWindow(GW_CHILD), 0, 0, cx, cy, 0);
	if (view != nullptr)
	{
		view->UpdateWH(cx, cy);
	}
}
