//
//	stdafx.hpp
//	SGPDF v0.1
//
//	Copyright � 2022 Secured Globe, Inc.. All rights reserved.
//
//	Master include file for standard system include files, or project specific
//	include files that are used frequently, but are changed infrequently.
//

#pragma once

#ifndef STRICT
#define STRICT
#endif

#include "targetver.h"

// Windows headers
#include <Windows.h>
#include <WindowsX.h>
#pragma warning(push)
#pragma warning(disable: 4458)
#include <GdiPlus.h>
#pragma warning(pop)
#include <ShlwApi.h>
#include <ShlObj.h>

// C++ STL headers
#include <string>
#include <memory>
#include <functional>
#include <unordered_map>
#include <vector>
#include <map>
#include <set>
#include <mutex>
#include <thread>
//#include <deque>
//#include <list>
//#include <algorithm>
//#include <iterator>

// Visual C++ pragmas
#pragma warning(disable : 4100)
#pragma warning(disable : 4706)

// Application specific
#include "pch.h"
#include "sgpdfsdk\public\fpdfview.h"
#include "sgpdfsdk\public\fpdf_doc.h"
#include "sgpdfsdk\public\fpdf_text.h"
#include "sgpdfsdk\public\fpdf_edit.h"
#include "SGPDFDebug.hpp"
#include "SGPDFGlobals.hpp"
#include "SGPDFSupport.hpp"
#include "SGPDFGeometry.hpp"
#include "SGPDFResource.hpp"
