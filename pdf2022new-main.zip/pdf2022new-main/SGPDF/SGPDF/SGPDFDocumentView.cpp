//
//	SGPDFDocumentView.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFDocument.hpp"
#include "SGPDFDocumentView.hpp"
#include "SGPDFDocumentPane.hpp"
#include "SGPDFToolbarPane.hpp"
#include "SGPDFToolbarItem.hpp"
#include "SGPDFToolbarEdit.hpp"
#include "SGPDFToolbarText.hpp"
#include "SGPDFStatusPane.hpp"

using namespace nsSGPDF;

//
//	Constants
//

constexpr int searchTimerTick = 100;
constexpr int searchTimerTock = 2000;

static const wchar_t* kWindowClassName = L"SGPDFDocumentViewClass";

//
//	SGPDFDocumentView methods
//

nsSGPDF::SGPDFDocumentView::SGPDFDocumentView(const std::shared_ptr<SGPDFDocument>& document)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_Document = document; RegisterMessages();
}

nsSGPDF::SGPDFDocumentView::~SGPDFDocumentView(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_ToolbarPane == nullptr; m_DocumentPane = nullptr; m_StatusPane = nullptr;

	m_Document = nullptr; m_WindowHandle = nullptr; m_ParentWindow = nullptr;

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

ATOM nsSGPDF::SGPDFDocumentView::DoRegisterWindowClass(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	WNDCLASSEXW wcex; RtlSecureZeroMemory(&wcex, sizeof(wcex));

	wcex.hInstance = hModule;
	wcex.lpszClassName = kWindowClassName;
	wcex.style = 0; wcex.lpszMenuName = nullptr;
	wcex.lpfnWndProc = SGPDFDocumentView::WindowDispatch;
	wcex.hIcon = nullptr; wcex.hIconSm = nullptr; wcex.hbrBackground = nullptr;
	wcex.hCursor = SGPDFSupport::ArrowCursor();
	wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
	wcex.cbSize = sizeof(WNDCLASSEXW);

	return RegisterClassExW(&wcex);
}

BOOL nsSGPDF::SGPDFDocumentView::UnRegisterWindowClass(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	return UnregisterClassW(kWindowClassName, hModule);
}

LRESULT CALLBACK nsSGPDF::SGPDFDocumentView::WindowDispatch(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WMLog(hWnd, message, wParam, lParam);

	if (message == WM_NCCREATE) SetWindowLongPtrW(hWnd, GWLP_USERDATA, LONG_PTR((LPCREATESTRUCT(lParam))->lpCreateParams));

	SGPDFDocumentView *thisWindow = reinterpret_cast<SGPDFDocumentView *>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));

	if (thisWindow != nullptr)
		return thisWindow->WindowProcedure(hWnd, message, wParam, lParam);
	else
		return DefWindowProcW(hWnd, message, wParam, lParam);
}

LRESULT nsSGPDF::SGPDFDocumentView::WindowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WMLog(hWnd, message, wParam, lParam);

	auto entry = m_MessageMap.find(message);

	if (entry == m_MessageMap.end())
		return DefWindowProcW(hWnd, message, wParam, lParam);
	else
		return entry->second(hWnd, message, wParam, lParam);
}

bool nsSGPDF::SGPDFDocumentView::Create(const HWND hParent, const int x, const int y, const int w, const int h)
{
	//WriteLogFile(L"%S 0x%p %i %i %i %i\n", __FUNCSIG__, hParent, x, y, w, h);

	if ((m_Document == nullptr) || (m_Document->IsOpen() == false)) return false;

	const DWORD ws = (WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN); const DWORD es = (WS_EX_NOPARENTNOTIFY); // Window style

	const HWND hWnd = CreateWindowExW(es, kWindowClassName, nullptr, ws, x, y, w, h, hParent, HMENU(this), SGPDFSupport::Module(), this);

	if (hWnd == nullptr) { const DWORD ec = GetLastError(); DBLog(L"%S Unable to create window (%lu).\n", __FUNCSIG__, ec); }

	return (hWnd != nullptr);
}

void nsSGPDF::SGPDFDocumentView::Destroy(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	DestroyWindow(m_WindowHandle);

	//WriteLogFile(L"%S\n", __FUNCSIG__);
}

void nsSGPDF::SGPDFDocumentView::UpdateXYWH(const int x, const int y, const int w, const int h)
{
	//WriteLogFile(L"%S %i %i %i %i\n", __FUNCSIG__, x, y, w, h);

	SetWindowPos(m_WindowHandle, nullptr, x, y, w, h, (SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOZORDER));

	RedrawWindow(m_WindowHandle, nullptr, nullptr, (RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN)); // !!!
}

void nsSGPDF::SGPDFDocumentView::UpdateWH(const int w, const int h)
{
	//WriteLogFile(L"%S %i %i\n", __FUNCSIG__, w, h);

	SetWindowPos(m_WindowHandle, nullptr, 0, 0, w, h, (SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOMOVE | SWP_NOZORDER));

	RedrawWindow(m_WindowHandle, nullptr, nullptr, (RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN)); // !!!
}

//
//	Window message methods
//

void nsSGPDF::SGPDFDocumentView::RegisterMessages(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	m_MessageMap.emplace(WM_CREATE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowCreate(h, m, w, l); });
	m_MessageMap.emplace(WM_SIZE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowSize(h, m, w, l); });
	m_MessageMap.emplace(WM_ERASEBKGND, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowErase(h, m, w, l); });
	m_MessageMap.emplace(WM_PAINT, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowPaint(h, m, w, l); });
	m_MessageMap.emplace(WM_TIMER, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowTimer(h, m, w, l); });

	m_MessageMap.emplace(UX_SEARCH_FOUND, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->SearchFound(h, m, w, l); });
}

LRESULT nsSGPDF::SGPDFDocumentView::WindowCreate(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	//CREATESTRUCTW *cs = reinterpret_cast<CREATESTRUCTW *>(lParam);

	m_WindowHandle = hWnd; m_ParentWindow = GetParent(hWnd);

	RECT rect; GetClientRect(hWnd, &rect); const int cx = 0; const int cy = 0;
	const int cw = (rect.right - rect.left); const int ch = (rect.bottom - rect.top);

	m_ToolbarPane = std::make_unique<nsSGPDF::SGPDFToolbarPane>();
	m_DocumentPane = std::make_unique<nsSGPDF::SGPDFDocumentPane>(m_Document);
	m_StatusPane = std::make_unique<nsSGPDF::SGPDFStatusPane>();

	const int th = m_ToolbarPane->PaneHeight(); const int sh = m_StatusPane->PaneHeight();

	if (m_ToolbarPane->Create(hWnd, cx, cy, cw, th) == false) m_ToolbarPane = nullptr;
	if (m_DocumentPane->Create(hWnd, cx, th, cw, (ch-th-sh)) == false) m_DocumentPane = nullptr;
	if (m_StatusPane->Create(hWnd, cx, (ch-sh), cw, sh) == false) m_StatusPane = nullptr;

	if (m_ToolbarPane != nullptr) // SGPDFToolbarPane
	{
		if (auto item = m_ToolbarPane->NumberEditItem())
		{
			item->EnterSelect([this](int id) { this->NumberEnterSelect(id); });
			item->TextChanged([this](int id) { this->NumberTextChanged(id); });
			item->ChangeFocus([this](int id) { this->NumberChangeFocus(id); });
		}

		if (auto item = m_ToolbarPane->SearchEditItem())
		{
			item->EnterSelect([this](int id) { this->SearchEnterSelect(id); });
			item->TextChanged([this](int id) { this->SearchTextChanged(id); });
			item->ChangeFocus([this](int id) { this->SearchChangeFocus(id); });
		}

		if (auto item = m_ToolbarPane->PageDecrementItem())
		{
			item->ItemClicked([this](int id) { this->ToolbarItemClicked(id); });
		}

		if (auto item = m_ToolbarPane->PageIncrementItem())
		{
			item->ItemClicked([this](int id) { this->ToolbarItemClicked(id); });
		}

		if (auto item = m_ToolbarPane->ZoomDecrementItem())
		{
			item->ItemClicked([this](int id) { this->ToolbarItemClicked(id); });
		}

		if (auto item = m_ToolbarPane->ZoomIncrementItem())
		{
			item->ItemClicked([this](int id) { this->ToolbarItemClicked(id); });
		}
	}

	if (m_DocumentPane != nullptr) // SGPDFDocumentPane
	{
		//m_DocumentPane->ViewPortChanged([this]() { this->ViewPortChanged(); });
		m_DocumentPane->VisiblePagesChanged([this]() { this->VisiblePagesChanged(); });
		m_DocumentPane->CurrentPageChanged([this]() { this->CurrentPageChanged(); });
		auto sf = [this](bool cancel, int found) { this->SearchFinished(cancel, found); };
		auto sp = [this](int index, int found) { this->SearchProgress(index, found); };
		m_DocumentPane->SearchFinished(sf); m_DocumentPane->SearchProgress(sp);
	}

	return 0;
}

LRESULT nsSGPDF::SGPDFDocumentView::WindowSize(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	if ((m_ToolbarPane == nullptr) && (m_DocumentPane == nullptr) && (m_StatusPane == nullptr))
	{
		InvalidateRect(hWnd, nullptr, FALSE);
	}
	else // Position and resize panes
	{
		const int cw = LOWORD(lParam); const int ch = HIWORD(lParam);
		const int cx = 0; const int cy = 0; int th = 0; int sh = 0;

		if (m_ToolbarPane != nullptr) th = m_ToolbarPane->PaneHeight();
		if (m_StatusPane != nullptr) sh = m_StatusPane->PaneHeight();

		if (m_ToolbarPane != nullptr) m_ToolbarPane->UpdateXYWH(cx, cy, cw, th);
		if (m_DocumentPane != nullptr) m_DocumentPane->UpdateXYWH(cx, th, cw, (ch-th-sh));
		if (m_StatusPane != nullptr) m_StatusPane->UpdateXYWH(cx, (ch-sh), cw, sh);
	}

	return 0;
}

LRESULT nsSGPDF::SGPDFDocumentView::WindowErase(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	return 0;
}

LRESULT nsSGPDF::SGPDFDocumentView::WindowPaint(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	PAINTSTRUCT ps {}; HDC hDC = BeginPaint(hWnd, &ps);

	if (IsRectEmpty(&ps.rcPaint) == FALSE) // Paint the requested area
	{
		FillRect(hDC, &ps.rcPaint, SGPDFSupport::DocumentBackgroundBrush());
		//HGDIOBJ font = SGPDFSupport::SystemFont(hWnd); HGDIOBJ oldFont = SelectObject(hDC, font);
		//SetTextColor(hDC, 0x00FFFFFF); SetBkMode(hDC, TRANSPARENT); RECT area; GetClientRect(hWnd, &area);
		//DrawTextW(hDC, kWindowClassName, -1, &area, (DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP | DT_NOPREFIX));
		//SelectObject(hDC, oldFont);
	}

	EndPaint(hWnd, &ps);

	return 0;
}

LRESULT nsSGPDF::SGPDFDocumentView::WindowTimer(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	KillTimer(hWnd, wParam);

	switch (wParam) // Timer
	{
		case searchTimerTick: // Start search
		{
			if (auto item = m_ToolbarPane->SearchEditItem())
			{
				auto text = item->EditText(); StartSearch(text);
			}
			break;
		}
	}

	return 0;
}

LRESULT nsSGPDF::SGPDFDocumentView::SearchFound(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	return 0;
}

//
//	Support methods
//

void nsSGPDF::SGPDFDocumentView::UpdateUserInterface(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (m_ToolbarPane != nullptr)
	{
		if (auto item = m_ToolbarPane->ZoomDecrementItem()) item->Enable(CanZoomDecrement());
		if (auto item = m_ToolbarPane->ZoomIncrementItem()) item->Enable(CanZoomIncrement());

		if (auto item = m_ToolbarPane->NumberEditItem()) item->Enable(true);
		if (auto item = m_ToolbarPane->SearchEditItem()) item->Enable(true);
	}
}

void nsSGPDF::SGPDFDocumentView::VisiblePagesChanged(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (m_DocumentPane != nullptr)
	{
		UpdateUserInterface(); // Toolbar

		if (fn_UpdateWindowTitle != nullptr)
		{
			const auto& visiblePages = m_DocumentPane->VisiblePages();

			if (visiblePages.size() > 0)
			{
				std::wstring visible;

				auto it1 = visiblePages.begin();

				if (visiblePages.size() > 1) // Multiple
				{
					auto it2 = visiblePages.end(); --it2;

					std::wstring a = m_Document->PageLabel(*it1);
					std::wstring b = m_Document->PageLabel(*it2);

					visible = a + L", " + b;
				}
				else // Single page
				{
					visible = m_Document->PageLabel(*it1);
				}

				const int of = (m_Document->PageCount() - 1);
				std::wstring total = m_Document->PageLabel(of);

				const std::wstring& name = m_Document->Title();

				std::wstring text = name + L" (" + visible + L" of " + total + L")";

				fn_UpdateWindowTitle(text.data());
			}
		}
	}
}

void nsSGPDF::SGPDFDocumentView::CurrentPageChanged(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if ((m_ToolbarPane != nullptr) && (m_DocumentPane != nullptr))
	{
		std::wstring page = m_Document->PageLabel(m_DocumentPane->CurrentPage());

		if (auto item = m_ToolbarPane->PageDecrementItem()) item->Enable(CanPageNumberDecrement());
		if (auto item = m_ToolbarPane->PageIncrementItem()) item->Enable(CanPageNumberIncrement());

		if (auto item = m_ToolbarPane->NumberEditItem()) item->EditText(page);
	}
}

void nsSGPDF::SGPDFDocumentView::ToolbarItemClicked(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	switch (id)
	{
		case UX_ZOOM_INCREMENT: { ZoomIncrement(); break; }
		case UX_ZOOM_DECREMENT: { ZoomDecrement(); break; }

		case UX_PAGE_INCREMENT: { PageNumberIncrement(); break; }
		case UX_PAGE_DECREMENT: { PageNumberDecrement(); break; }
	}
}

void nsSGPDF::SGPDFDocumentView::StartSearch(const std::wstring& term)
{
	//WriteLogFile(L"%S '%s'\n", __FUNCSIG__, term.data());

	if ((m_DocumentPane != nullptr) && (term != m_SearchTerm))
	{
		m_SearchTerm = term; m_DocumentPane->StartSearch(m_SearchTerm, 0);
	}
}

void nsSGPDF::SGPDFDocumentView::SearchProgress(const int index, const int found)
{
	//WriteLogFile(L"%S %i %i\n", __FUNCSIG__, index, found);

	if (auto item = m_ToolbarPane->SearchTextItem())
	{
		item->UpdateText(std::to_wstring(found), 0x00008200);
	}
}

void nsSGPDF::SGPDFDocumentView::SearchFinished(bool cancel, const int found)
{
	//WriteLogFile(L"%S %i %i\n", __FUNCSIG__, cancel, found);

	if (auto item = m_ToolbarPane->SearchTextItem())
	{
		const DWORD color = (cancel ? 0x00000000 : (found ? 0x00000000 : 0x000000E0));

		std::wstring text(cancel ? L"" : std::to_wstring(found)); item->UpdateText(text, color);
	}

	if ((cancel == false) && found) PostMessageW(m_WindowHandle, UX_SEARCH_FOUND, 0, found);
}

void nsSGPDF::SGPDFDocumentView::SearchEnterSelect(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	if (auto item = m_ToolbarPane->SearchEditItem())
	{
		auto text = item->EditText(); StartSearch(text);
	}
}

void nsSGPDF::SGPDFDocumentView::SearchTextChanged(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	if (auto item = m_ToolbarPane->SearchEditItem())
	{
		auto text = item->EditText(); if (text != m_SearchText)
		{
			m_SearchText = text; SetTimer(m_WindowHandle, searchTimerTick, searchTimerTock, nullptr);
		}
	}
}

void nsSGPDF::SGPDFDocumentView::SearchChangeFocus(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	if (id != 0)
		{ if (auto item = m_ToolbarPane->NumberEditItem()) item->GiveEditFocus(); }
	else
		SetFocus(m_ParentWindow);
}

void nsSGPDF::SGPDFDocumentView::NumberEnterSelect(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	if (auto item = m_ToolbarPane->NumberEditItem())
	{
		auto text = item->EditText(); //WriteLogFile(L"%S '%s'\n", __FUNCSIG__, text.data());
	}
}

void nsSGPDF::SGPDFDocumentView::NumberTextChanged(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	if (auto item = m_ToolbarPane->NumberEditItem())
	{
		auto text = item->EditText(); //WriteLogFile(L"%S '%s'\n", __FUNCSIG__, text.data());
	}
}

void nsSGPDF::SGPDFDocumentView::NumberChangeFocus(const int id)
{
	//WriteLogFile(L"%S 0x%08X\n", __FUNCSIG__, id);

	if (id != 0)
		{ if (auto item = m_ToolbarPane->SearchEditItem()) item->GiveEditFocus(); }
	else
		SetFocus(m_ParentWindow);
}

//
//	API methods
//

void nsSGPDF::SGPDFDocumentView::UpdateWindowTitle(std::function<void(const wchar_t*)> updateWindowTitle)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, updateWindowTitle);

	fn_UpdateWindowTitle = updateWindowTitle;
}

void nsSGPDF::SGPDFDocumentView::MouseWheelV(const WPARAM wParam, const LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p\n", __FUNCSIG__, wParam, lParam);

	if (m_DocumentPane != nullptr) m_DocumentPane->MouseWheelV(wParam, lParam);
}

void nsSGPDF::SGPDFDocumentView::MouseWheelH(const WPARAM wParam, const LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p\n", __FUNCSIG__, wParam, lParam);

	if (m_DocumentPane != nullptr) m_DocumentPane->MouseWheelH(wParam, lParam);
}

bool nsSGPDF::SGPDFDocumentView::ZoomScale(const int percent)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane != nullptr) ? m_DocumentPane->ZoomScale(percent) : false;
}

int nsSGPDF::SGPDFDocumentView::ZoomScale(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane != nullptr) ? m_DocumentPane->ZoomScale() : false;
}

//
//	UI method
//

void nsSGPDF::SGPDFDocumentView::ShowInformation(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanShowInformation()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanShowInformation(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::PrintDocument(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPrintDocument()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanPrintDocument(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::CopyDocumentText(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanCopyDocumentText()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanCopyDocumentText(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::SelectAllDocumentText(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanSelectAllDocumentText()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanSelectAllDocumentText(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::SearchTextFocus(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanSearchTextFocus()) m_ToolbarPane->SearchEditItem()->GiveEditFocus();
}

bool nsSGPDF::SGPDFDocumentView::CanSearchTextFocus(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_ToolbarPane && m_ToolbarPane->SearchEditItem());
}

void nsSGPDF::SGPDFDocumentView::SearchHitIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanSearchHitIncrement()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanSearchHitIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::SearchHitDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanSearchHitDecrement()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanSearchHitDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::FindTextSelection(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanFindTextSelection()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanFindTextSelection(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::GotoTextSelection(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanGotoTextSelection()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanGotoTextSelection(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::HideDocumentSidebar(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanHideDocumentSidebar()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanHideDocumentSidebar(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::ShowDocumentOutline(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanShowDocumentOutline()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanShowDocumentOutline(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::ShowDocumentThumbs(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanShowDocumentThumbs()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanShowDocumentThumbs(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::ZoomIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanZoomIncrement()) m_DocumentPane->ZoomIncrement(1.25);
}

bool nsSGPDF::SGPDFDocumentView::CanZoomIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanZoomIncrement() : false);
}

void nsSGPDF::SGPDFDocumentView::ZoomDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanZoomDecrement()) m_DocumentPane->ZoomDecrement(1.25);
}

bool nsSGPDF::SGPDFDocumentView::CanZoomDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanZoomDecrement() : false);
}

void nsSGPDF::SGPDFDocumentView::ZoomFitWidth(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanZoomFitWidth()) m_DocumentPane->ZoomFitWidth();
}

bool nsSGPDF::SGPDFDocumentView::CanZoomFitWidth(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanZoomFitWidth() : false);
}

void nsSGPDF::SGPDFDocumentView::ZoomOneToOne(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanZoomOneToOne()) m_DocumentPane->ZoomOneToOne();
}

bool nsSGPDF::SGPDFDocumentView::CanZoomOneToOne(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanZoomOneToOne() : false);
}

void nsSGPDF::SGPDFDocumentView::PageNumberFocus(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageNumberFocus()) m_ToolbarPane->NumberEditItem()->GiveEditFocus();
}

bool nsSGPDF::SGPDFDocumentView::CanPageNumberFocus(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_ToolbarPane && m_ToolbarPane->NumberEditItem());
}

void nsSGPDF::SGPDFDocumentView::PageNumberIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageNumberIncrement()) m_DocumentPane->PageNumberIncrement();
}

bool nsSGPDF::SGPDFDocumentView::CanPageNumberIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanPageNumberIncrement() : false);
}

void nsSGPDF::SGPDFDocumentView::PageNumberDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageNumberDecrement()) m_DocumentPane->PageNumberDecrement();
}

bool nsSGPDF::SGPDFDocumentView::CanPageNumberDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanPageNumberDecrement() : false);
}

void nsSGPDF::SGPDFDocumentView::PageNavigateIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageNavigateIncrement()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanPageNavigateIncrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::PageNavigateDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageNavigateDecrement()) {}
}

bool nsSGPDF::SGPDFDocumentView::CanPageNavigateDecrement(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return false;
}

void nsSGPDF::SGPDFDocumentView::LineScrollIncrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanLineScrollIncrementY()) m_DocumentPane->LineScrollIncrementY();
}

bool nsSGPDF::SGPDFDocumentView::CanLineScrollIncrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollIncrementY() : false);
}

void nsSGPDF::SGPDFDocumentView::LineScrollDecrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanLineScrollDecrementY()) m_DocumentPane->LineScrollDecrementY();
}

bool nsSGPDF::SGPDFDocumentView::CanLineScrollDecrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollDecrementY() : false);
}

void nsSGPDF::SGPDFDocumentView::LineScrollIncrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanLineScrollIncrementX()) m_DocumentPane->LineScrollIncrementX();
}

bool nsSGPDF::SGPDFDocumentView::CanLineScrollIncrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollIncrementX() : false);
}

void nsSGPDF::SGPDFDocumentView::LineScrollDecrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanLineScrollDecrementX()) m_DocumentPane->LineScrollDecrementX();
}

bool nsSGPDF::SGPDFDocumentView::CanLineScrollDecrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollDecrementX() : false);
}

void nsSGPDF::SGPDFDocumentView::PageScrollIncrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageScrollIncrementY()) m_DocumentPane->PageScrollIncrementY();
}

bool nsSGPDF::SGPDFDocumentView::CanPageScrollIncrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollIncrementY() : false);
}

void nsSGPDF::SGPDFDocumentView::PageScrollDecrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageScrollDecrementY()) m_DocumentPane->PageScrollDecrementY();
}

bool nsSGPDF::SGPDFDocumentView::CanPageScrollDecrementY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollDecrementY() : false);
}

void nsSGPDF::SGPDFDocumentView::PageScrollIncrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageScrollIncrementX()) m_DocumentPane->PageScrollIncrementX();
}

bool nsSGPDF::SGPDFDocumentView::CanPageScrollIncrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollIncrementX() : false);
}

void nsSGPDF::SGPDFDocumentView::PageScrollDecrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanPageScrollDecrementX()) m_DocumentPane->PageScrollDecrementX();
}

bool nsSGPDF::SGPDFDocumentView::CanPageScrollDecrementX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollDecrementX() : false);
}

void nsSGPDF::SGPDFDocumentView::GotoMinimumDocumentY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanGotoMinimumDocumentY()) m_DocumentPane->GotoMinimumDocumentY();
}

bool nsSGPDF::SGPDFDocumentView::CanGotoMinimumDocumentY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollDecrementY() : false);
}

void nsSGPDF::SGPDFDocumentView::GotoMaximumDocumentY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanGotoMaximumDocumentY()) m_DocumentPane->GotoMaximumDocumentY();
}

bool nsSGPDF::SGPDFDocumentView::CanGotoMaximumDocumentY(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollIncrementY() : false);
}

void nsSGPDF::SGPDFDocumentView::GotoMinimumDocumentX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanGotoMinimumDocumentX()) m_DocumentPane->GotoMinimumDocumentX();
}

bool nsSGPDF::SGPDFDocumentView::CanGotoMinimumDocumentX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollDecrementX() : false);
}

void nsSGPDF::SGPDFDocumentView::GotoMaximumDocumentX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (CanGotoMaximumDocumentX()) m_DocumentPane->GotoMaximumDocumentX();
}

bool nsSGPDF::SGPDFDocumentView::CanGotoMaximumDocumentX(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_DocumentPane ? m_DocumentPane->CanViewPortScrollIncrementX() : false);
}
