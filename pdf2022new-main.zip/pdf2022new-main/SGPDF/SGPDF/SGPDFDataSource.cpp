//
//	SGPDFDataSource.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFDataSource.hpp"

using namespace nsSGPDF;

//
//	SGPDFDataSource methods
//

nsSGPDF::SGPDFDataSource::SGPDFDataSource(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

nsSGPDF::SGPDFDataSource::~SGPDFDataSource(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}
