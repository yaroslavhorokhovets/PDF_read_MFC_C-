//
//	SGPDFDocumentPage.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFDocument;
	class SGPDFSelection;
	class SGPDFAction;

	class SGPDFDocumentPage final
	{
		private: // Variables
			FPDF_PAGE m_pdfPage = nullptr;
			FPDF_TEXTPAGE m_TextPage = nullptr;
			FPDF_DOCUMENT m_pdfDocument = nullptr;

			SGPDFDocument* m_Document = nullptr;

			int m_PageIndex = 0; int m_Rotation = 0; UXPageSize m_PageSize;

			std::unique_ptr<std::vector<SGPDFAction>> m_PageLinks;
			std::unique_ptr<std::vector<SGPDFAction>> m_TextLinks;

			std::vector<SGPDFSelection> m_SearchSelections;

		public: // Methods
			SGPDFDocumentPage(const int index, SGPDFDocument* document);
			~SGPDFDocumentPage(void);

			SGPDFDocumentPage(void) = delete;
			SGPDFDocumentPage(const SGPDFDocumentPage&) = delete;
			SGPDFDocumentPage& operator=(const SGPDFDocumentPage&) = delete;
			SGPDFDocumentPage& operator=(SGPDFDocumentPage&&) = delete;
			SGPDFDocumentPage(SGPDFDocumentPage&&) = delete;

			bool IsOpen(void) const;

			const HBITMAP PageThumb(const HDC hDC, const int size) const;
			const HBITMAP PageBitmap(const HDC hDC, const double scale) const;
			void DrawPageArea(const FPDF_BITMAP pdfBitmap, const UXRect& pageArea, const double scale) const;
			void DrawOverPage(const HDC hDC, const UXRect& pageArea, const double scale) const;

			const SGPDFAction* ActionForPoint(const UXPoint& point);
			std::wstring ActionTooltip(const SGPDFAction* action);
			bool ExtractLinks(void);

			int SearchPage(const std::wstring& term, const int options, int& counter);
			void ClearSearch(void);

		private: // Methods
			const FPDF_TEXTPAGE TextPage(void);
			void TextPageClose(void);

			bool ExtractPageLinks(void);
			bool ExtractTextLinks(void);
	};
}
