//
//	SGPDFTemplates.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFTemplates final
	{
		private: // Variables

		public: // Methods
			SGPDFTemplates(void);
			~SGPDFTemplates(void);

			SGPDFTemplates(const SGPDFTemplates&) = delete;
			SGPDFTemplates& operator=(const SGPDFTemplates&) = delete;
			SGPDFTemplates& operator=(SGPDFTemplates&&) = delete;
			SGPDFTemplates(SGPDFTemplates&&) = delete;

		private: // Methods
	};
}

template<typename T> class UXRectZ
{
	private:
		T x_1, y_1;
		T x_2, y_2;

	public:
		UXRectZ(void) : x_1(0), y_1(0), x_2(0), y_2(0) {}

		UXRectZ(T x1, T y1, T x2, T y2) : x_1(x1), y_1(y1), x_2(x2), y_2(y2) {}

		inline T x1(void) { return x_1; }
		inline T y1(void) { return y_1; }
		inline T x2(void) { return x_2; }
		inline T y2(void) { return y_2; }

		inline T x(void) { return x_1; }
		inline T y(void) { return y_1; }
		inline T w(void) { return (x_2 - x_1); }
		inline T h(void) { return (y_2 - y_1); }

		inline bool contains(T x, T y) const
		{
			return ((x >= x_1) && (x <= x_2) && (y >= y_1) && (y <= y_2));
		}
};
