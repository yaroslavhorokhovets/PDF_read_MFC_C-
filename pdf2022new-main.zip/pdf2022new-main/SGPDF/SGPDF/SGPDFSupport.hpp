//
//	SGPDFSupport.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

#ifndef NEGATORY
#define NEGATORY (-1)
#endif// NEGATORY

namespace nsSGPDF
{
	class SGPDFSupport final
	{
		public: // Methods
			static SGPDFSupport& Instance(void)
			{
				static SGPDFSupport singleton; return singleton;
			}

			std::mutex Mutex;

			static HMODULE Module(void);

			static int UIS(const int dpi = 96);
			static int DPI(const HWND hWnd = nullptr);

			static std::wstring UTF16(const std::string& utf8);
			static std::string UTF8(const std::wstring& utf16);

			static HBRUSH PaneSeparatorLineBrush(void);
			static HBRUSH TestPaneBackgroundBrush(void);
			static HBRUSH StatusPaneBackgroundBrush(void);
			static HBRUSH ToolbarPaneBackgroundBrush(void);
			static HBRUSH ToolbarItemHighlightBrush(void);
			static HBRUSH ToolbarItemSelectedBrush(void);
			static HBRUSH DocumentBackgroundBrush(void);
			static HBRUSH EditControlFillBrush(void);
			static HBRUSH EditControlLineBrush(void);

			static HGDIOBJ SystemFont(const HWND hWnd);

			static HCURSOR WaitCursor(void);
			static HCURSOR ArrowCursor(void);
			static HCURSOR PointCursor(void);
			static HCURSOR BusyCursor(void);

		private: // Methods
			SGPDFSupport(void);
			~SGPDFSupport(void);

			SGPDFSupport(const SGPDFSupport&) = delete;
			SGPDFSupport& operator=(const SGPDFSupport&) = delete;
			SGPDFSupport& operator=(SGPDFSupport&&) = delete;
			SGPDFSupport(SGPDFSupport&&) = delete;

			HGDIOBJ GetSystemFont(const HWND hWnd);

		private: // Variables
			HBRUSH m_PaneSeparatorLineBrush = nullptr;
			HBRUSH m_TestPaneBackgroundBrush = nullptr;
			HBRUSH m_StatusPaneBackgroundBrush = nullptr;
			HBRUSH m_ToolbarPaneBackgroundBrush = nullptr;
			HBRUSH m_ToolbarItemHighlightBrush = nullptr;
			HBRUSH m_ToolbarItemSelectedBrush = nullptr;
			HBRUSH m_DocumentBackgroundBrush = nullptr;
			HBRUSH m_EditControlFillBrush = nullptr;
			HBRUSH m_EditControlLineBrush = nullptr;

			HGDIOBJ m_SystemFont = nullptr;

			HCURSOR m_WaitCursor = nullptr;
			HCURSOR m_ArrowCursor = nullptr;
			HCURSOR m_PointCursor = nullptr;
			HCURSOR m_BusyCursor = nullptr;
	};
}
