//
//	SGPDFToolbarText.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFToolbarText.hpp"

using namespace nsSGPDF;

//
//	Constants
//

static const wchar_t* kWindowClassName = L"SGPDFToolbarTextClass";

//
//	SGPDFToolbarText methods
//

nsSGPDF::SGPDFToolbarText::SGPDFToolbarText(const int id)
{
	//WriteLogFile(L"%S 0x%p %i\n", __FUNCSIG__, this, id);

	m_ItemID = id; RegisterMessages();
}

nsSGPDF::SGPDFToolbarText::~SGPDFToolbarText(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_WindowHandle = nullptr; m_ParentWindow = nullptr;

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

ATOM nsSGPDF::SGPDFToolbarText::DoRegisterWindowClass(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	WNDCLASSEXW wcex; RtlSecureZeroMemory(&wcex, sizeof(wcex));

	wcex.hInstance = hModule;
	wcex.lpszClassName = kWindowClassName;
	wcex.style = 0; wcex.lpszMenuName = nullptr;
	wcex.lpfnWndProc = SGPDFToolbarText::WindowDispatch;
	wcex.hIcon = nullptr; wcex.hIconSm = nullptr; wcex.hbrBackground = nullptr;
	wcex.hCursor = SGPDFSupport::ArrowCursor();
	wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
	wcex.cbSize = sizeof(WNDCLASSEXW);

	return RegisterClassExW(&wcex);
}

BOOL nsSGPDF::SGPDFToolbarText::UnRegisterWindowClass(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	return UnregisterClassW(kWindowClassName, hModule);
}

LRESULT CALLBACK nsSGPDF::SGPDFToolbarText::WindowDispatch(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WMLog(hWnd, message, wParam, lParam);

	if (message == WM_NCCREATE) SetWindowLongPtrW(hWnd, GWLP_USERDATA, LONG_PTR((LPCREATESTRUCT(lParam))->lpCreateParams));

	SGPDFToolbarText *thisWindow = reinterpret_cast<SGPDFToolbarText *>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));

	if (thisWindow != nullptr)
		return thisWindow->WindowProcedure(hWnd, message, wParam, lParam);
	else
		return DefWindowProcW(hWnd, message, wParam, lParam);
}

LRESULT nsSGPDF::SGPDFToolbarText::WindowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WMLog(hWnd, message, wParam, lParam);

	auto entry = m_MessageMap.find(message);

	if (entry == m_MessageMap.end())
		return DefWindowProcW(hWnd, message, wParam, lParam);
	else
		return entry->second(hWnd, message, wParam, lParam);
}

bool nsSGPDF::SGPDFToolbarText::Create(const HWND hParent, const int x, const int y, const int w, const int h)
{
	//WriteLogFile(L"%S 0x%p %i %i %i %i\n", __FUNCSIG__, hParent, x, y, w, h);

	const DWORD ws = (WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN); const DWORD es = (WS_EX_NOPARENTNOTIFY); // Window style

	const HWND hWnd = CreateWindowExW(es, kWindowClassName, nullptr, ws, x, y, w, h, hParent, HMENU(this), SGPDFSupport::Module(), this);

	if (hWnd == nullptr) { const DWORD ec = GetLastError(); DBLog(L"%S Unable to create window (%lu).\n", __FUNCSIG__, ec); }

	return (hWnd != nullptr);
}

void nsSGPDF::SGPDFToolbarText::Destroy(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	DestroyWindow(m_WindowHandle);
}

void nsSGPDF::SGPDFToolbarText::UpdateXYWH(const int x, const int y, const int w, const int h)
{
	//WriteLogFile(L"%S %i %i %i %i\n", __FUNCSIG__, x, y, w, h);

	SetWindowPos(m_WindowHandle, nullptr, x, y, w, h, (SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOZORDER));

	RedrawWindow(m_WindowHandle, nullptr, nullptr, (RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN)); // !!!
}

void nsSGPDF::SGPDFToolbarText::UpdateWH(const int w, const int h)
{
	//WriteLogFile(L"%S %i %i\n", __FUNCSIG__, w, h);

	SetWindowPos(m_WindowHandle, nullptr, 0, 0, w, h, (SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOMOVE | SWP_NOZORDER));

	RedrawWindow(m_WindowHandle, nullptr, nullptr, (RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN)); // !!!
}

//
//	Window message methods
//

void nsSGPDF::SGPDFToolbarText::RegisterMessages(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	m_MessageMap.emplace(WM_CREATE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowCreate(h, m, w, l); });
	m_MessageMap.emplace(WM_SIZE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowSize(h, m, w, l); });
	m_MessageMap.emplace(WM_ERASEBKGND, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowErase(h, m, w, l); });
	m_MessageMap.emplace(WM_PAINT, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowPaint(h, m, w, l); });
}

LRESULT nsSGPDF::SGPDFToolbarText::WindowCreate(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	//CREATESTRUCTW *cs = reinterpret_cast<CREATESTRUCTW *>(lParam);

	m_WindowHandle = hWnd; m_ParentWindow = GetParent(hWnd);

	m_BackgroundBrush = SGPDFSupport::ToolbarPaneBackgroundBrush();

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarText::WindowSize(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	//const int cw = LOWORD(lParam); const int ch = HIWORD(lParam);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarText::WindowErase(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarText::WindowPaint(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	PAINTSTRUCT ps {}; HDC hDC = BeginPaint(hWnd, &ps);

	if (IsRectEmpty(&ps.rcPaint) == FALSE) HandlePaint(hWnd, hDC);

	EndPaint(hWnd, &ps);

	return 0;
}

//
//	API methods
//

void nsSGPDF::SGPDFToolbarText::HandlePaint(const HWND hWnd, const HDC hDC)
{
	//WriteLogFile(L"%S 0x%p 0x%p\n", __FUNCSIG__, hWnd, hDC);

	const UINT options = (DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP | DT_NOPREFIX);

	RECT area; GetClientRect(hWnd, &area); FillRect(hDC, &area, m_BackgroundBrush);
	const HGDIOBJ font = SGPDFSupport::SystemFont(hWnd); const HGDIOBJ oldFont = SelectObject(hDC, font);
	SetTextColor(hDC, m_TextColor); SetBkMode(hDC, TRANSPARENT); //SetBkColor(hDC, 0x00FFFFFF);
	DrawTextW(hDC, m_Text.data(), int(m_Text.length()), &area, options);
	SelectObject(hDC, oldFont);
}

void nsSGPDF::SGPDFToolbarText::RenderText(const std::wstring& text, const DWORD textColor)
{
	//WriteLogFile(L"%S '%s'\n", __FUNCSIG__, text.data());

	if ((text != m_Text) || (textColor != m_TextColor))
	{
		m_Text = text; m_TextColor = textColor; const HWND hWnd = m_WindowHandle;

		if (HDC hDC = GetDC(hWnd)) { HandlePaint(hWnd, hDC); ReleaseDC(hWnd, hDC); }
	}
}

void nsSGPDF::SGPDFToolbarText::UpdateText(const std::wstring& text, const DWORD textColor)
{
	//WriteLogFile(L"%S '%s'\n", __FUNCSIG__, text.data());

	if ((text != m_Text) || (textColor != m_TextColor))
	{
		m_Text = text; m_TextColor = textColor; InvalidateRect(m_WindowHandle, nullptr, FALSE);
	}
}

void nsSGPDF::SGPDFToolbarText::BackgroundBrush(const HBRUSH hBrush)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hBrush);

	if (hBrush != m_BackgroundBrush)
	{
		m_BackgroundBrush = hBrush; InvalidateRect(m_WindowHandle, nullptr, FALSE);
	}
}
