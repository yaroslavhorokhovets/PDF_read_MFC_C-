//
//	SGPDFPageCache.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFPageCache final
	{
		private: // Variables
			size_t m_PageCacheSizeLimit = 4194304;
			std::map<int, HBITMAP> m_PageBitmapCache;
			std::vector<int> m_PageBitmapQueue;

		public: // Methods
			SGPDFPageCache(const size_t limit);
			~SGPDFPageCache(void);

			SGPDFPageCache(void) = delete;
			SGPDFPageCache(const SGPDFPageCache&) = delete;
			SGPDFPageCache& operator=(const SGPDFPageCache&) = delete;
			SGPDFPageCache& operator=(SGPDFPageCache&&) = delete;
			SGPDFPageCache(SGPDFPageCache&&) = delete;

			void PurgePageBitmapCache(void);
			void PrunePageBitmapCache(void);
			void PurgeNotVisiblePages(const std::set<int>& visiblePages);
			void CachePageBitmap(const int index, const HBITMAP hBitmap);
			HBITMAP CachedPageBitmap(const int index);

		private: // Methods
			void RemovePageFromQueue(const int index);
			void MovePageToBackOfQueue(const int index);
			void PurgePageBitmap(const int index);
	};
}
