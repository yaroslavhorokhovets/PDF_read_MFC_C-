//
//	SGPDFSelection.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFSelection.hpp"

using namespace nsSGPDF;

//
//	SGPDFSelection methods
//

nsSGPDF::SGPDFSelection::SGPDFSelection(const int pageIndex, const int charIndex, const int charCount, const std::vector<UXRect>& rectangles, const int selection)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_PageIndex = pageIndex; m_CharIndex = charIndex; m_CharCount = charCount; m_Rectangles = rectangles; m_Selection = selection;
}

nsSGPDF::SGPDFSelection::~SGPDFSelection(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

const std::vector<UXRect> nsSGPDF::SGPDFSelection::Rectangles(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Rectangles;
}

int nsSGPDF::SGPDFSelection::PageIndex(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_PageIndex;
}

int nsSGPDF::SGPDFSelection::CharIndex(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_CharIndex;
}

int nsSGPDF::SGPDFSelection::CharCount(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_CharCount;
}

int nsSGPDF::SGPDFSelection::Selection(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Selection;
}

void nsSGPDF::SGPDFSelection::Description(void) const
{
	DBLog(L"%S %i (%zu) %i\n", __FUNCSIG__, m_PageIndex, m_Rectangles.size(), m_Selection);
}
