//
//	SGPDFDataSource.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFDataSource
	{
		public: // Methods
			SGPDFDataSource(void);
			SGPDFDataSource(const SGPDFDataSource&) = default;
			SGPDFDataSource& operator=(const SGPDFDataSource&) = default;
			SGPDFDataSource& operator=(SGPDFDataSource&&) = default;
			SGPDFDataSource(SGPDFDataSource&&) = default;
			virtual ~SGPDFDataSource(void);

			virtual bool GetDataBlock(const size_t offset, const size_t size, const void *buffer) = 0;
			virtual size_t DataLength(void) = 0;
	};
}
