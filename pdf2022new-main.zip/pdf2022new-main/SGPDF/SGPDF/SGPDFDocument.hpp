//
//	SGPDFDocument.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFDataSource;
	class SGPDFDocumentPage;

	class SGPDFDocument final
	{
		private: // Variables
			std::wstring m_DocumentFile;

			std::vector<uint8_t> m_DocumentData;

			std::shared_ptr<SGPDFDataSource> m_DataSource;

			std::unordered_map<int, std::shared_ptr<SGPDFDocumentPage>> m_DocumentPages;

			std::unordered_map<int, std::wstring> m_PageLabels;

			FPDF_DOCUMENT m_pdfDocument = nullptr;

			std::vector<UXPageSize> m_PageSizes;

			int m_PageCount = 0; int m_MaximumPage = 0;

			std::wstring m_DocumentTitle;

		public: // Methods
			SGPDFDocument(const wchar_t *filePath);
			SGPDFDocument(const void *const data, const size_t size);
			SGPDFDocument(const std::shared_ptr<SGPDFDataSource>& source);
			~SGPDFDocument(void);

			SGPDFDocument(void) = delete;
			SGPDFDocument(const SGPDFDocument&) = delete;
			SGPDFDocument& operator=(const SGPDFDocument&) = delete;
			SGPDFDocument& operator=(SGPDFDocument&&) = delete;
			SGPDFDocument(SGPDFDocument&&) = delete;

			bool operator==(const SGPDFDocument& rhs);

			bool IsOpen(void) const;
			bool OpenWithPassword(const wchar_t *password, int& errorCode);
			FPDF_DOCUMENT pdfDocument(void) const;

			int PageCount(void) const;
			bool IsValidPageIndex(const int index) const;
			int MinimumPage(void) const;
			int MaximumPage(void) const;

			const UXPageSize& PageSize(const int index) const;
			std::shared_ptr<SGPDFDocumentPage> DocumentPage(const int index);
			void EnumerateCachedPages(std::function<void(int, const std::shared_ptr<SGPDFDocumentPage>&)> fn);
			std::wstring PageLabel(const int index);

			const std::wstring& Title(void);

			bool ConserveMemory(void) const;

			void HexDump(void);

		private: // Methods
			static int GetDataBlock(void *self, unsigned long offset, unsigned char *buffer, unsigned long size);

			void HexCode(const void *data, const size_t size);
	};
}
