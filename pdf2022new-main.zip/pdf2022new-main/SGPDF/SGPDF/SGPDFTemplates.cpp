//
//	SGPDFTemplates.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFTemplates.hpp"

using namespace nsSGPDF;

//
//	SGPDFTemplates methods
//

nsSGPDF::SGPDFTemplates::SGPDFTemplates(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	UXRectZ<double> rect(4.0, 4.0, 32.0, 32.0);

	DBLog(L"%S %g %g %g %g\n", __FUNCSIG__, rect.x1(), rect.y1(), rect.x2(), rect.y2());

	DBLog(L"%S %g %g %g %g\n", __FUNCSIG__, rect.x(), rect.y(), rect.w(), rect.h());

	DBLog(L"%S %i\n", __FUNCSIG__, rect.contains(8.0, 16.0));
}

nsSGPDF::SGPDFTemplates::~SGPDFTemplates(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}
