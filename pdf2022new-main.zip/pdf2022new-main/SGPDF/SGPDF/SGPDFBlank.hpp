//
//	SGPDFBlank.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFBlank final
	{
		private: // Variables

		public: // Methods
			SGPDFBlank(void);
			~SGPDFBlank(void);

			SGPDFBlank(const SGPDFBlank&) = delete;
			SGPDFBlank& operator=(const SGPDFBlank&) = delete;
			SGPDFBlank& operator=(SGPDFBlank&&) = delete;
			SGPDFBlank(SGPDFBlank&&) = delete;

		private: // Methods
	};
}
