//
//	SGPDFToolbarPane.h
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFToolbarItem;
	class SGPDFToolbarText;
	class SGPDFToolbarEdit;

	class SGPDFToolbarPane final
	{
		private: // Variables
			HWND m_WindowHandle = nullptr;
			HWND m_ParentWindow = nullptr;
			int m_SeparatorSize = 0;
			int m_PaneHeight = 0;

			std::unique_ptr<SGPDFToolbarEdit> m_NumberEditItem;

			std::unique_ptr<SGPDFToolbarEdit> m_SearchEditItem;
			std::unique_ptr<SGPDFToolbarText> m_SearchTextItem;

			std::unique_ptr<SGPDFToolbarItem> m_PageDecrementItem;
			std::unique_ptr<SGPDFToolbarItem> m_PageIncrementItem;

			std::unique_ptr<SGPDFToolbarItem> m_ZoomDecrementItem;
			std::unique_ptr<SGPDFToolbarItem> m_ZoomIncrementItem;

			std::map<UINT, std::function<LRESULT(HWND, UINT, WPARAM, LPARAM)>> m_MessageMap;

		public: // Methods
			SGPDFToolbarPane(void);
			~SGPDFToolbarPane(void);

			SGPDFToolbarPane(const SGPDFToolbarPane&) = delete;
			SGPDFToolbarPane& operator=(const SGPDFToolbarPane&) = delete;
			SGPDFToolbarPane& operator=(SGPDFToolbarPane&&) = delete;
			SGPDFToolbarPane(SGPDFToolbarPane&&) = delete;

			static ATOM DoRegisterWindowClass(const HMODULE hModule);
			static BOOL UnRegisterWindowClass(const HMODULE hModule);

			int PaneHeight(const HWND hWnd = nullptr);
			bool Create(const HWND hParent, const int x, const int y, const int w, const int h); void Destroy(void);
			void UpdateXYWH(const int x, const int y, const int w, const int h); void UpdateWH(const int w, const int h);

			SGPDFToolbarItem* PageDecrementItem(void) const;
			SGPDFToolbarItem* PageIncrementItem(void) const;

			SGPDFToolbarItem* ZoomDecrementItem(void) const;
			SGPDFToolbarItem* ZoomIncrementItem(void) const;

			SGPDFToolbarEdit* SearchEditItem(void) const;
			SGPDFToolbarText* SearchTextItem(void) const;

			SGPDFToolbarEdit* NumberEditItem(void) const;

		private: // Methods
			LRESULT WindowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
			static LRESULT CALLBACK WindowDispatch(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

			LRESULT WindowCreate(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
			LRESULT WindowSize(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
			LRESULT WindowErase(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
			LRESULT WindowPaint(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
			LRESULT MenuContext(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

			void AddToolbarItems(const HWND hWnd);
			void RegisterMessages(void);
	};
}
