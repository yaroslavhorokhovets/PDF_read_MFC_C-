//
//	SGPDFGlobals.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFGlobals.hpp"

//
//	Global statics
//
