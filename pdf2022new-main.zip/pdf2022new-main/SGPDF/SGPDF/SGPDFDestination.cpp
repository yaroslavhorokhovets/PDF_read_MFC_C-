//
//	SGPDFDestination.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFDestination.hpp"

using namespace nsSGPDF;

//
//	SGPDFDestination methods
//

nsSGPDF::SGPDFDestination::SGPDFDestination(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_PageIndex = NEGATORY;
}

nsSGPDF::SGPDFDestination::SGPDFDestination(const int index, bool hasX, bool hasY, bool hasZ, double x, double y, double z)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	if (hasX) { m_X = x; m_HasX = hasX; }
	if (hasY) { m_Y = y; m_HasY = hasY; }
	if (hasZ) { m_Z = z; m_HasZ = hasZ; }

	m_PageIndex = index;
}

nsSGPDF::SGPDFDestination::~SGPDFDestination(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

int nsSGPDF::SGPDFDestination::PageIndex(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_PageIndex;
}

int nsSGPDF::SGPDFDestination::PageNumber(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_PageIndex + 1);
}

bool nsSGPDF::SGPDFDestination::hasX(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_HasX;
}

double nsSGPDF::SGPDFDestination::X(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_X;
}

bool nsSGPDF::SGPDFDestination::hasY(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_HasY;
}

double nsSGPDF::SGPDFDestination::Y(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Y;
}

bool nsSGPDF::SGPDFDestination::hasZ(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_HasZ;
}

double nsSGPDF::SGPDFDestination::Z(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Z;
}

void nsSGPDF::SGPDFDestination::Description(void) const
{
	DBLog(L"%S %i x:%i:%g y:%i:%g z:%i:%g\n", __FUNCSIG__, m_PageIndex, m_HasX, m_X, m_HasY, m_Y, m_HasZ, m_Z);
}
