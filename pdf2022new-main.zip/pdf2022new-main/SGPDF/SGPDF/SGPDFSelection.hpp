//
//	SGPDFSelection.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFSelection final
	{
		private: // Variables
			std::vector<UXRect> m_Rectangles;

			int m_PageIndex = 0; int m_CharIndex = 0; int m_CharCount = 0; int m_Selection = 0;

		public: // Methods
			SGPDFSelection(const int pageIndex, const int charIndex, const int charCount, const std::vector<UXRect>& rectangles, const int selection);
			~SGPDFSelection(void);

			SGPDFSelection(void) = delete;
			SGPDFSelection(const SGPDFSelection&) = default;
			SGPDFSelection& operator=(const SGPDFSelection&) = default;
			SGPDFSelection& operator=(SGPDFSelection&&) = delete;
			//SGPDFSelection(SGPDFSelection&&) = delete;

			const std::vector<UXRect> Rectangles(void) const;

			int PageIndex(void) const;
			int CharIndex(void) const;
			int CharCount(void) const;
			int Selection(void) const;

			void Description(void) const;
	};
}
