//
//	SGPDFLibrary.hpp
//	SGPDF v0.1
//
//	Copyright � 2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

#include "SGPDFMainWindow.hpp"

namespace nsSGPDF
{
	class SGPDFLibrary final
	{
		public: // Methods
			static SGPDFLibrary& Instance(void)
			{
				static SGPDFLibrary singleton; return singleton;
			}

			static void Module(const HMODULE hModule);
			static HMODULE Module(void);

		private: // Methods
			SGPDFLibrary(void);
			~SGPDFLibrary(void);

			SGPDFLibrary(const SGPDFLibrary&) = delete;
			SGPDFLibrary& operator=(const SGPDFLibrary&) = delete;
			SGPDFLibrary& operator=(SGPDFLibrary&&) = delete;
			SGPDFLibrary(SGPDFLibrary&&) = delete;

			void hModule(const HMODULE hModule);
			HMODULE hModule(void);

			void DoRegisterWindowClasses(void);
			void UnRegisterWindowClasses(void);

		private: // Variables
			HMODULE m_Module = nullptr;
			ULONG_PTR m_GdiPlusToken = 0;
	};
}

extern void DBLog(const wchar_t *format, ...);
extern void DBHex(const void *data, const size_t size);
extern void WMLog(const HWND hWnd, const UINT message, const WPARAM wParam, const LPARAM lParam);
