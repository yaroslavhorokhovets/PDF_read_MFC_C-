//
//	SGPDFAction.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFAction.hpp"
#include "SGPDFDestination.hpp"

using namespace nsSGPDF;

//
//	SGPDFAction methods
//

nsSGPDF::SGPDFAction::SGPDFAction(const std::string& URI, const UXRect& rectangle)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_Type = SGPDFActionType::URI;

	m_Rectangles.push_back(rectangle);

	m_URI = SGPDFSupport::UTF16(URI);
}

nsSGPDF::SGPDFAction::SGPDFAction(const SGPDFDestination& destination, const UXRect& rectangle)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_Type = SGPDFActionType::Goto;

	m_Destination = std::make_unique<SGPDFDestination>(destination);

	m_Rectangles.push_back(rectangle);
}

nsSGPDF::SGPDFAction::SGPDFAction(const SGPDFDestination& destination, const std::wstring& URI, const UXRect& rectangle)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_Type = SGPDFActionType::RemoteGoto;

	m_Destination = std::make_unique<SGPDFDestination>(destination);

	m_Rectangles.push_back(rectangle); m_URI = URI;
}

nsSGPDF::SGPDFAction::SGPDFAction(const std::wstring& URI, const UXRect& rectangle)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_Type = SGPDFActionType::Launch;

	m_Rectangles.push_back(rectangle); m_URI = URI;
}

nsSGPDF::SGPDFAction::SGPDFAction(const std::wstring& URI, const std::vector<UXRect>& rectangles)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_Type = SGPDFActionType::Link;

	m_Rectangles = rectangles; m_URI = URI;
}

nsSGPDF::SGPDFAction::~SGPDFAction(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

SGPDFActionType nsSGPDF::SGPDFAction::Type(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Type;
}

const SGPDFDestination* nsSGPDF::SGPDFAction::Destination(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Destination.get();
}

const std::vector<UXRect>& nsSGPDF::SGPDFAction::Rectangles(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_Rectangles;
}

const std::wstring& nsSGPDF::SGPDFAction::URI(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_URI;
}

bool nsSGPDF::SGPDFAction::Contains(const UXPoint& point) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	for (const UXRect& rectangle : m_Rectangles) // O(n)
	{
		if (rectangle.contains(point)) return true;
	}

	return false;
}

void nsSGPDF::SGPDFAction::Description(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	switch (m_Type)
	{
		case SGPDFActionType::URI:
		{
			DBLog(L"%S URI: '%s'\n", __FUNCSIG__, m_URI.data());
			break;
		}

		case SGPDFActionType::Goto:
		{
			DBLog(L"%S Goto: %i\n", __FUNCSIG__, m_Destination->PageIndex());
			break;
		}

		case SGPDFActionType::RemoteGoto:
		{
			DBLog(L"%S RemoteGoto: '%s' %i\n", __FUNCSIG__, m_URI.data(), m_Destination->PageIndex());
			break;
		}

		case SGPDFActionType::Launch:
		{
			DBLog(L"%S Launch: '%s'\n", __FUNCSIG__, m_URI.data());
			break;
		}

		case SGPDFActionType::Link:
		{
			DBLog(L"%S Link: '%s'\n", __FUNCSIG__, m_URI.data());
			break;
		}
	}
}
