//
//	SGPDFResource.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFResource final
	{
		public: // Methods
			static SGPDFResource& Instance(void)
			{
				static SGPDFResource singleton; return singleton;
			}

			static const HBITMAP Icon(const HDC hDC, const int id, const int w, const int h);
			static const wchar_t *String(const int id);

		private: // Methods
			SGPDFResource(void);
			~SGPDFResource(void);

			SGPDFResource(const SGPDFResource&) = delete;
			SGPDFResource& operator=(const SGPDFResource&) = delete;
			SGPDFResource& operator=(SGPDFResource&&) = delete;
			SGPDFResource(SGPDFResource&&) = delete;

			void PopulateStrings(void);
			void PopulateIconData(void);

			HBITMAP CreateIcon(const HDC hDC, const int id, const int w, const int h);
			HBITMAP RenderIcon(const HDC hDC, const int w, const int h, const uint8_t* data, const size_t size);

		private: // Variables
			std::map<int, std::wstring> m_Strings;
			std::map<int, std::pair<uint8_t*, size_t>> m_IconData;
			std::map<int, HBITMAP> m_Icons;
	};
}
