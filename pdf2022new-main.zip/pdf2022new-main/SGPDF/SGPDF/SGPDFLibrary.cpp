//
//	SGPDFLibrary.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFLibrary.hpp"
#include "SGPDFMainWindow.hpp"
#include "SGPDFDocumentPane.hpp"
#include "SGPDFDocumentView.hpp"
#include "SGPDFToolbarPane.hpp"
#include "SGPDFToolbarItem.hpp"
#include "SGPDFToolbarText.hpp"
#include "SGPDFToolbarEdit.hpp"
#include "SGPDFStatusPane.hpp"

using namespace nsSGPDF;

//
//	SGPDFLibrary methods
//

nsSGPDF::SGPDFLibrary::SGPDFLibrary(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	OleInitialize(nullptr);

	INITCOMMONCONTROLSEX icc; icc.dwSize = sizeof(icc);
	icc.dwICC = ICC_STANDARD_CLASSES; InitCommonControlsEx(&icc);

	Gdiplus::GdiplusStartupInput gdiPlusStartupInput;
	Gdiplus::GdiplusStartup(&m_GdiPlusToken, &gdiPlusStartupInput, nullptr);

	const FPDF_LIBRARY_CONFIG config {2, nullptr, nullptr, 0};
	FPDF_InitLibraryWithConfig(&config);
}

nsSGPDF::SGPDFLibrary::~SGPDFLibrary(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	Gdiplus::GdiplusShutdown(m_GdiPlusToken); m_GdiPlusToken = 0;

	FPDF_DestroyLibrary(); UnRegisterWindowClasses(); OleUninitialize();

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

//
//	Module methods
//

void nsSGPDF::SGPDFLibrary::hModule(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	if ((hModule != nullptr) && (m_Module == nullptr))
	{
		m_Module = hModule; DoRegisterWindowClasses();
	}
}

void nsSGPDF::SGPDFLibrary::Module(const HMODULE hModule)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFLibrary& Instance = SGPDFLibrary::Instance();

	Instance.hModule(hModule);
}

HMODULE nsSGPDF::SGPDFLibrary::hModule(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, m_Module);

	if (m_Module == nullptr) // Default
	{
		m_Module = GetModuleHandleW(nullptr);

		DoRegisterWindowClasses();
	}

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, m_Module);

	return m_Module;
}

HMODULE nsSGPDF::SGPDFLibrary::Module(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFLibrary& Instance = SGPDFLibrary::Instance();

	return Instance.hModule();
}

//
//	Window methods
//

void nsSGPDF::SGPDFLibrary::DoRegisterWindowClasses(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, m_Module);

	if (m_Module != nullptr)
	{
		SGPDFMainWindow::DoRegisterWindowClass(m_Module);

		SGPDFDocumentPane::DoRegisterWindowClass(m_Module);
		SGPDFDocumentView::DoRegisterWindowClass(m_Module);

		SGPDFToolbarPane::DoRegisterWindowClass(m_Module);
		SGPDFToolbarItem::DoRegisterWindowClass(m_Module);
		SGPDFToolbarText::DoRegisterWindowClass(m_Module);
		SGPDFToolbarEdit::DoRegisterWindowClass(m_Module);

		SGPDFStatusPane::DoRegisterWindowClass(m_Module);
	}
}

void nsSGPDF::SGPDFLibrary::UnRegisterWindowClasses(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, m_Module);

	if (m_Module != nullptr)
	{
		SGPDFMainWindow::UnRegisterWindowClass(m_Module);

		SGPDFDocumentPane::UnRegisterWindowClass(m_Module);
		SGPDFDocumentView::UnRegisterWindowClass(m_Module);

		SGPDFToolbarPane::UnRegisterWindowClass(m_Module);
		SGPDFToolbarItem::UnRegisterWindowClass(m_Module);
		SGPDFToolbarText::UnRegisterWindowClass(m_Module);
		SGPDFToolbarEdit::UnRegisterWindowClass(m_Module);

		SGPDFStatusPane::UnRegisterWindowClass(m_Module);
	}
}
