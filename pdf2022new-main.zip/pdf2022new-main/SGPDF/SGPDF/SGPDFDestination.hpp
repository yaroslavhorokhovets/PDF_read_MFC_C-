//
//	SGPDFDestination.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFDestination final
	{
		private: // Variables
			int m_PageIndex = 0;

			double m_X = 0.0;
			double m_Y = 0.0;
			double m_Z = 0.0;

			bool m_HasX = false;
			bool m_HasY = false;
			bool m_HasZ = false;

		public: // Methods
			SGPDFDestination(void);
			SGPDFDestination(const int index, bool hasX, bool hasY, bool hasZ, double x, double y, double z);
			~SGPDFDestination(void);

			SGPDFDestination(const SGPDFDestination&) = default;
			SGPDFDestination& operator=(const SGPDFDestination&) = default;
			SGPDFDestination& operator=(SGPDFDestination&&) = default;
			SGPDFDestination(SGPDFDestination&&) = default;

			int PageIndex(void) const; int PageNumber(void) const;

			bool hasX(void) const; double X(void) const;
			bool hasY(void) const; double Y(void) const;
			bool hasZ(void) const; double Z(void) const;

			void Description(void) const;
	};
}
