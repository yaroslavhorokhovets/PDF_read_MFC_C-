//
//	SGPDFAction.hpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#pragma once

namespace nsSGPDF
{
	class SGPDFDestination;

	enum class SGPDFActionType {None, URI, Goto, RemoteGoto, Launch, Link};

	class SGPDFAction final
	{
		private: // Variables
			SGPDFActionType m_Type = SGPDFActionType::None;
			std::unique_ptr<SGPDFDestination> m_Destination;
			std::vector<UXRect> m_Rectangles;
			std::wstring m_URI;

		public: // Methods
			SGPDFAction(const std::string& URI, const UXRect& rectangle);
			SGPDFAction(const SGPDFDestination& destination, const UXRect& rectangle);
			SGPDFAction(const SGPDFDestination& destination, const std::wstring& URI, const UXRect& rectangle);
			SGPDFAction(const std::wstring& URI, const UXRect& rectangle);
			SGPDFAction(const std::wstring& URI, const std::vector<UXRect>& rectangles);
			~SGPDFAction(void);

			SGPDFAction(void) = delete;
			SGPDFAction(const SGPDFAction&) = default;
			SGPDFAction& operator=(const SGPDFAction&) = default;
			SGPDFAction& operator=(SGPDFAction&&) = default;
			SGPDFAction(SGPDFAction&&) = default;

			SGPDFActionType Type(void) const;
			const SGPDFDestination* Destination(void) const;
			const std::vector<UXRect>& Rectangles(void) const;
			const std::wstring& URI(void) const;

			bool Contains(const UXPoint& point) const;

			void Description(void) const;
	};
}
