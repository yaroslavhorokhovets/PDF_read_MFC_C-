//
//	SGPDFToolbarItem.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFToolbarItem.hpp"

using namespace nsSGPDF;

//
//	Constants
//

static const wchar_t* kWindowClassName = L"SGPDFToolbarItemClass";

//
//	SGPDFToolbarItem methods
//

nsSGPDF::SGPDFToolbarItem::SGPDFToolbarItem(const int id)
{
	//WriteLogFile(L"%S 0x%p %i\n", __FUNCSIG__, this, id);

	m_ItemID = id; RegisterMessages();
}

nsSGPDF::SGPDFToolbarItem::~SGPDFToolbarItem(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_WindowHandle = nullptr; m_ParentWindow = nullptr; m_TooltipPane = nullptr; m_Icon = nullptr;

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

ATOM nsSGPDF::SGPDFToolbarItem::DoRegisterWindowClass(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	WNDCLASSEXW wcex; RtlSecureZeroMemory(&wcex, sizeof(wcex));

	wcex.hInstance = hModule;
	wcex.lpszClassName = kWindowClassName;
	wcex.style = 0; wcex.lpszMenuName = nullptr;
	wcex.lpfnWndProc = SGPDFToolbarItem::WindowDispatch;
	wcex.hIcon = nullptr; wcex.hIconSm = nullptr; wcex.hbrBackground = nullptr;
	wcex.hCursor = SGPDFSupport::ArrowCursor();
	wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
	wcex.cbSize = sizeof(WNDCLASSEXW);

	return RegisterClassExW(&wcex);
}

BOOL nsSGPDF::SGPDFToolbarItem::UnRegisterWindowClass(const HMODULE hModule)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hModule);

	return UnregisterClassW(kWindowClassName, hModule);
}

LRESULT CALLBACK nsSGPDF::SGPDFToolbarItem::WindowDispatch(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WMLog(hWnd, message, wParam, lParam);

	if (message == WM_NCCREATE) SetWindowLongPtrW(hWnd, GWLP_USERDATA, LONG_PTR((LPCREATESTRUCT(lParam))->lpCreateParams));

	SGPDFToolbarItem *thisWindow = reinterpret_cast<SGPDFToolbarItem *>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));

	if (thisWindow != nullptr)
		return thisWindow->WindowProcedure(hWnd, message, wParam, lParam);
	else
		return DefWindowProcW(hWnd, message, wParam, lParam);
}

LRESULT nsSGPDF::SGPDFToolbarItem::WindowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WMLog(hWnd, message, wParam, lParam);

	auto entry = m_MessageMap.find(message);

	if (entry == m_MessageMap.end())
		return DefWindowProcW(hWnd, message, wParam, lParam);
	else
		return entry->second(hWnd, message, wParam, lParam);
}

bool nsSGPDF::SGPDFToolbarItem::Create(const HWND hParent, const int x, const int y, const int w, const int h)
{
	//WriteLogFile(L"%S 0x%p %i %i %i %i\n", __FUNCSIG__, hParent, x, y, w, h);

	const DWORD ws = (WS_CHILD | WS_VISIBLE | WS_DISABLED); const DWORD es = (WS_EX_NOPARENTNOTIFY); // Window style

	const HWND hWnd = CreateWindowExW(es, kWindowClassName, nullptr, ws, x, y, w, h, hParent, HMENU(this), SGPDFSupport::Module(), this);

	if (hWnd == nullptr) { const DWORD ec = GetLastError(); DBLog(L"%S Unable to create window (%lu).\n", __FUNCSIG__, ec); }

	return (hWnd != nullptr);
}

void nsSGPDF::SGPDFToolbarItem::Destroy(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	DestroyWindow(m_WindowHandle);
}

void nsSGPDF::SGPDFToolbarItem::UpdateXYWH(const int x, const int y, const int w, const int h)
{
	//WriteLogFile(L"%S %i %i %i %i\n", __FUNCSIG__, x, y, w, h);

	SetWindowPos(m_WindowHandle, nullptr, x, y, w, h, (SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOZORDER));

	RedrawWindow(m_WindowHandle, nullptr, nullptr, (RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN)); // !!!
}

void nsSGPDF::SGPDFToolbarItem::UpdateWH(const int w, const int h)
{
	//WriteLogFile(L"%S %i %i\n", __FUNCSIG__, w, h);

	SetWindowPos(m_WindowHandle, nullptr, 0, 0, w, h, (SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOMOVE | SWP_NOZORDER));

	RedrawWindow(m_WindowHandle, nullptr, nullptr, (RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN)); // !!!
}

//
//	Window message methods
//

void nsSGPDF::SGPDFToolbarItem::RegisterMessages(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	m_MessageMap.emplace(WM_CREATE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowCreate(h, m, w, l); });
	m_MessageMap.emplace(WM_SIZE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowSize(h, m, w, l); });
	m_MessageMap.emplace(WM_ERASEBKGND, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowErase(h, m, w, l); });
	m_MessageMap.emplace(WM_PAINT, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->WindowPaint(h, m, w, l); });
	m_MessageMap.emplace(WM_MOUSEMOVE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->MouseMove(h, m, w, l); });
	m_MessageMap.emplace(WM_MOUSELEAVE, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->MouseLeave(h, m, w, l); });
	m_MessageMap.emplace(WM_LBUTTONDOWN, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->MouseDown(h, m, w, l); });
	m_MessageMap.emplace(WM_LBUTTONUP, [this](HWND h, UINT m, WPARAM w, LPARAM l) { return this->MouseLift(h, m, w, l); });
}

LRESULT nsSGPDF::SGPDFToolbarItem::WindowCreate(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	//CREATESTRUCTW *cs = reinterpret_cast<CREATESTRUCTW *>(lParam);

	m_WindowHandle = hWnd; m_ParentWindow = GetParent(hWnd); AddItemTooltip(hWnd);

	m_HighlightInset = MulDiv(2, SGPDFSupport::DPI(hWnd), 96); GetClientRect(hWnd, &m_HighlightArea);

	InflateRect(&m_HighlightArea, -m_HighlightInset, -m_HighlightInset);

	if (const HDC hDC = GetDC(hWnd))
	{
		m_Icon = SGPDFResource::Icon(hDC, m_ItemID, 20, 20); ReleaseDC(hWnd, hDC);
	}

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::WindowSize(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	//const int cw = LOWORD(lParam); const int ch = HIWORD(lParam);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::WindowErase(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::WindowPaint(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	PAINTSTRUCT ps {}; HDC hDC = BeginPaint(hWnd, &ps);

	if (IsRectEmpty(&ps.rcPaint) == FALSE) // Paint the requested area
	{
		RECT area; GetClientRect(hWnd, &area); const int cx = 0; const int cy = 0;
		const int cw = (area.right - area.left); const int ch = (area.bottom - area.top);

		FillRect(hDC, &area, SGPDFSupport::ToolbarPaneBackgroundBrush());

		if (m_MouseDown == true)
			FillRect(hDC, &m_HighlightArea, SGPDFSupport::ToolbarItemSelectedBrush());
		else if (m_TrackingMouse == true)
			FillRect(hDC, &m_HighlightArea, SGPDFSupport::ToolbarItemHighlightBrush());

		if (m_Icon != nullptr) // Draw icon
		{
			if (const HDC memDC = CreateCompatibleDC(hDC))
			{
				BITMAP bm; RtlSecureZeroMemory(&bm, sizeof(bm));

				if (GetObjectW(m_Icon, sizeof(bm), &bm) != 0) // Blit
				{
					const int iw = bm.bmWidth; const int ix = ((cw - iw) / 2);
					const int ih = bm.bmHeight; const int iy = ((ch - ih) / 2);

					const BYTE alpha = (IsWindowEnabled(hWnd) ? 255 : 95);
					const HGDIOBJ oldObject = SelectObject(memDC, m_Icon);
					BLENDFUNCTION bf = {AC_SRC_OVER, 0, alpha, AC_SRC_ALPHA};
					GdiAlphaBlend(hDC, ix, iy, iw, ih, memDC, cx, cy, iw, ih, bf);
					SelectObject(memDC, oldObject); DeleteDC(memDC);
				}
			}
		}
	}

	EndPaint(hWnd, &ps);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::MouseMove(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	if (m_TrackingMouse == false) { TrackMouse(hWnd); RedrawItem(hWnd); }

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::MouseLeave(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	m_TrackingMouse = m_MouseDown = false; RedrawItem(hWnd);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::MouseDown(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	m_MouseDown = true; RedrawItem(hWnd);

	return 0;
}

LRESULT nsSGPDF::SGPDFToolbarItem::MouseLift(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//WriteLogFile(L"%S 0x%p 0x%p 0x%p\n", __FUNCSIG__, hWnd, wParam, lParam);

	m_MouseDown = false; RedrawItem(hWnd);

	if (fn_ItemClicked) fn_ItemClicked(m_ItemID);

	return 0;
}

//
//	Support methods
//

void nsSGPDF::SGPDFToolbarItem::RedrawItem(const HWND hWnd)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hWnd);

	InvalidateRect(hWnd, nullptr, FALSE);
}

void nsSGPDF::SGPDFToolbarItem::AddItemTooltip(const HWND hWnd)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hWnd);

	const HMODULE hModule = SGPDFSupport::Module();

	const DWORD ws = (WS_POPUP | TTS_NOPREFIX); const DWORD es = (WS_EX_TOPMOST);

	if (m_TooltipPane = CreateWindowExW(es, TOOLTIPS_CLASSW, nullptr, ws, 0, 0, 0, 0, hWnd, nullptr, hModule, nullptr))
	{
		SetWindowPos(m_TooltipPane, HWND_TOPMOST, 0, 0, 0, 0, (SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE));

		TOOLINFOW ti; RtlSecureZeroMemory(&ti, sizeof(ti)); ti.cbSize = sizeof(ti); ti.uFlags = TTF_SUBCLASS;
		ti.hwnd = hWnd; ti.lpszText = LPWSTR(SGPDFResource::String(m_ItemID)); GetClientRect(hWnd, &ti.rect);

		SendMessageW(m_TooltipPane, TTM_ADDTOOL, 0, LPARAM(&ti));
	}
}

void nsSGPDF::SGPDFToolbarItem::TrackMouse(const HWND hWnd)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hWnd);

	m_MouseDown = ((GetKeyState(VK_LBUTTON) & 0x8000) ? true : false);

	TRACKMOUSEEVENT tme; tme.cbSize = sizeof(tme); tme.hwndTrack = hWnd;

	tme.dwHoverTime = HOVER_DEFAULT; tme.dwFlags = TME_LEAVE;

	m_TrackingMouse = TrackMouseEvent(&tme);
}

void nsSGPDF::SGPDFToolbarItem::ItemClicked(std::function<void(int)> itemClicked)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, itemClicked);

	fn_ItemClicked = itemClicked;
}

void nsSGPDF::SGPDFToolbarItem::Enable(const bool enable)
{
	//WriteLogFile(L"%S %i\n", __FUNCSIG__, enable);

	const HWND hWnd = m_WindowHandle;

	if ((IsWindowEnabled(hWnd) ? true : false) != enable)
	{
		if (enable == false) m_TrackingMouse = m_MouseDown = false;

		EnableWindow(hWnd, enable); RedrawItem(hWnd);
	}
}
