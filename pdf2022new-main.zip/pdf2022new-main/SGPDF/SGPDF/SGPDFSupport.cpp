//
//	SGPDFSupport.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFSupport.hpp"
#include "SGPDFLibrary.hpp"

using namespace nsSGPDF;

//
//	SGPDFSupport methods
//

nsSGPDF::SGPDFSupport::SGPDFSupport(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	m_WaitCursor = LoadCursorW(nullptr, IDC_WAIT);
	m_ArrowCursor = LoadCursorW(nullptr, IDC_ARROW);
	m_PointCursor = LoadCursorW(nullptr, IDC_HAND);
	m_BusyCursor = LoadCursorW(nullptr, IDC_APPSTARTING);

	m_PaneSeparatorLineBrush = CreateSolidBrush(0x00B0B0B0);
	m_TestPaneBackgroundBrush = CreateSolidBrush(0x00E8E8E8);
	m_StatusPaneBackgroundBrush = CreateSolidBrush(0x00F8F8F8);
	m_ToolbarPaneBackgroundBrush = CreateSolidBrush(0x00F8F8F8);
	m_ToolbarItemHighlightBrush = CreateSolidBrush(0x00E2E2E2);
	m_ToolbarItemSelectedBrush = CreateSolidBrush(0x00DADADA);
	m_DocumentBackgroundBrush = CreateSolidBrush(0x00484848);
	m_EditControlFillBrush = CreateSolidBrush(0x00FFFFFF);
	m_EditControlLineBrush = CreateSolidBrush(0x00D0D0D0);
}

nsSGPDF::SGPDFSupport::~SGPDFSupport(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	if (m_PaneSeparatorLineBrush != nullptr)
	{
		DeleteObject(m_PaneSeparatorLineBrush);
	}

	if (m_TestPaneBackgroundBrush != nullptr)
	{
		DeleteObject(m_TestPaneBackgroundBrush);
	}

	if (m_StatusPaneBackgroundBrush != nullptr)
	{
		DeleteObject(m_StatusPaneBackgroundBrush);
	}

	if (m_ToolbarPaneBackgroundBrush != nullptr)
	{
		DeleteObject(m_ToolbarPaneBackgroundBrush);
	}

	if (m_ToolbarItemHighlightBrush != nullptr)
	{
		DeleteObject(m_ToolbarItemHighlightBrush);
	}

	if (m_ToolbarItemSelectedBrush != nullptr)
	{
		DeleteObject(m_ToolbarItemSelectedBrush);
	}

	if (m_DocumentBackgroundBrush != nullptr)
	{
		DeleteObject(m_DocumentBackgroundBrush);
	}

	if (m_EditControlFillBrush != nullptr)
	{
		DeleteObject(m_EditControlFillBrush);
	}

	if (m_EditControlLineBrush != nullptr)
	{
		DeleteObject(m_EditControlLineBrush);
	}

	if (m_WaitCursor != nullptr) DeleteObject(m_WaitCursor);
	if (m_ArrowCursor != nullptr) DeleteObject(m_ArrowCursor);
	if (m_PointCursor != nullptr) DeleteObject(m_PointCursor);
	if (m_BusyCursor != nullptr) DeleteObject(m_BusyCursor);

	if (m_SystemFont != nullptr) DeleteObject(m_SystemFont);

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

HMODULE nsSGPDF::SGPDFSupport::Module(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return SGPDFLibrary::Module();
}

//
//	User interface methods
//

int nsSGPDF::SGPDFSupport::UIS(const int dpi)
{
	//WriteLogFile(L"%S %i\n", __FUNCSIG__, dpi);

	return MulDiv(100, dpi, 96);
}

int nsSGPDF::SGPDFSupport::DPI(const HWND hWnd)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hWnd);

	int dpi = 96; // Default DPI

	if (const HDC hDC = GetDC(hWnd))
	{
		dpi = GetDeviceCaps(hDC, LOGPIXELSX);

		ReleaseDC(hWnd, hDC);
	}

	return dpi;
}

//
//	String methods
//

std::wstring nsSGPDF::SGPDFSupport::UTF16(const std::string &utf8)
{
	//WriteLogFile(L"%S '%S'\n", __FUNCSIG__, utf8.data());

	std::wstring utf16;

	if (utf8.empty() == false) // Convert UTF8 string to UTF16 string
	{
		if (const int size = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), int(utf8.size()), LPWSTR(utf16.data()), int(utf16.size())))
		{
			utf16.resize(size, 0); MultiByteToWideChar(CP_UTF8, 0, utf8.data(), int(utf8.size()), LPWSTR(utf16.data()), int(utf16.size()));
		}
	}

	//WriteLogFile(L"%S '%s'\n", __FUNCSIG__, utf16.data());

	return utf16;
}

std::string nsSGPDF::SGPDFSupport::UTF8(const std::wstring& utf16)
{
	//WriteLogFile(L"%S '%s'\n", __FUNCSIG__, utf16.data());

	std::string utf8;

	if (utf16.empty() == false) // Convert UTF16 string to UTF8 string
	{
		if (const int size = WideCharToMultiByte(CP_UTF8, 0, utf16.data(), int(utf16.size()), LPSTR(utf8.data()), int(utf8.size()), nullptr, nullptr))
		{
			utf8.resize(size, 0); WideCharToMultiByte(CP_UTF8, 0, utf16.data(), int(utf16.size()), LPSTR(utf8.data()), int(utf8.size()), nullptr, nullptr);
		}
	}

	//WriteLogFile(L"%S '%S'\n", __FUNCSIG__, utf8.data());

	return utf8;
}

//
//	Color methods
//

HBRUSH nsSGPDF::SGPDFSupport::PaneSeparatorLineBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_PaneSeparatorLineBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::TestPaneBackgroundBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_TestPaneBackgroundBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::StatusPaneBackgroundBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_StatusPaneBackgroundBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::ToolbarPaneBackgroundBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_ToolbarPaneBackgroundBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::ToolbarItemHighlightBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_ToolbarItemHighlightBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::ToolbarItemSelectedBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_ToolbarItemSelectedBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::DocumentBackgroundBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_DocumentBackgroundBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::EditControlFillBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_EditControlFillBrush;
}

HBRUSH nsSGPDF::SGPDFSupport::EditControlLineBrush(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_EditControlLineBrush;
}

//
//	Cursor methods
//

HCURSOR nsSGPDF::SGPDFSupport::WaitCursor(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_WaitCursor;
}

HCURSOR nsSGPDF::SGPDFSupport::ArrowCursor(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_ArrowCursor;
}

HCURSOR nsSGPDF::SGPDFSupport::PointCursor(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_PointCursor;
}

HCURSOR nsSGPDF::SGPDFSupport::BusyCursor(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.m_BusyCursor;
}

//
//	Font methods
//

HGDIOBJ nsSGPDF::SGPDFSupport::GetSystemFont(const HWND hWnd)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hWnd);

	const int fontSize = 9; const int PPI = 72;

	NONCLIENTMETRICS ncm {}; ncm.cbSize = sizeof(NONCLIENTMETRICS);

	if (SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, ncm.cbSize, &ncm, 0))
	{
		ncm.lfMessageFont.lfHeight = -MulDiv(fontSize, DPI(hWnd), PPI);

		m_SystemFont = CreateFontIndirectW(&ncm.lfMessageFont);
	}
	else // Use default font
	{
		m_SystemFont = GetStockObject(DEFAULT_GUI_FONT);
	}

	return m_SystemFont;
}

HGDIOBJ nsSGPDF::SGPDFSupport::SystemFont(const HWND hWnd)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, hWnd);

	SGPDFSupport& Instance = SGPDFSupport::Instance();

	return Instance.GetSystemFont(hWnd);
}
