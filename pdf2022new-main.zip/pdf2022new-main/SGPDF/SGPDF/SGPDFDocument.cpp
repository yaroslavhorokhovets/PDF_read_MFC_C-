//
//	SGPDFDocument.cpp
//	SGPDF v0.1
//
//	Copyright �2022 Secured Globe, Inc.. All rights reserved.
//

#include "pch.h"
#include "stdafx.hpp"
#include "SGPDFDocument.hpp"
#include "SGPDFDocumentPage.hpp"
#include "SGPDFDataSource.hpp"

using namespace nsSGPDF;

//
//	Constants
//

constexpr int m_MinimumPage = 0;

//
//	SGPDFDocument methods
//

nsSGPDF::SGPDFDocument::SGPDFDocument(const wchar_t *filePath)
{
	//WriteLogFile(L"%S 0x%p '%s'\n", __FUNCSIG__, this, filePath);

	if (filePath != nullptr) m_DocumentFile.assign(filePath);
	int error = 0;
}

nsSGPDF::SGPDFDocument::SGPDFDocument(const void *const data, const size_t size)
{
	//WriteLogFile(L"%S 0x%p 0x%p %Iu\n", __FUNCSIG__, this, data, size);

	if ((data != nullptr) && (size > 0)) // Make a copy of the document data
	{
		m_DocumentData.resize(size); memcpy(m_DocumentData.data(), data, size);
	}
}

nsSGPDF::SGPDFDocument::SGPDFDocument(const std::shared_ptr<SGPDFDataSource>& source)
{
	//WriteLogFile(L"%S 0x%p 0x%p\n", __FUNCSIG__, this, source.get());

	m_DataSource = source;
}

nsSGPDF::SGPDFDocument::~SGPDFDocument(void)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	SGPDFSupport& support = SGPDFSupport::Instance();
	{
		std::lock_guard<std::mutex> lockGuard(support.Mutex);

		m_DocumentPages.clear(); m_PageSizes.clear(); m_PageLabels.clear();

		if (m_pdfDocument != nullptr) { FPDF_CloseDocument(m_pdfDocument); m_pdfDocument = nullptr; }
	}

	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);
}

bool nsSGPDF::SGPDFDocument::operator==(const SGPDFDocument& rhs)
{
	//WriteLogFile(L"%S 0x%p\n", __FUNCSIG__, this);

	if (m_DocumentFile.empty() || rhs.m_DocumentFile.empty()) return false;

	return (m_DocumentFile == rhs.m_DocumentFile);
}

int nsSGPDF::SGPDFDocument::GetDataBlock(void *self, unsigned long offset, unsigned char *buffer, unsigned long size)
{
	//WriteLogFile(L"%S 0x%p %lu 0x%p %lu\n", __FUNCSIG__, self, offset, buffer, size);

	const SGPDFDocument *document = static_cast<const SGPDFDocument *>(self);

	return document->m_DataSource->GetDataBlock(offset, size, buffer);
}

bool nsSGPDF::SGPDFDocument::IsOpen(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return (m_pdfDocument != nullptr);
}

bool nsSGPDF::SGPDFDocument::OpenWithPassword(const wchar_t *password, int& errorCode)
{
	//WriteLogFile(L"%S '%s'\n", __FUNCSIG__, password);

	SGPDFSupport& support = SGPDFSupport::Instance();
	{
		std::lock_guard<std::mutex> lockGuard(support.Mutex);

		if (m_pdfDocument == nullptr)
		{
			errorCode = 0;

			std::string phrase;

			if (password != nullptr)
			{
				phrase = SGPDFSupport::UTF8(password);
			}

			if (m_DocumentFile.empty() == false) // Open file
			{
				std::string filePath = SGPDFSupport::UTF8(m_DocumentFile);

				m_pdfDocument = FPDF_LoadDocument(filePath.c_str(), phrase.c_str());
			}
			else if (m_DocumentData.empty() == false) // Open memory
			{
				const uint8_t *data = m_DocumentData.data(); const size_t size = m_DocumentData.size();

				m_pdfDocument = FPDF_LoadMemDocument(static_cast<const void *>(data), int(size), phrase.c_str());
			}
			else if (m_DataSource != nullptr) // Open data source
			{
				FPDF_FILEACCESS fileAccess; RtlSecureZeroMemory(&fileAccess, sizeof(fileAccess));
				fileAccess.m_GetBlock = &SGPDFDocument::GetDataBlock; fileAccess.m_Param = this;
				fileAccess.m_FileLen = static_cast<unsigned long>(m_DataSource->DataLength());

				m_pdfDocument = FPDF_LoadCustomDocument(&fileAccess, phrase.c_str());
			}
			else // None of the above
			{
				return false;
			}

			if (m_pdfDocument != nullptr) // Opened
			{
				m_PageCount = FPDF_GetPageCount(m_pdfDocument);

				m_MaximumPage = (m_PageCount - 1); // Convenience

				m_PageSizes.reserve(m_PageCount); // Pre-allocate

				for (int index = 0; index < m_PageCount; ++index)
				{
					double w = 0.0; double h = 0.0; // Page size in points (1/72")

					if (FPDF_GetPageSizeByIndex(m_pdfDocument, index, &w, &h) != FALSE)
						m_PageSizes.emplace_back(ceil(w), ceil(h));
					else
						m_PageSizes.emplace_back(612.0f, 792.0f);
				}
			}
			else // Return error
			{
				errorCode = FPDF_GetLastError();
			}
		}
	}

	return (m_pdfDocument != nullptr);
}

FPDF_DOCUMENT nsSGPDF::SGPDFDocument::pdfDocument(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_pdfDocument;
}

int nsSGPDF::SGPDFDocument::PageCount(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_PageCount;
}

bool nsSGPDF::SGPDFDocument::IsValidPageIndex(const int index) const
{
	//WriteLogFile(L"%S %i\n", __FUNCSIG__, index);

	return ((index >= m_MinimumPage) && (index <= m_MaximumPage));
}

int nsSGPDF::SGPDFDocument::MinimumPage(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_MinimumPage;
}

int nsSGPDF::SGPDFDocument::MaximumPage(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return m_MaximumPage;
}

const UXPageSize& nsSGPDF::SGPDFDocument::PageSize(const int index) const
{
	//WriteLogFile(L"%S %i\n", __FUNCSIG__, index);

	return m_PageSizes.at(index);
}

std::shared_ptr<SGPDFDocumentPage> nsSGPDF::SGPDFDocument::DocumentPage(const int index)
{
	//WriteLogFile(L"%S %i\n", __FUNCSIG__, index);

	std::shared_ptr<SGPDFDocumentPage> documentPage;

	SGPDFSupport& support = SGPDFSupport::Instance();
	{
		std::lock_guard<std::mutex> lockGuard(support.Mutex);

		if (m_pdfDocument != nullptr) // Document is open
		{
			const auto it = m_DocumentPages.find(index); // Lookup

			if (it == m_DocumentPages.end()) // Create SGPDFDocumentPage
			{
				documentPage = std::make_shared<SGPDFDocumentPage>(index, this);

				if (documentPage->IsOpen() == true)
					m_DocumentPages.emplace(index, documentPage);
				else
					documentPage = nullptr;
			}
			else // Existing SGPDFDocumentPage
			{
				documentPage = it->second;
			}
		}
	}

	return documentPage;
}

void nsSGPDF::SGPDFDocument::EnumerateCachedPages(std::function<void(int, const std::shared_ptr<SGPDFDocumentPage>&)> fn)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	for (auto it : m_DocumentPages) fn(it.first, it.second);
}

std::wstring nsSGPDF::SGPDFDocument::PageLabel(const int index)
{
	//WriteLogFile(L"%S %i\n", __FUNCSIG__, index);

	std::wstring pageLabel; // Label for page index

	SGPDFSupport& support = SGPDFSupport::Instance();
	{
		std::lock_guard<std::mutex> lockGuard(support.Mutex);

		if (m_pdfDocument != nullptr) // Document is open
		{
			const auto it = m_PageLabels.find(index); // Lookup

			if (it == m_PageLabels.end()) // Extract page label from document
			{
				if (const int bytes = int(FPDF_GetPageLabel(m_pdfDocument, index, nullptr, 0)))
				{
					pageLabel.resize(bytes / sizeof(wchar_t)); void *buffer = &pageLabel[0];

					if (FPDF_GetPageLabel(m_pdfDocument, index, buffer, bytes))
					{
						pageLabel.resize(pageLabel.size() - 1); // Trim NUL

						m_PageLabels.emplace(index, pageLabel);
					}
				}
				else // No page label - return page number
				{
					pageLabel = std::to_wstring(index + 1);

					m_PageLabels.emplace(index, pageLabel);
				}
			}
			else // Existing page label
			{
				pageLabel = it->second;
			}
		}
	}

	return pageLabel;
}

const std::wstring& nsSGPDF::SGPDFDocument::Title(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	if (m_DocumentTitle.empty() == true)
	{
		if (m_DocumentFile.empty() == false)
		{
			wchar_t filePath[MAX_PATH] {}; // Ick

			wcscpy_s(filePath, m_DocumentFile.data());

			PathStripPathW(filePath); PathRemoveExtensionW(filePath);

			m_DocumentTitle.assign(filePath);
		}
		else // Default name
		{
			m_DocumentTitle.assign(L"noname");
		}
	}

	return m_DocumentTitle;
}

bool nsSGPDF::SGPDFDocument::ConserveMemory(void) const
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	return true;
}

void nsSGPDF::SGPDFDocument::HexDump(void)
{
	//WriteLogFile(L"%S\n", __FUNCSIG__);

	HANDLE fh = CreateFileW(m_DocumentFile.data(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (fh != INVALID_HANDLE_VALUE) // Read file into memory
	{
		DWORD fileSize = GetFileSize(fh, nullptr); DWORD bytesRead = 0;

		if ((fileSize != INVALID_FILE_SIZE) && (fileSize > 0))
		{
			if (void *documentData = malloc(fileSize))
			{
				if (ReadFile(fh, documentData, fileSize, &bytesRead, nullptr) != FALSE)
				{
					HexCode(documentData, bytesRead);
				}

				free(documentData);
			}
		}

		CloseHandle(fh);
	}
}

void nsSGPDF::SGPDFDocument::HexCode(const void *data, const size_t size)
{
	//WriteLogFile(L"%S 0x%p %i\n", __FUNCSIG__, data, size);

	if ((data != nullptr) && (size > 0)) // Hex dump data size
	{
		const unsigned char *ptr = reinterpret_cast<const unsigned char *>(data);

		size_t count = size; int offset = 0; const int bpr = 16; wchar_t text[256];

		std::wstring ws_ptr; std::wstring ws_hex; std::wstring ws_ascii;

		swprintf_s(text, 256, L"\nstatic size_t pdfSize = %zu;\n", size);

		OutputDebugStringW(text);

		OutputDebugStringW(L"\nstatic uint8_t pdfData[] =\n{\n");

		while (count > 0) // Hex dump loop
		{
			if (offset == 0) // Start new row
			{
				ws_hex.clear(); ws_ascii.clear();
			}

			const unsigned char byte = *ptr; // Get data byte

			swprintf_s(text, 256, L"0x%02X, ", byte); ws_hex.append(text);

			count--; offset++; ptr++;

			if (offset >= bpr) // Output full row
			{
				OutputDebugStringW(ws_hex.data()); OutputDebugStringW(L"\n");

				offset = 0;
			}
		}

		if (offset > 0) // Output final row
		{
			OutputDebugStringW(ws_hex.data());
		}

		OutputDebugStringW(L"\n};\n\n/*\n");
	}
}
