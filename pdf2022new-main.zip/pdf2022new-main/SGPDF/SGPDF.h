#pragma once

#include <iostream>
#include <memory>

#include "SGPDF/stdafx.hpp"
#include "SGPDF/SGPDFLibrary.hpp"
#include "SGPDF/SGPDFDocumentView.hpp"
#include "SGPDF/SGPDFDocument.hpp"

// SGPDFDlg

using namespace nsSGPDF;

class SGPDFDlg : public CWnd
{
	DECLARE_DYNAMIC(SGPDFDlg)

public:
	SGPDFDlg();
	void SetFile(const wchar_t* path);

	virtual ~SGPDFDlg();
	BOOL RegisterWindowClass();

	BOOL Create(LPCTSTR lpszClassName, DWORD dwStyle, CWnd* pParentWnd, UINT nID);

protected:
	std::shared_ptr<SGPDFDocument> doc;
	std::unique_ptr<SGPDFDocumentView> view;
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


