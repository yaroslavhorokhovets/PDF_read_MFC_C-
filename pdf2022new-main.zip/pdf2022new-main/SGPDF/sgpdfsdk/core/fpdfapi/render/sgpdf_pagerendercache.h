// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_PAGERENDERCACHE_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_PAGERENDERCACHE_H_

#include <map>
#include <memory>

#include "core/fpdfapi/page/sgpdf_page.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/maybe_owned.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Image;
class CSGPDF_SDK_ImageCacheEntry;
class CSGPDF_SDK_Page;
class CSGPDF_SDK_RenderStatus;
class CSGPDF_SDK_Stream;
class PauseIndicatorIface;

class CSGPDF_SDK_PageRenderCache : public CSGPDF_SDK_Page::RenderCacheIface {
 public:
  explicit CSGPDF_SDK_PageRenderCache(CSGPDF_SDK_Page* pPage);
  ~CSGPDF_SDK_PageRenderCache() override;

  // CSGPDF_SDK_Page::RenderCacheIface:
  void ResetBitmapForImage(const RetainPtr<CSGPDF_SDK_Image>& pImage) override;

  void CacheOptimization(int32_t dwLimitCacheSize);
  uint32_t GetTimeCount() const { return m_nTimeCount; }
  CSGPDF_SDK_Page* GetPage() const { return m_pPage.Get(); }
  CSGPDF_SDK_ImageCacheEntry* GetCurImageCacheEntry() const {
    return m_pCurImageCacheEntry.Get();
  }

  bool StartGetCachedBitmap(const RetainPtr<CSGPDF_SDK_Image>& pImage,
                            const CSGPDF_SDK_RenderStatus* pRenderStatus,
                            bool bStdCS);

  bool Continue(PauseIndicatorIface* pPause, CSGPDF_SDK_RenderStatus* pRenderStatus);

 private:
  void ClearImageCacheEntry(CSGPDF_SDK_Stream* pStream);

  UnownedPtr<CSGPDF_SDK_Page> const m_pPage;
  std::map<CSGPDF_SDK_Stream*, std::unique_ptr<CSGPDF_SDK_ImageCacheEntry>> m_ImageCache;
  MaybeOwned<CSGPDF_SDK_ImageCacheEntry> m_pCurImageCacheEntry;
  uint32_t m_nTimeCount = 0;
  uint32_t m_nCacheSize = 0;
  bool m_bCurFindCache = false;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_PAGERENDERCACHE_H_
