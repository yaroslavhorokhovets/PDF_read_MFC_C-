// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_PROGRESSIVERENDERER_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_PROGRESSIVERENDERER_H_

#include <memory>

#include "core/fpdfapi/page/sgpdf_pageobjectholder.h"
#include "core/fpdfapi/render/sgpdf_rendercontext.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_RenderOptions;
class CSGPDF_SDK_RenderStatus;
class CFX_RenderDevice;
class PauseIndicatorIface;

class CSGPDF_SDK_ProgressiveRenderer {
 public:
  // Must match FDF_RENDER_* definitions in public/fpdf_progressive.h, but
  // cannot #include that header. sgpdfsdk/fpdf_progressive.cpp has
  // static_asserts to make sure the two sets of values match.
  enum Status {
    kReady,          // FPDF_RENDER_READY
    kToBeContinued,  // FPDF_RENDER_TOBECONTINUED
    kDone,           // FPDF_RENDER_DONE
    kFailed          // FPDF_RENDER_FAILED
  };

  CSGPDF_SDK_ProgressiveRenderer(CSGPDF_SDK_RenderContext* pContext,
                           CFX_RenderDevice* pDevice,
                           const CSGPDF_SDK_RenderOptions* pOptions);
  ~CSGPDF_SDK_ProgressiveRenderer();

  Status GetStatus() const { return m_Status; }
  void Start(PauseIndicatorIface* pPause);
  void Continue(PauseIndicatorIface* pPause);

 private:
  // Maximum page objects to render before checking for pause.
  static constexpr int kStepLimit = 100;

  Status m_Status = kReady;
  UnownedPtr<CSGPDF_SDK_RenderContext> const m_pContext;
  UnownedPtr<CFX_RenderDevice> const m_pDevice;
  const CSGPDF_SDK_RenderOptions* const m_pOptions;
  std::unique_ptr<CSGPDF_SDK_RenderStatus> m_pRenderStatus;
  CFX_FloatRect m_ClipRect;
  uint32_t m_LayerIndex = 0;
  CSGPDF_SDK_RenderContext::Layer* m_pCurrentLayer = nullptr;
  CSGPDF_SDK_PageObjectHolder::const_iterator m_LastObjectRendered;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_PROGRESSIVERENDERER_H_
