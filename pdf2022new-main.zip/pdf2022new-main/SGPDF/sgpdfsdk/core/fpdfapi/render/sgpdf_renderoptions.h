// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_RENDEROPTIONS_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_RENDEROPTIONS_H_

#include "core/fpdfapi/page/sgpdf_occontext.h"
#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxge/dib/fx_dib.h"

class CSGPDF_SDK_RenderOptions {
 public:
  enum Type : uint8_t { kNormal = 0, kGray, kAlpha, kForcedColor };

  enum RenderType : uint8_t { kFill = 0, kStroke };

  struct Options {
    Options();
    Options(const Options& rhs);

    bool bClearType = false;
    bool bNoNativeText = false;
    bool bForceHalftone = false;
    bool bRectAA = false;
    bool bBreakForMasks = false;
    bool bNoTextSmooth = false;
    bool bNoPathSmooth = false;
    bool bNoImageSmooth = false;
    bool bLimitedImageCache = false;
    bool bConvertFillToStroke = false;
  };

  struct ColorScheme {
    FX_ARGB path_fill_color;
    FX_ARGB path_stroke_color;
    FX_ARGB text_fill_color;
    FX_ARGB text_stroke_color;
  };

  CSGPDF_SDK_RenderOptions();
  CSGPDF_SDK_RenderOptions(const CSGPDF_SDK_RenderOptions& rhs);
  ~CSGPDF_SDK_RenderOptions();

  FX_ARGB TranslateColor(FX_ARGB argb) const;
  FX_ARGB TranslateObjectColor(FX_ARGB argb,
                               CSGPDF_SDK_PageObject::Type object_type,
                               RenderType render_type) const;

  void SetColorScheme(const ColorScheme& color_scheme) {
    m_ColorScheme = color_scheme;
  }

  void SetColorMode(Type mode) { m_ColorMode = mode; }
  bool ColorModeIs(Type mode) const { return m_ColorMode == mode; }

  const Options& GetOptions() const { return m_Options; }
  Options& GetOptions() { return m_Options; }

  uint32_t GetCacheSizeLimit() const;

  void SetDrawAnnots(bool draw) { m_bDrawAnnots = draw; }
  bool GetDrawAnnots() const { return m_bDrawAnnots; }

  void SetOCContext(RetainPtr<CSGPDF_SDK_OCContext> context) {
    m_pOCContext = context;
  }
  const CSGPDF_SDK_OCContext* GetOCContext() const { return m_pOCContext.Get(); }

 private:
  Type m_ColorMode = kNormal;
  bool m_bDrawAnnots = false;
  Options m_Options;
  ColorScheme m_ColorScheme;
  RetainPtr<CSGPDF_SDK_OCContext> m_pOCContext;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_RENDEROPTIONS_H_
