// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/render/sgpdf_imagecacheentry.h"

#include <memory>
#include <utility>

#include "core/fpdfapi/page/sgpdf_dib.h"
#include "core/fpdfapi/page/sgpdf_image.h"
#include "core/fpdfapi/page/sgpdf_page.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/render/sgpdf_pagerendercache.h"
#include "core/fpdfapi/render/sgpdf_rendercontext.h"
#include "core/fpdfapi/render/sgpdf_renderstatus.h"
#include "core/fxge/dib/cfx_dibitmap.h"
#include "third_party/base/check.h"
#include "third_party/base/numerics/safe_conversions.h"

namespace
{

	uint32_t GetEstimatedImageSize(const RetainPtr<CFX_DIBBase>& pDIB)
	{
		if (!pDIB || !pDIB->GetBuffer())
			return 0;

		int height = pDIB->GetHeight();
		DCHECK(pdfium::base::IsValueInRangeForNumericType<uint32_t>(height));
		return static_cast<uint32_t>(height) * pDIB->GetPitch() +
			pDIB->GetPaletteSize() * 4;
	}

}  // namespace

CSGPDF_SDK_ImageCacheEntry::CSGPDF_SDK_ImageCacheEntry(CSGPDF_SDK_Document* pDoc,
	const RetainPtr<CSGPDF_SDK_Image>& pImage)
	: m_pDocument(pDoc), m_pImage(pImage)
{
}

CSGPDF_SDK_ImageCacheEntry::~CSGPDF_SDK_ImageCacheEntry() = default;

void CSGPDF_SDK_ImageCacheEntry::Reset()
{
	m_pCachedBitmap.Reset();
	CalcSize();
}

RetainPtr<CFX_DIBBase> CSGPDF_SDK_ImageCacheEntry::DetachBitmap()
{
	return std::move(m_pCurBitmap);
}

RetainPtr<CFX_DIBBase> CSGPDF_SDK_ImageCacheEntry::DetachMask()
{
	return std::move(m_pCurMask);
}

CSGPDF_SDK_DIB::LoadState CSGPDF_SDK_ImageCacheEntry::StartGetCachedBitmap(
	const CSGPDF_SDK_Dictionary* pPageResources,
	const CSGPDF_SDK_RenderStatus* pRenderStatus,
	bool bStdCS)
{
	if (m_pCachedBitmap)
	{
		m_pCurBitmap = m_pCachedBitmap;
		m_pCurMask = m_pCachedMask;
		return CSGPDF_SDK_DIB::LoadState::kSuccess;
	}

	m_pCurBitmap = pdfium::MakeRetain<CSGPDF_SDK_DIB>();
	CSGPDF_SDK_DIB::LoadState ret = m_pCurBitmap.As<CSGPDF_SDK_DIB>()->StartLoadDIBBase(
		m_pDocument.Get(), m_pImage->GetStream(), true,
		pRenderStatus->GetFormResource(), pPageResources, bStdCS,
		pRenderStatus->GetGroupFamily(), pRenderStatus->GetLoadMask());
	if (ret == CSGPDF_SDK_DIB::LoadState::kContinue)
		return CSGPDF_SDK_DIB::LoadState::kContinue;

	if (ret == CSGPDF_SDK_DIB::LoadState::kSuccess)
		ContinueGetCachedBitmap(pRenderStatus);
	else
		m_pCurBitmap.Reset();
	return CSGPDF_SDK_DIB::LoadState::kFail;
}

bool CSGPDF_SDK_ImageCacheEntry::Continue(PauseIndicatorIface* pPause,
	CSGPDF_SDK_RenderStatus* pRenderStatus)
{
	CSGPDF_SDK_DIB::LoadState ret =
		m_pCurBitmap.As<CSGPDF_SDK_DIB>()->ContinueLoadDIBBase(pPause);
	if (ret == CSGPDF_SDK_DIB::LoadState::kContinue)
		return true;

	if (ret == CSGPDF_SDK_DIB::LoadState::kSuccess)
		ContinueGetCachedBitmap(pRenderStatus);
	else
		m_pCurBitmap.Reset();
	return false;
}

void CSGPDF_SDK_ImageCacheEntry::ContinueGetCachedBitmap(
	const CSGPDF_SDK_RenderStatus* pRenderStatus)
{
	m_MatteColor = m_pCurBitmap.As<CSGPDF_SDK_DIB>()->GetMatteColor();
	m_pCurMask = m_pCurBitmap.As<CSGPDF_SDK_DIB>()->DetachMask();
	CSGPDF_SDK_RenderContext* pContext = pRenderStatus->GetContext();
	CSGPDF_SDK_PageRenderCache* pPageRenderCache = pContext->GetPageCache();
	m_dwTimeCount = pPageRenderCache->GetTimeCount();
	if (m_pCurBitmap->GetPitch() * m_pCurBitmap->GetHeight() < kHugeImageSize)
	{
		m_pCachedBitmap = m_pCurBitmap->Clone(nullptr);
		m_pCurBitmap.Reset();
	}
	else
	{
		m_pCachedBitmap = m_pCurBitmap;
	}
	if (m_pCurMask)
	{
		m_pCachedMask = m_pCurMask->Clone(nullptr);
		m_pCurMask.Reset();
	}
	m_pCurBitmap = m_pCachedBitmap;
	m_pCurMask = m_pCachedMask;
	CalcSize();
}

void CSGPDF_SDK_ImageCacheEntry::CalcSize()
{
	m_dwCacheSize = GetEstimatedImageSize(m_pCachedBitmap) +
		GetEstimatedImageSize(m_pCachedMask);
}
