// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_DEVICEBUFFER_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_DEVICEBUFFER_H_

#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CFX_DIBitmap;
class CFX_RenderDevice;
class CSGPDF_SDK_PageObject;
class CSGPDF_SDK_RenderContext;

class CSGPDF_SDK_DeviceBuffer {
 public:
  static CFX_Matrix CalculateMatrix(CFX_RenderDevice* pDevice,
                                    const FX_RECT& rect,
                                    int max_dpi,
                                    bool scale);

  CSGPDF_SDK_DeviceBuffer(CSGPDF_SDK_RenderContext* pContext,
                    CFX_RenderDevice* pDevice,
                    const FX_RECT& rect,
                    const CSGPDF_SDK_PageObject* pObj,
                    int max_dpi);
  ~CSGPDF_SDK_DeviceBuffer();

  bool Initialize();
  void OutputToDevice();
  RetainPtr<CFX_DIBitmap> GetBitmap() const { return m_pBitmap; }
  const CFX_Matrix& GetMatrix() const { return m_Matrix; }

 private:
  UnownedPtr<CFX_RenderDevice> const m_pDevice;
  UnownedPtr<CSGPDF_SDK_RenderContext> const m_pContext;
  UnownedPtr<const CSGPDF_SDK_PageObject> const m_pObject;
  RetainPtr<CFX_DIBitmap> const m_pBitmap;
  const FX_RECT m_Rect;
  const CFX_Matrix m_Matrix;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_DEVICEBUFFER_H_
