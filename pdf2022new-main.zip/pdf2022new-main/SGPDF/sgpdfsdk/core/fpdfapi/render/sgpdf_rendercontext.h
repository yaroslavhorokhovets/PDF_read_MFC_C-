// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_RENDERCONTEXT_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_RENDERCONTEXT_H_

#include <vector>

#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_PageObject;
class CSGPDF_SDK_PageObjectHolder;
class CSGPDF_SDK_PageRenderCache;
class CSGPDF_SDK_RenderOptions;
class CFX_DIBitmap;
class CFX_Matrix;
class CFX_RenderDevice;

class CSGPDF_SDK_RenderContext {
 public:
  class Layer {
   public:
    Layer();
    Layer(const Layer& that);
    ~Layer();

    UnownedPtr<CSGPDF_SDK_PageObjectHolder> m_pObjectHolder;
    CFX_Matrix m_Matrix;
  };

  CSGPDF_SDK_RenderContext(CSGPDF_SDK_Document* pDoc,
                     CSGPDF_SDK_Dictionary* pPageResources,
                     CSGPDF_SDK_PageRenderCache* pPageCache);
  ~CSGPDF_SDK_RenderContext();

  void AppendLayer(CSGPDF_SDK_PageObjectHolder* pObjectHolder,
                   const CFX_Matrix* pObject2Device);

  void Render(CFX_RenderDevice* pDevice,
              const CSGPDF_SDK_RenderOptions* pOptions,
              const CFX_Matrix* pLastMatrix);

  void Render(CFX_RenderDevice* pDevice,
              const CSGPDF_SDK_PageObject* pStopObj,
              const CSGPDF_SDK_RenderOptions* pOptions,
              const CFX_Matrix* pLastMatrix);

  void GetBackground(const RetainPtr<CFX_DIBitmap>& pBuffer,
                     const CSGPDF_SDK_PageObject* pObj,
                     const CSGPDF_SDK_RenderOptions* pOptions,
                     const CFX_Matrix& mtFinal);

  size_t CountLayers() const { return m_Layers.size(); }
  Layer* GetLayer(uint32_t index) { return &m_Layers[index]; }

  CSGPDF_SDK_Document* GetDocument() const { return m_pDocument.Get(); }
  CSGPDF_SDK_Dictionary* GetPageResources() const { return m_pPageResources.Get(); }
  CSGPDF_SDK_PageRenderCache* GetPageCache() const { return m_pPageCache.Get(); }

 protected:
  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  RetainPtr<CSGPDF_SDK_Dictionary> const m_pPageResources;
  UnownedPtr<CSGPDF_SDK_PageRenderCache> const m_pPageCache;
  std::vector<Layer> m_Layers;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_RENDERCONTEXT_H_
