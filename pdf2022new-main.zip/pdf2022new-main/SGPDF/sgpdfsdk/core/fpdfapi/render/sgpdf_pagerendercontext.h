// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_PAGERENDERCONTEXT_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_PAGERENDERCONTEXT_H_

#include <memory>

#include "core/fpdfapi/page/sgpdf_page.h"

class CFX_RenderDevice;
class CSGPDF_SDK_ProgressiveRenderer;
class CSGPDF_SDK_RenderContext;
class CSGPDF_SDK_RenderOptions;

// Everything about rendering is put here: for OOM recovery
class CSGPDF_SDK_PageRenderContext final : public CSGPDF_SDK_Page::RenderContextIface {
 public:
  // Context merely manages the lifetime for callers.
  class AnnotListIface {
   public:
    virtual ~AnnotListIface() {}
  };

  CSGPDF_SDK_PageRenderContext();
  ~CSGPDF_SDK_PageRenderContext() override;

  // Specific destruction order required.
  std::unique_ptr<AnnotListIface> m_pAnnots;
  std::unique_ptr<CSGPDF_SDK_RenderOptions> m_pOptions;
  std::unique_ptr<CFX_RenderDevice> m_pDevice;
  std::unique_ptr<CSGPDF_SDK_RenderContext> m_pContext;
  std::unique_ptr<CSGPDF_SDK_ProgressiveRenderer> m_pRenderer;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_PAGERENDERCONTEXT_H_
