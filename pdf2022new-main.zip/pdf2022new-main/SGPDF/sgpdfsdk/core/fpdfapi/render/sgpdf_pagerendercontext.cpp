// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/render/sgpdf_pagerendercontext.h"

#include "core/fpdfapi/page/sgpdf_occontext.h"
#include "core/fpdfapi/render/sgpdf_progressiverenderer.h"
#include "core/fpdfapi/render/sgpdf_rendercontext.h"
#include "core/fpdfapi/render/sgpdf_renderoptions.h"
#include "core/fxge/cfx_renderdevice.h"

CSGPDF_SDK_PageRenderContext::CSGPDF_SDK_PageRenderContext() = default;

CSGPDF_SDK_PageRenderContext::~CSGPDF_SDK_PageRenderContext() = default;
