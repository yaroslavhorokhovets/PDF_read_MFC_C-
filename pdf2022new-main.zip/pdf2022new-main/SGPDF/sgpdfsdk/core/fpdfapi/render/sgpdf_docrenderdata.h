// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_DOCRENDERDATA_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_DOCRENDERDATA_H_

#include <map>

#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fxcrt/observed_ptr.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_Font;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_TransferFunc;
class CSGPDF_SDK_Type3Cache;
class CSGPDF_SDK_Type3Font;

class CSGPDF_SDK_DocRenderData : public CSGPDF_SDK_Document::RenderDataIface {
 public:
  static CSGPDF_SDK_DocRenderData* FromDocument(const CSGPDF_SDK_Document* pDoc);

  CSGPDF_SDK_DocRenderData();
  ~CSGPDF_SDK_DocRenderData() override;

  CSGPDF_SDK_DocRenderData(const CSGPDF_SDK_DocRenderData&) = delete;
  CSGPDF_SDK_DocRenderData& operator=(const CSGPDF_SDK_DocRenderData&) = delete;

  RetainPtr<CSGPDF_SDK_Type3Cache> GetCachedType3(CSGPDF_SDK_Type3Font* pFont);
  RetainPtr<CSGPDF_SDK_TransferFunc> GetTransferFunc(const CSGPDF_SDK_Object* pObj);

 protected:
  // protected for use by test subclasses.
  RetainPtr<CSGPDF_SDK_TransferFunc> CreateTransferFunc(
      const CSGPDF_SDK_Object* pObj) const;

 private:
  std::map<CSGPDF_SDK_Font*, ObservedPtr<CSGPDF_SDK_Type3Cache>> m_Type3FaceMap;
  std::map<const CSGPDF_SDK_Object*, ObservedPtr<CSGPDF_SDK_TransferFunc>>
      m_TransferFuncMap;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_DOCRENDERDATA_H_
