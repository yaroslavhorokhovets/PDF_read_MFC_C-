// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/render/sgpdf_rendercontext.h"

#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fpdfapi/page/sgpdf_pageobjectholder.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fpdfapi/render/sgpdf_pagerendercache.h"
#include "core/fpdfapi/render/sgpdf_progressiverenderer.h"
#include "core/fpdfapi/render/sgpdf_renderoptions.h"
#include "core/fpdfapi/render/sgpdf_renderstatus.h"
#include "core/fpdfapi/render/sgpdf_textrenderer.h"
#include "core/fxge/cfx_defaultrenderdevice.h"
#include "core/fxge/cfx_renderdevice.h"
#include "core/fxge/dib/cfx_dibitmap.h"
#include "core/fxge/dib/fx_dib.h"

CSGPDF_SDK_RenderContext::CSGPDF_SDK_RenderContext(CSGPDF_SDK_Document* pDoc,
	CSGPDF_SDK_Dictionary* pPageResources,
	CSGPDF_SDK_PageRenderCache* pPageCache)
	: m_pDocument(pDoc),
	m_pPageResources(pPageResources),
	m_pPageCache(pPageCache)
{
}

CSGPDF_SDK_RenderContext::~CSGPDF_SDK_RenderContext() = default;

void CSGPDF_SDK_RenderContext::GetBackground(const RetainPtr<CFX_DIBitmap>& pBuffer,
	const CSGPDF_SDK_PageObject* pObj,
	const CSGPDF_SDK_RenderOptions* pOptions,
	const CFX_Matrix& mtFinal)
{
	CFX_DefaultRenderDevice device;
	device.Attach(pBuffer, false, nullptr, false);

	device.FillRect(FX_RECT(0, 0, device.GetWidth(), device.GetHeight()),
		0xffffffff);
	Render(&device, pObj, pOptions, &mtFinal);
}

void CSGPDF_SDK_RenderContext::AppendLayer(CSGPDF_SDK_PageObjectHolder* pObjectHolder,
	const CFX_Matrix* pObject2Device)
{
	m_Layers.emplace_back();
	m_Layers.back().m_pObjectHolder = pObjectHolder;
	if (pObject2Device)
		m_Layers.back().m_Matrix = *pObject2Device;
}

void CSGPDF_SDK_RenderContext::Render(CFX_RenderDevice* pDevice,
	const CSGPDF_SDK_RenderOptions* pOptions,
	const CFX_Matrix* pLastMatrix)
{
	Render(pDevice, nullptr, pOptions, pLastMatrix);
}

void CSGPDF_SDK_RenderContext::Render(CFX_RenderDevice* pDevice,
	const CSGPDF_SDK_PageObject* pStopObj,
	const CSGPDF_SDK_RenderOptions* pOptions,
	const CFX_Matrix* pLastMatrix)
{
	for (auto& layer : m_Layers)
	{
		CFX_RenderDevice::StateRestorer restorer(pDevice);
		CSGPDF_SDK_RenderStatus status(this, pDevice);
		if (pOptions)
			status.SetOptions(*pOptions);
		status.SetStopObject(pStopObj);
		status.SetTransparency(layer.m_pObjectHolder->GetTransparency());
		CFX_Matrix final_matrix = layer.m_Matrix;
		if (pLastMatrix)
		{
			final_matrix *= *pLastMatrix;
			status.SetDeviceMatrix(*pLastMatrix);
		}
		status.Initialize(nullptr, nullptr);
		status.RenderObjectList(layer.m_pObjectHolder.Get(), final_matrix);
		if (status.GetRenderOptions().GetOptions().bLimitedImageCache)
		{
			m_pPageCache->CacheOptimization(
				status.GetRenderOptions().GetCacheSizeLimit());
		}
		if (status.IsStopped())
			break;
	}
}

CSGPDF_SDK_RenderContext::Layer::Layer() = default;

CSGPDF_SDK_RenderContext::Layer::Layer(const Layer& that) = default;

CSGPDF_SDK_RenderContext::Layer::~Layer() = default;
