// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/render/sgpdf_renderoptions.h"

namespace
{

	constexpr uint32_t kCacheSizeLimitBytes = 100 * 1024 * 1024;

}  // namespace

CSGPDF_SDK_RenderOptions::Options::Options() = default;

CSGPDF_SDK_RenderOptions::Options::Options(const CSGPDF_SDK_RenderOptions::Options& rhs) =
default;

CSGPDF_SDK_RenderOptions::CSGPDF_SDK_RenderOptions()
{
	// TODO(thestig): Make constexpr to initialize |m_Options| once C++14 is
	// available.
	m_Options.bClearType = true;
}

CSGPDF_SDK_RenderOptions::CSGPDF_SDK_RenderOptions(const CSGPDF_SDK_RenderOptions& rhs) = default;

CSGPDF_SDK_RenderOptions::~CSGPDF_SDK_RenderOptions() = default;

FX_ARGB CSGPDF_SDK_RenderOptions::TranslateColor(FX_ARGB argb) const
{
	if (ColorModeIs(kNormal))
		return argb;
	if (ColorModeIs(kAlpha))
		return argb;

	int a;
	int r;
	int g;
	int b;
	std::tie(a, r, g, b) = ArgbDecode(argb);
	int gray = FXRGB2GRAY(r, g, b);
	return ArgbEncode(a, gray, gray, gray);
}

FX_ARGB CSGPDF_SDK_RenderOptions::TranslateObjectColor(
	FX_ARGB argb,
	CSGPDF_SDK_PageObject::Type object_type,
	RenderType render_type) const
{
	if (!ColorModeIs(kForcedColor))
		return TranslateColor(argb);

	switch (object_type)
	{
		case CSGPDF_SDK_PageObject::Type::PATH:
			return render_type == RenderType::kFill ? m_ColorScheme.path_fill_color
				: m_ColorScheme.path_stroke_color;
		case CSGPDF_SDK_PageObject::Type::TEXT:
			return render_type == RenderType::kFill ? m_ColorScheme.text_fill_color
				: m_ColorScheme.text_stroke_color;
		default:
			return argb;
	}
}

uint32_t CSGPDF_SDK_RenderOptions::GetCacheSizeLimit() const
{
	return kCacheSizeLimitBytes;
}
