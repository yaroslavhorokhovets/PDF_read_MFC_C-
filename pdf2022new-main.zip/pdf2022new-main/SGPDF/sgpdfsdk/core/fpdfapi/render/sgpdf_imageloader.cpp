// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/render/sgpdf_imageloader.h"

#include "core/fpdfapi/page/sgpdf_dib.h"
#include "core/fpdfapi/page/sgpdf_image.h"
#include "core/fpdfapi/page/sgpdf_imageobject.h"
#include "core/fpdfapi/page/sgpdf_transferfunc.h"
#include "core/fpdfapi/render/sgpdf_imagecacheentry.h"
#include "core/fpdfapi/render/sgpdf_pagerendercache.h"
#include "core/fpdfapi/render/sgpdf_rendercontext.h"
#include "core/fpdfapi/render/sgpdf_renderstatus.h"
#include "core/fxge/dib/cfx_dibitmap.h"
#include "third_party/base/check.h"

CSGPDF_SDK_ImageLoader::CSGPDF_SDK_ImageLoader() = default;

CSGPDF_SDK_ImageLoader::~CSGPDF_SDK_ImageLoader() = default;

bool CSGPDF_SDK_ImageLoader::Start(CSGPDF_SDK_ImageObject* pImage,
	const CSGPDF_SDK_RenderStatus* pRenderStatus,
	bool bStdCS)
{
	m_pCache = pRenderStatus->GetContext()->GetPageCache();
	m_pImageObject = pImage;
	bool ret;
	if (m_pCache)
	{
		ret = m_pCache->StartGetCachedBitmap(m_pImageObject->GetImage(),
			pRenderStatus, bStdCS);
	}
	else
	{
		ret = m_pImageObject->GetImage()->StartLoadDIBBase(
			pRenderStatus->GetFormResource(), pRenderStatus->GetPageResource(),
			bStdCS, pRenderStatus->GetGroupFamily(), pRenderStatus->GetLoadMask());
	}
	if (!ret)
		HandleFailure();
	return ret;
}

bool CSGPDF_SDK_ImageLoader::Continue(PauseIndicatorIface* pPause,
	CSGPDF_SDK_RenderStatus* pRenderStatus)
{
	bool ret = m_pCache ? m_pCache->Continue(pPause, pRenderStatus)
		: m_pImageObject->GetImage()->Continue(pPause);
	if (!ret)
		HandleFailure();
	return ret;
}

RetainPtr<CFX_DIBBase> CSGPDF_SDK_ImageLoader::TranslateImage(
	const RetainPtr<CSGPDF_SDK_TransferFunc>& pTransferFunc)
{
	DCHECK(pTransferFunc);
	DCHECK(!pTransferFunc->GetIdentity());

	m_pBitmap = pTransferFunc->TranslateImage(m_pBitmap);
	if (m_bCached && m_pMask)
		m_pMask = m_pMask->Clone(nullptr);
	m_bCached = false;
	return m_pBitmap;
}

void CSGPDF_SDK_ImageLoader::HandleFailure()
{
	if (m_pCache)
	{
		CSGPDF_SDK_ImageCacheEntry* entry = m_pCache->GetCurImageCacheEntry();
		m_bCached = true;
		m_pBitmap = entry->DetachBitmap();
		m_pMask = entry->DetachMask();
		m_MatteColor = entry->m_MatteColor;
		return;
	}
	RetainPtr<CSGPDF_SDK_Image> pImage = m_pImageObject->GetImage();
	m_bCached = false;
	m_pBitmap = pImage->DetachBitmap();
	m_pMask = pImage->DetachMask();
	m_MatteColor = pImage->m_MatteColor;
}
