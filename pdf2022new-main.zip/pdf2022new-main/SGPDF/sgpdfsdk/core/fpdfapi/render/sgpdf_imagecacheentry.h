// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_RENDER_CSGPDF_SDK_IMAGECACHEENTRY_H_
#define CORE_FPDFAPI_RENDER_CSGPDF_SDK_IMAGECACHEENTRY_H_

#include "core/fpdfapi/page/sgpdf_dib.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_Image;
class CSGPDF_SDK_RenderStatus;
class PauseIndicatorIface;

class CSGPDF_SDK_ImageCacheEntry {
 public:
  CSGPDF_SDK_ImageCacheEntry(CSGPDF_SDK_Document* pDoc,
                       const RetainPtr<CSGPDF_SDK_Image>& pImage);
  ~CSGPDF_SDK_ImageCacheEntry();

  void Reset();
  uint32_t EstimateSize() const { return m_dwCacheSize; }
  uint32_t GetTimeCount() const { return m_dwTimeCount; }
  CSGPDF_SDK_Image* GetImage() const { return m_pImage.Get(); }

  CSGPDF_SDK_DIB::LoadState StartGetCachedBitmap(
      const CSGPDF_SDK_Dictionary* pPageResources,
      const CSGPDF_SDK_RenderStatus* pRenderStatus,
      bool bStdCS);

  // Returns whether to Continue() or not.
  bool Continue(PauseIndicatorIface* pPause, CSGPDF_SDK_RenderStatus* pRenderStatus);

  RetainPtr<CFX_DIBBase> DetachBitmap();
  RetainPtr<CFX_DIBBase> DetachMask();

  int m_dwTimeCount = 0;
  uint32_t m_MatteColor = 0;

 private:
  void ContinueGetCachedBitmap(const CSGPDF_SDK_RenderStatus* pRenderStatus);
  void CalcSize();

  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  RetainPtr<CSGPDF_SDK_Image> const m_pImage;
  RetainPtr<CFX_DIBBase> m_pCurBitmap;
  RetainPtr<CFX_DIBBase> m_pCurMask;
  RetainPtr<CFX_DIBBase> m_pCachedBitmap;
  RetainPtr<CFX_DIBBase> m_pCachedMask;
  uint32_t m_dwCacheSize = 0;
};

#endif  // CORE_FPDFAPI_RENDER_CSGPDF_SDK_IMAGECACHEENTRY_H_
