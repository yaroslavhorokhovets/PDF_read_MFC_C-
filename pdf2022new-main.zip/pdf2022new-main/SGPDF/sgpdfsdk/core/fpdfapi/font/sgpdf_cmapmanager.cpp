// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/font/sgpdf_cmapmanager.h"

#include <utility>

#include "core/fpdfapi/font/sgpdf_cid2unicodemap.h"
#include "core/fpdfapi/font/sgpdf_cmap.h"

namespace
{

	RetainPtr<const CSGPDF_SDK_CMap> LoadPredefinedCMap(ByteStringView name)
	{
		if (!name.IsEmpty() && name[0] == '/')
			name = name.Last(name.GetLength() - 1);
		return pdfium::MakeRetain<CSGPDF_SDK_CMap>(name);
	}

}  // namespace

CSGPDF_SDK_CMapManager::CSGPDF_SDK_CMapManager() = default;

CSGPDF_SDK_CMapManager::~CSGPDF_SDK_CMapManager() = default;

RetainPtr<const CSGPDF_SDK_CMap> CSGPDF_SDK_CMapManager::GetPredefinedCMap(
	const ByteString& name)
{
	auto it = m_CMaps.find(name);
	if (it != m_CMaps.end())
		return it->second;

	RetainPtr<const CSGPDF_SDK_CMap> pCMap = LoadPredefinedCMap(name.AsStringView());
	if (!name.IsEmpty())
		m_CMaps[name] = pCMap;

	return pCMap;
}

CSGPDF_SDK_CID2UnicodeMap* CSGPDF_SDK_CMapManager::GetCID2UnicodeMap(CIDSet charset)
{
	if (!m_CID2UnicodeMaps[charset])
	{
		m_CID2UnicodeMaps[charset] = std::make_unique<CSGPDF_SDK_CID2UnicodeMap>(charset);
	}
	return m_CID2UnicodeMaps[charset].get();
}
