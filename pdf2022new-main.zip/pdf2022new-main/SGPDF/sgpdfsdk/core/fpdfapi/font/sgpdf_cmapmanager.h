// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_FONT_CSGPDF_SDK_CMAPMANAGER_H_
#define CORE_FPDFAPI_FONT_CSGPDF_SDK_CMAPMANAGER_H_

#include <map>
#include <memory>

#include "core/fpdfapi/font/sgpdf_cidfont.h"
#include "core/fxcrt/bytestring.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_CMapManager {
 public:
  CSGPDF_SDK_CMapManager();
  ~CSGPDF_SDK_CMapManager();

  RetainPtr<const CSGPDF_SDK_CMap> GetPredefinedCMap(const ByteString& name);
  CSGPDF_SDK_CID2UnicodeMap* GetCID2UnicodeMap(CIDSet charset);

 private:
  std::map<ByteString, RetainPtr<const CSGPDF_SDK_CMap>> m_CMaps;
  std::unique_ptr<CSGPDF_SDK_CID2UnicodeMap> m_CID2UnicodeMaps[CIDSET_NUM_SETS];
};

#endif  // CORE_FPDFAPI_FONT_CSGPDF_SDK_CMAPMANAGER_H_
