// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_FONT_CSGPDF_SDK_FONTGLOBALS_H_
#define CORE_FPDFAPI_FONT_CSGPDF_SDK_FONTGLOBALS_H_

#include <map>
#include <memory>

#include "core/fpdfapi/cmaps/fpdf_cmaps.h"
#include "core/fpdfapi/font/sgpdf_cmapmanager.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxge/cfx_fontmapper.h"
#include "third_party/base/span.h"

class CFX_StockFontArray;

class CSGPDF_SDK_FontGlobals {
 public:
  // Per-process singleton which must be managed by callers.
  static void Create();
  static void Destroy();
  static CSGPDF_SDK_FontGlobals* GetInstance();

  // Caller must load the maps before using font globals.
  void LoadEmbeddedMaps();

  void Clear(CSGPDF_SDK_Document* pDoc);
  RetainPtr<CSGPDF_SDK_Font> Find(CSGPDF_SDK_Document* pDoc,
                            CFX_FontMapper::StandardFont index);
  void Set(CSGPDF_SDK_Document* pDoc,
           CFX_FontMapper::StandardFont index,
           const RetainPtr<CSGPDF_SDK_Font>& pFont);

  void SetEmbeddedCharset(size_t idx, pdfium::span<const FXCMAP_CMap> map) {
    m_EmbeddedCharsets[idx] = map;
  }
  pdfium::span<const FXCMAP_CMap> GetEmbeddedCharset(size_t idx) const {
    return m_EmbeddedCharsets[idx];
  }
  void SetEmbeddedToUnicode(size_t idx, pdfium::span<const uint16_t> map) {
    m_EmbeddedToUnicodes[idx] = map;
  }
  pdfium::span<const uint16_t> GetEmbeddedToUnicode(size_t idx) {
    return m_EmbeddedToUnicodes[idx];
  }

  CSGPDF_SDK_CMapManager* GetCMapManager() { return &m_CMapManager; }

 private:
  CSGPDF_SDK_FontGlobals();
  ~CSGPDF_SDK_FontGlobals();

  void LoadEmbeddedGB1CMaps();
  void LoadEmbeddedCNS1CMaps();
  void LoadEmbeddedJapan1CMaps();
  void LoadEmbeddedKorea1CMaps();

  CSGPDF_SDK_CMapManager m_CMapManager;
  pdfium::span<const FXCMAP_CMap> m_EmbeddedCharsets[CIDSET_NUM_SETS];
  pdfium::span<const uint16_t> m_EmbeddedToUnicodes[CIDSET_NUM_SETS];
  std::map<CSGPDF_SDK_Document*, std::unique_ptr<CFX_StockFontArray>> m_StockMap;
};

#endif  // CORE_FPDFAPI_FONT_CSGPDF_SDK_FONTGLOBALS_H_
