// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_FONT_CSGPDF_SDK_TRUETYPEFONT_H_
#define CORE_FPDFAPI_FONT_CSGPDF_SDK_TRUETYPEFONT_H_

#include "core/fpdfapi/font/sgpdf_simplefont.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_TrueTypeFont final : public CSGPDF_SDK_SimpleFont {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;
  ~CSGPDF_SDK_TrueTypeFont() override;

  // CSGPDF_SDK_Font:
  bool IsTrueTypeFont() const override;
  const CSGPDF_SDK_TrueTypeFont* AsTrueTypeFont() const override;
  CSGPDF_SDK_TrueTypeFont* AsTrueTypeFont() override;

 private:
  CSGPDF_SDK_TrueTypeFont(CSGPDF_SDK_Document* pDocument, CSGPDF_SDK_Dictionary* pFontDict);

  // CSGPDF_SDK_Font:
  bool Load() override;

  // CSGPDF_SDK_SimpleFont:
  void LoadGlyphMap() override;
};

#endif  // CORE_FPDFAPI_FONT_CSGPDF_SDK_TRUETYPEFONT_H_
