// Copyright 2019 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/font/sgpdf_cidfont.h"

#include <utility>

#include "core/fpdfapi/page/sgpdf_docpagedata.h"
#include "core/fpdfapi/page/sgpdf_pagemodule.h"
#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/render/sgpdf_docrenderdata.h"
#include "testing/gtest/include/gtest/gtest.h"

class CSGPDF_SDK_CIDFontTest : public testing::Test {
 protected:
  void SetUp() override { CSGPDF_SDK_PageModule::Create(); }
  void TearDown() override { CSGPDF_SDK_PageModule::Destroy(); }
};

TEST_F(CSGPDF_SDK_CIDFontTest, BUG_920636) {
  CSGPDF_SDK_Document doc(std::make_unique<CSGPDF_SDK_DocRenderData>(),
                    std::make_unique<CSGPDF_SDK_DocPageData>());
  auto font_dict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  font_dict->SetNewFor<CSGPDF_SDK_Name>("Encoding", "Identity−H");

  {
    auto descendant_fonts = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    {
      auto descendant_font = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
      descendant_font->SetNewFor<CSGPDF_SDK_Name>("BaseFont", "CourierStd");
      descendant_fonts->Append(std::move(descendant_font));
    }
    font_dict->SetFor("DescendantFonts", std::move(descendant_fonts));
  }

  auto font = pdfium::MakeRetain<CSGPDF_SDK_CIDFont>(&doc, font_dict.Get());
  ASSERT_TRUE(font->Load());

  // It would be nice if we can test more values here. However, the glyph
  // indices are sometimes machine dependent.
  struct {
    uint32_t charcode;
    int glyph;
  } static constexpr kTestCases[] = {
      {0, 31},
      {256, 287},
      {34661, 34692},
  };

  for (const auto& test_case : kTestCases) {
    EXPECT_EQ(test_case.glyph,
              font->GlyphFromCharCode(test_case.charcode, nullptr));
  }
}
