// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_FONT_CSGPDF_SDK_FONT_H_
#define CORE_FPDFAPI_FONT_CSGPDF_SDK_FONT_H_

#include <memory>
#include <utility>
#include <vector>

#include "build/build_config.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_stream_acc.h"
#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/observed_ptr.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"
#include "core/fxge/cfx_font.h"

class CFX_DIBitmap;
class CFX_SubstFont;
class CSGPDF_SDK_CIDFont;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_TrueTypeFont;
class CSGPDF_SDK_Type1Font;
class CSGPDF_SDK_Type3Char;
class CSGPDF_SDK_Type3Font;
class CSGPDF_SDK_ToUnicodeMap;

class CSGPDF_SDK_Font : public Retainable, public Observable {
 public:
  // Callback mechanism for Type3 fonts to get pixels from forms.
  class FormIface {
   public:
    virtual ~FormIface() {}

    virtual void ParseContentForType3Char(CSGPDF_SDK_Type3Char* pChar) = 0;
    virtual bool HasPageObjects() const = 0;
    virtual CFX_FloatRect CalcBoundingBox() const = 0;
    virtual Optional<std::pair<RetainPtr<CFX_DIBitmap>, CFX_Matrix>>
    GetBitmapAndMatrixFromSoleImageOfForm() const = 0;
  };

  // Callback mechanism for Type3 fonts to get new forms from upper layers.
  class FormFactoryIface {
   public:
    virtual ~FormFactoryIface() {}

    virtual std::unique_ptr<FormIface> CreateForm(
        CSGPDF_SDK_Document* pDocument,
        CSGPDF_SDK_Dictionary* pPageResources,
        CSGPDF_SDK_Stream* pFormStream) = 0;
  };

  static constexpr uint32_t kInvalidCharCode = static_cast<uint32_t>(-1);

  // |pFactory| only required for Type3 fonts.
  static RetainPtr<CSGPDF_SDK_Font> Create(CSGPDF_SDK_Document* pDoc,
                                     CSGPDF_SDK_Dictionary* pFontDict,
                                     FormFactoryIface* pFactory);
  static RetainPtr<CSGPDF_SDK_Font> GetStockFont(CSGPDF_SDK_Document* pDoc,
                                           ByteStringView fontname);

  ~CSGPDF_SDK_Font() override;

  virtual bool IsType1Font() const;
  virtual bool IsTrueTypeFont() const;
  virtual bool IsType3Font() const;
  virtual bool IsCIDFont() const;
  virtual const CSGPDF_SDK_Type1Font* AsType1Font() const;
  virtual CSGPDF_SDK_Type1Font* AsType1Font();
  virtual const CSGPDF_SDK_TrueTypeFont* AsTrueTypeFont() const;
  virtual CSGPDF_SDK_TrueTypeFont* AsTrueTypeFont();
  virtual const CSGPDF_SDK_Type3Font* AsType3Font() const;
  virtual CSGPDF_SDK_Type3Font* AsType3Font();
  virtual const CSGPDF_SDK_CIDFont* AsCIDFont() const;
  virtual CSGPDF_SDK_CIDFont* AsCIDFont();

  virtual void WillBeDestroyed();
  virtual bool IsVertWriting() const;
  virtual bool IsUnicodeCompatible() const;
  virtual uint32_t GetNextChar(ByteStringView pString, size_t* pOffset) const;
  virtual size_t CountChar(ByteStringView pString) const;
  virtual int AppendChar(char* buf, uint32_t charcode) const;
  virtual int GlyphFromCharCode(uint32_t charcode, bool* pVertGlyph) = 0;
#if defined(OS_APPLE)
  virtual int GlyphFromCharCodeExt(uint32_t charcode);
#endif
  virtual WideString UnicodeFromCharCode(uint32_t charcode) const;
  virtual uint32_t CharCodeFromUnicode(wchar_t Unicode) const;
  virtual bool HasFontWidths() const;

  ByteString GetBaseFontName() const { return m_BaseFontName; }
  CFX_SubstFont* GetSubstFont() const { return m_Font.GetSubstFont(); }
  bool IsEmbedded() const { return IsType3Font() || m_pFontFile != nullptr; }
  CSGPDF_SDK_Dictionary* GetFontDict() const { return m_pFontDict.Get(); }
  void ClearFontDict() { m_pFontDict = nullptr; }
  bool IsStandardFont() const;
  bool HasFace() const { return !!m_Font.GetFaceRec(); }
  void AppendChar(ByteString* str, uint32_t charcode) const;

  const FX_RECT& GetFontBBox() const { return m_FontBBox; }
  int GetTypeAscent() const { return m_Ascent; }
  int GetTypeDescent() const { return m_Descent; }
  int GetStringWidth(ByteStringView pString);
  uint32_t FallbackFontFromCharcode(uint32_t charcode);
  int FallbackGlyphFromCharcode(int fallbackFont, uint32_t charcode);
  int GetFontFlags() const { return m_Flags; }
  int GetFontWeight() const;

  virtual int GetCharWidthF(uint32_t charcode) = 0;
  virtual FX_RECT GetCharBBox(uint32_t charcode) = 0;

  // Can return nullptr for stock Type1 fonts. Always returns non-null for other
  // font types.
  CSGPDF_SDK_Document* GetDocument() const { return m_pDocument.Get(); }

  CFX_Font* GetFont() { return &m_Font; }
  const CFX_Font* GetFont() const { return &m_Font; }

  CFX_Font* GetFontFallback(int position);

 protected:
  CSGPDF_SDK_Font(CSGPDF_SDK_Document* pDocument, CSGPDF_SDK_Dictionary* pFontDict);

  static int TT2PDF(int m, FXFT_FaceRec* face);
  static bool FT_UseTTCharmap(FXFT_FaceRec* face,
                              int platform_id,
                              int encoding_id);
  static const char* GetAdobeCharName(int iBaseEncoding,
                                      const std::vector<ByteString>& charnames,
                                      uint32_t charcode);

  virtual bool Load() = 0;

  void LoadUnicodeMap() const;  // logically const only.
  void LoadFontDescriptor(const CSGPDF_SDK_Dictionary* pFontDesc);
  void CheckFontMetrics();

  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  CFX_Font m_Font;
  std::vector<std::unique_ptr<CFX_Font>> m_FontFallbacks;
  RetainPtr<CSGPDF_SDK_StreamAcc> m_pFontFile;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pFontDict;
  ByteString m_BaseFontName;
  mutable std::unique_ptr<CSGPDF_SDK_ToUnicodeMap> m_pToUnicodeMap;
  mutable bool m_bToUnicodeLoaded = false;
  int m_Flags = 0;
  int m_StemV = 0;
  int m_Ascent = 0;
  int m_Descent = 0;
  int m_ItalicAngle = 0;
  FX_RECT m_FontBBox;
};

#endif  // CORE_FPDFAPI_FONT_CSGPDF_SDK_FONT_H_
