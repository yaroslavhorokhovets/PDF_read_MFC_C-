// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_FONT_CSGPDF_SDK_TYPE3FONT_H_
#define CORE_FPDFAPI_FONT_CSGPDF_SDK_TYPE3FONT_H_

#include <map>
#include <memory>

#include "core/fpdfapi/font/sgpdf_simplefont.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_Stream;
class CSGPDF_SDK_Type3Char;

class CSGPDF_SDK_Type3Font final : public CSGPDF_SDK_SimpleFont {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;
  ~CSGPDF_SDK_Type3Font() override;

  // CSGPDF_SDK_Font:
  bool IsType3Font() const override;
  const CSGPDF_SDK_Type3Font* AsType3Font() const override;
  CSGPDF_SDK_Type3Font* AsType3Font() override;
  void WillBeDestroyed() override;
  int GetCharWidthF(uint32_t charcode) override;
  FX_RECT GetCharBBox(uint32_t charcode) override;

  void SetPageResources(CSGPDF_SDK_Dictionary* pResources) {
    m_pPageResources.Reset(pResources);
  }
  CSGPDF_SDK_Type3Char* LoadChar(uint32_t charcode);
  void CheckType3FontMetrics();

  CFX_Matrix& GetFontMatrix() { return m_FontMatrix; }

 private:
  CSGPDF_SDK_Type3Font(CSGPDF_SDK_Document* pDocument,
                 CSGPDF_SDK_Dictionary* pFontDict,
                 FormFactoryIface* pFormFactory);

  // CSGPDF_SDK_Font:
  bool Load() override;

  // CSGPDF_SDK_SimpleFont:
  void LoadGlyphMap() override;

  // The depth char loading is in, to avoid recurive calling LoadChar().
  int m_CharLoadingDepth = 0;
  CFX_Matrix m_FontMatrix;
  UnownedPtr<FormFactoryIface> const m_pFormFactory;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pCharProcs;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pPageResources;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pFontResources;
  std::map<uint32_t, std::unique_ptr<CSGPDF_SDK_Type3Char>> m_CacheMap;
  int m_CharWidthL[256] = {};
};

#endif  // CORE_FPDFAPI_FONT_CSGPDF_SDK_TYPE3FONT_H_
