// (c)2022 Secured GLobe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_EDIT_CSGPDF_SDK_CREATOR_H_
#define CORE_FPDFAPI_EDIT_CSGPDF_SDK_CREATOR_H_

#include <map>
#include <memory>
#include <vector>

#include "core/fxcrt/fx_stream.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Array;
class CSGPDF_SDK_CryptoHandler;
class CSGPDF_SDK_SecurityHandler;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_Parser;

#define FPDFCREATE_INCREMENTAL 1
#define FPDFCREATE_NO_ORIGINAL 2

class CSGPDF_SDK_Creator {
 public:
  CSGPDF_SDK_Creator(CSGPDF_SDK_Document* pDoc,
               const RetainPtr<IFX_RetainableWriteStream>& archive);
  ~CSGPDF_SDK_Creator();

  void RemoveSecurity();
  bool Create(uint32_t flags);
  bool SetFileVersion(int32_t fileVersion);

 private:
  enum class Stage {
    kInvalid = -1,
    kInit0 = 0,
    kWriteHeader10 = 10,
    kWriteIncremental15 = 15,
    kInitWriteObjs20 = 20,
    kWriteOldObjs21 = 21,
    kInitWriteNewObjs25 = 25,
    kWriteNewObjs26 = 26,
    kWriteEncryptDict27 = 27,
    kInitWriteXRefs80 = 80,
    kWriteXrefsNotIncremental81 = 81,
    kWriteXrefsIncremental82 = 82,
    kWriteTrailerAndFinish90 = 90,
    kComplete100 = 100,
  };

  bool Continue();
  void Clear();

  void InitNewObjNumOffsets();
  void InitID();

  CSGPDF_SDK_Creator::Stage WriteDoc_Stage1();
  CSGPDF_SDK_Creator::Stage WriteDoc_Stage2();
  CSGPDF_SDK_Creator::Stage WriteDoc_Stage3();
  CSGPDF_SDK_Creator::Stage WriteDoc_Stage4();

  bool WriteOldIndirectObject(uint32_t objnum);
  bool WriteOldObjs();
  bool WriteNewObjs();
  bool WriteIndirectObj(uint32_t objnum, const CSGPDF_SDK_Object* pObj);

  CSGPDF_SDK_CryptoHandler* GetCryptoHandler();

  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  UnownedPtr<const CSGPDF_SDK_Parser> const m_pParser;
  RetainPtr<const CSGPDF_SDK_Dictionary> m_pEncryptDict;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pNewEncryptDict;
  RetainPtr<CSGPDF_SDK_SecurityHandler> m_pSecurityHandler;
  RetainPtr<const CSGPDF_SDK_Object> m_pMetadata;
  uint32_t m_dwLastObjNum;
  std::unique_ptr<IFX_ArchiveStream> m_Archive;
  FX_FILESIZE m_SavedOffset = 0;
  Stage m_iStage = Stage::kInvalid;
  uint32_t m_CurObjNum = 0;
  FX_FILESIZE m_XrefStart = 0;
  std::map<uint32_t, FX_FILESIZE> m_ObjectOffsets;
  std::vector<uint32_t> m_NewObjNumArray;  // Sorted, ascending.
  RetainPtr<CSGPDF_SDK_Array> m_pIDArray;
  int32_t m_FileVersion = 0;
  bool m_bSecurityChanged = false;
  bool m_IsIncremental = false;
  bool m_IsOriginal = false;
};

#endif  // CORE_FPDFAPI_EDIT_CSGPDF_SDK_CREATOR_H_
