// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_EDIT_CSGPDF_SDK_PAGECONTENTGENERATOR_H_
#define CORE_FPDFAPI_EDIT_CSGPDF_SDK_PAGECONTENTGENERATOR_H_

#include <map>
#include <memory>
#include <sstream>
#include <vector>

#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_ContentMarks;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_ImageObject;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_PageObject;
class CSGPDF_SDK_PageObjectHolder;
class CSGPDF_SDK_Path;
class CSGPDF_SDK_PathObject;
class CSGPDF_SDK_TextObject;

class CSGPDF_SDK_PageContentGenerator {
 public:
  explicit CSGPDF_SDK_PageContentGenerator(CSGPDF_SDK_PageObjectHolder* pObjHolder);
  ~CSGPDF_SDK_PageContentGenerator();

  void GenerateContent();
  bool ProcessPageObjects(std::ostringstream* buf);

 private:
  friend class CSGPDF_SDK_PageContentGeneratorTest;

  void ProcessPageObject(std::ostringstream* buf, CSGPDF_SDK_PageObject* pPageObj);
  void ProcessPathPoints(std::ostringstream* buf, CSGPDF_SDK_Path* pPath);
  void ProcessPath(std::ostringstream* buf, CSGPDF_SDK_PathObject* pPathObj);
  void ProcessImage(std::ostringstream* buf, CSGPDF_SDK_ImageObject* pImageObj);
  void ProcessGraphics(std::ostringstream* buf, CSGPDF_SDK_PageObject* pPageObj);
  void ProcessDefaultGraphics(std::ostringstream* buf);
  void ProcessText(std::ostringstream* buf, CSGPDF_SDK_TextObject* pTextObj);
  ByteString GetOrCreateDefaultGraphics() const;
  ByteString RealizeResource(const CSGPDF_SDK_Object* pResource,
                             const ByteString& bsType) const;
  const CSGPDF_SDK_ContentMarks* ProcessContentMarks(std::ostringstream* buf,
                                               const CSGPDF_SDK_PageObject* pPageObj,
                                               const CSGPDF_SDK_ContentMarks* pPrev);
  void FinishMarks(std::ostringstream* buf,
                   const CSGPDF_SDK_ContentMarks* pContentMarks);

  // Returns a map from content stream index to new stream data. Unmodified
  // streams are not touched.
  std::map<int32_t, std::unique_ptr<std::ostringstream>>
  GenerateModifiedStreams();

  // Add buffer as a stream in page's 'Contents'
  void UpdateContentStreams(
      const std::map<int32_t, std::unique_ptr<std::ostringstream>>&
          new_stream_data);

  // Set the stream index of all page objects with stream index ==
  // |CSGPDF_SDK_PageObject::kNoContentStream|. These are new objects that had not
  // been parsed from or written to any content stream yet.
  void UpdateStreamlessPageObjects(int new_content_stream_index);

  UnownedPtr<CSGPDF_SDK_PageObjectHolder> const m_pObjHolder;
  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  std::vector<UnownedPtr<CSGPDF_SDK_PageObject>> m_pageObjects;
};

#endif  // CORE_FPDFAPI_EDIT_CSGPDF_SDK_PAGECONTENTGENERATOR_H_
