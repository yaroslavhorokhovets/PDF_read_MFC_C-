// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/edit/sgpdf_stringarchivestream.h"

#include "third_party/base/notreached.h"

CSGPDF_SDK_StringArchiveStream::CSGPDF_SDK_StringArchiveStream(std::ostringstream* stream)
	: stream_(stream)
{
}

CSGPDF_SDK_StringArchiveStream::~CSGPDF_SDK_StringArchiveStream() = default;

bool CSGPDF_SDK_StringArchiveStream::WriteByte(uint8_t byte)
{
	NOTREACHED();
	return false;
}

bool CSGPDF_SDK_StringArchiveStream::WriteDWord(uint32_t i)
{
	NOTREACHED();
	return false;
}

FX_FILESIZE CSGPDF_SDK_StringArchiveStream::CurrentOffset() const
{
	NOTREACHED();
	return false;
}

bool CSGPDF_SDK_StringArchiveStream::WriteBlock(const void* pData, size_t size)
{
	stream_->write(static_cast<const char*>(pData), size);
	return true;
}

bool CSGPDF_SDK_StringArchiveStream::WriteString(ByteStringView str)
{
	stream_->write(str.unterminated_c_str(), str.GetLength());
	return true;
}
