// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_object.h"

#include <algorithm>

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_indirect_object_holder.h"
#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fxcrt/fx_string.h"
#include "third_party/base/notreached.h"

CSGPDF_SDK_Object::~CSGPDF_SDK_Object() = default;

CSGPDF_SDK_Object* CSGPDF_SDK_Object::GetDirect()
{
	return this;
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Object::GetDirect() const
{
	return this;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Object::CloneObjectNonCyclic(bool bDirect) const
{
	std::set<const CSGPDF_SDK_Object*> visited_objs;
	return CloneNonCyclic(bDirect, &visited_objs);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Object::CloneDirectObject() const
{
	return CloneObjectNonCyclic(true);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Object::CloneNonCyclic(
	bool bDirect,
	std::set<const CSGPDF_SDK_Object*>* pVisited) const
{
	return Clone();
}

ByteString CSGPDF_SDK_Object::GetString() const
{
	return ByteString();
}

WideString CSGPDF_SDK_Object::GetUnicodeText() const
{
	return WideString();
}

float CSGPDF_SDK_Object::GetNumber() const
{
	return 0;
}

int CSGPDF_SDK_Object::GetInteger() const
{
	return 0;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Object::GetDict()
{
	return nullptr;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Object::GetDict() const
{
	return nullptr;
}

void CSGPDF_SDK_Object::SetString(const ByteString& str)
{
	NOTREACHED();
}

bool CSGPDF_SDK_Object::IsArray() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsBoolean() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsDictionary() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsName() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsNumber() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsReference() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsStream() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsString() const
{
	return false;
}

bool CSGPDF_SDK_Object::IsNull() const
{
	return false;
}

CSGPDF_SDK_Array* CSGPDF_SDK_Object::AsArray()
{
	return nullptr;
}

const CSGPDF_SDK_Array* CSGPDF_SDK_Object::AsArray() const
{
	return nullptr;
}

CSGPDF_SDK_Boolean* CSGPDF_SDK_Object::AsBoolean()
{
	return nullptr;
}

const CSGPDF_SDK_Boolean* CSGPDF_SDK_Object::AsBoolean() const
{
	return nullptr;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Object::AsDictionary()
{
	return nullptr;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Object::AsDictionary() const
{
	return nullptr;
}

CSGPDF_SDK_Name* CSGPDF_SDK_Object::AsName()
{
	return nullptr;
}

const CSGPDF_SDK_Name* CSGPDF_SDK_Object::AsName() const
{
	return nullptr;
}

CSGPDF_SDK_Number* CSGPDF_SDK_Object::AsNumber()
{
	return nullptr;
}

const CSGPDF_SDK_Number* CSGPDF_SDK_Object::AsNumber() const
{
	return nullptr;
}

CSGPDF_SDK_Reference* CSGPDF_SDK_Object::AsReference()
{
	return nullptr;
}

const CSGPDF_SDK_Reference* CSGPDF_SDK_Object::AsReference() const
{
	return nullptr;
}

CSGPDF_SDK_Stream* CSGPDF_SDK_Object::AsStream()
{
	return nullptr;
}

const CSGPDF_SDK_Stream* CSGPDF_SDK_Object::AsStream() const
{
	return nullptr;
}

CSGPDF_SDK_String* CSGPDF_SDK_Object::AsString()
{
	return nullptr;
}

const CSGPDF_SDK_String* CSGPDF_SDK_Object::AsString() const
{
	return nullptr;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Object::MakeReference(
	CSGPDF_SDK_IndirectObjectHolder* holder) const
{
	if (IsInline())
	{
		NOTREACHED();
		return nullptr;
	}
	return pdfium::MakeRetain<CSGPDF_SDK_Reference>(holder, GetObjNum());
}
