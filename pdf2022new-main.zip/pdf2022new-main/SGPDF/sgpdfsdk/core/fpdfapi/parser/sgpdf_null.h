// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_NULL_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_NULL_H_

#include "core/fpdfapi/parser/sgpdf_object.h"

class CSGPDF_SDK_Null final : public CSGPDF_SDK_Object {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  // CSGPDF_SDK_Object.
  Type GetType() const override;
  RetainPtr<CSGPDF_SDK_Object> Clone() const override;
  bool WriteTo(IFX_ArchiveStream* archive,
               const CSGPDF_SDK_Encryptor* encryptor) const override;
  bool IsNull() const override;

 private:
  CSGPDF_SDK_Null();
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_NULL_H_
