// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_NUMBER_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_NUMBER_H_

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/fx_number.h"
#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_Number final : public CSGPDF_SDK_Object {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  // CSGPDF_SDK_Object:
  Type GetType() const override;
  RetainPtr<CSGPDF_SDK_Object> Clone() const override;
  ByteString GetString() const override;
  float GetNumber() const override;
  int GetInteger() const override;
  void SetString(const ByteString& str) override;
  bool IsNumber() const override;
  CSGPDF_SDK_Number* AsNumber() override;
  const CSGPDF_SDK_Number* AsNumber() const override;
  bool WriteTo(IFX_ArchiveStream* archive,
               const CSGPDF_SDK_Encryptor* encryptor) const override;

  bool IsInteger() const { return m_Number.IsInteger(); }

 private:
  CSGPDF_SDK_Number();
  explicit CSGPDF_SDK_Number(int value);
  explicit CSGPDF_SDK_Number(float value);
  explicit CSGPDF_SDK_Number(ByteStringView str);
  ~CSGPDF_SDK_Number() override;

  FX_Number m_Number;
};

inline CSGPDF_SDK_Number* ToNumber(CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsNumber() : nullptr;
}

inline const CSGPDF_SDK_Number* ToNumber(const CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsNumber() : nullptr;
}

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_NUMBER_H_
