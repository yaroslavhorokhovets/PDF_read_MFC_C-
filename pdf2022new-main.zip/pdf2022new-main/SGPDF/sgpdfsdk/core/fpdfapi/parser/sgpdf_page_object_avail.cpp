// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/parser/sgpdf_page_object_avail.h"

#include "core/fpdfapi/parser/sgpdf_dictionary.h"

CSGPDF_SDK_PageObjectAvail::~CSGPDF_SDK_PageObjectAvail() = default;

bool CSGPDF_SDK_PageObjectAvail::ExcludeObject(const CSGPDF_SDK_Object* object) const
{
	if (CSGPDF_SDK_ObjectAvail::ExcludeObject(object))
		return true;

	return object->IsDictionary() &&
		object->GetDict()->GetNameFor("Type") == "Page";
}
