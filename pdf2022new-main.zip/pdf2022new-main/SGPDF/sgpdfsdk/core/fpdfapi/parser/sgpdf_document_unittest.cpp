// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/parser/sgpdf_document.h"

#include <memory>
#include <utility>

#include "core/fpdfapi/page/sgpdf_docpagedata.h"
#include "core/fpdfapi/page/sgpdf_pagemodule.h"
#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_boolean.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_linearized_header.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "core/fpdfapi/render/sgpdf_docrenderdata.h"
#include "testing/gtest/include/gtest/gtest.h"
#include "third_party/base/check.h"

namespace {

const int kNumTestPages = 7;

CSGPDF_SDK_Dictionary* CreatePageTreeNode(RetainPtr<CSGPDF_SDK_Array> kids,
                                    CSGPDF_SDK_Document* pDoc,
                                    int count) {
  CSGPDF_SDK_Array* pUnowned = pDoc->AddIndirectObject(std::move(kids))->AsArray();
  CSGPDF_SDK_Dictionary* pageNode = pDoc->NewIndirect<CSGPDF_SDK_Dictionary>();
  pageNode->SetNewFor<CSGPDF_SDK_Name>("Type", "Pages");
  pageNode->SetNewFor<CSGPDF_SDK_Reference>("Kids", pDoc, pUnowned->GetObjNum());
  pageNode->SetNewFor<CSGPDF_SDK_Number>("Count", count);
  for (size_t i = 0; i < pUnowned->size(); i++) {
    pUnowned->GetDictAt(i)->SetNewFor<CSGPDF_SDK_Reference>("Parent", pDoc,
                                                      pageNode->GetObjNum());
  }
  return pageNode;
}

RetainPtr<CSGPDF_SDK_Dictionary> CreateNumberedPage(size_t number) {
  auto page = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  page->SetNewFor<CSGPDF_SDK_Name>("Type", "Page");
  page->SetNewFor<CSGPDF_SDK_Number>("PageNumbering", static_cast<int>(number));
  return page;
}

class CSGPDF_SDK_TestDocumentForPages final : public CSGPDF_SDK_Document {
 public:
  CSGPDF_SDK_TestDocumentForPages()
      : CSGPDF_SDK_Document(std::make_unique<CSGPDF_SDK_DocRenderData>(),
                      std::make_unique<CSGPDF_SDK_DocPageData>()) {
    // Set up test
    auto zeroToTwo = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    zeroToTwo->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(0))->GetObjNum());
    zeroToTwo->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(1))->GetObjNum());
    zeroToTwo->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(2))->GetObjNum());
    CSGPDF_SDK_Dictionary* branch1 =
        CreatePageTreeNode(std::move(zeroToTwo), this, 3);

    auto zeroToThree = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    zeroToThree->AppendNew<CSGPDF_SDK_Reference>(this, branch1->GetObjNum());
    zeroToThree->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(3))->GetObjNum());
    CSGPDF_SDK_Dictionary* branch2 =
        CreatePageTreeNode(std::move(zeroToThree), this, 4);

    auto fourFive = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    fourFive->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(4))->GetObjNum());
    fourFive->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(5))->GetObjNum());
    CSGPDF_SDK_Dictionary* branch3 = CreatePageTreeNode(std::move(fourFive), this, 2);

    auto justSix = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    justSix->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(6))->GetObjNum());
    CSGPDF_SDK_Dictionary* branch4 = CreatePageTreeNode(std::move(justSix), this, 1);

    auto allPages = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    allPages->AppendNew<CSGPDF_SDK_Reference>(this, branch2->GetObjNum());
    allPages->AppendNew<CSGPDF_SDK_Reference>(this, branch3->GetObjNum());
    allPages->AppendNew<CSGPDF_SDK_Reference>(this, branch4->GetObjNum());
    CSGPDF_SDK_Dictionary* pagesDict =
        CreatePageTreeNode(std::move(allPages), this, kNumTestPages);

    SetRootForTesting(NewIndirect<CSGPDF_SDK_Dictionary>());
    GetRoot()->SetNewFor<CSGPDF_SDK_Reference>("Pages", this, pagesDict->GetObjNum());
    ResizePageListForTesting(kNumTestPages);
  }

  void SetTreeSize(int size) {
    GetRoot()->SetNewFor<CSGPDF_SDK_Number>("Count", size);
    ResizePageListForTesting(size);
  }
};

class CSGPDF_SDK_TestDocumentWithPageWithoutPageNum final : public CSGPDF_SDK_Document {
 public:
  CSGPDF_SDK_TestDocumentWithPageWithoutPageNum()
      : CSGPDF_SDK_Document(std::make_unique<CSGPDF_SDK_DocRenderData>(),
                      std::make_unique<CSGPDF_SDK_DocPageData>()) {
    // Set up test
    auto allPages = pdfium::MakeRetain<CSGPDF_SDK_Array>();
    allPages->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(0))->GetObjNum());
    allPages->AppendNew<CSGPDF_SDK_Reference>(
        this, AddIndirectObject(CreateNumberedPage(1))->GetObjNum());
    // Page without pageNum.
    inlined_page_ = allPages->Append(CreateNumberedPage(2));
    CSGPDF_SDK_Dictionary* pagesDict =
        CreatePageTreeNode(std::move(allPages), this, 3);
    SetRootForTesting(NewIndirect<CSGPDF_SDK_Dictionary>());
    GetRoot()->SetNewFor<CSGPDF_SDK_Reference>("Pages", this, pagesDict->GetObjNum());
    ResizePageListForTesting(3);
  }

  const CSGPDF_SDK_Object* inlined_page() const { return inlined_page_; }

 private:
  const CSGPDF_SDK_Object* inlined_page_;
};

class TestLinearized final : public CSGPDF_SDK_LinearizedHeader {
 public:
  explicit TestLinearized(CSGPDF_SDK_Dictionary* dict)
      : CSGPDF_SDK_LinearizedHeader(dict, 0) {}
};

class CSGPDF_SDK_TestDocPagesWithoutKids final : public CSGPDF_SDK_Document {
 public:
  CSGPDF_SDK_TestDocPagesWithoutKids()
      : CSGPDF_SDK_Document(std::make_unique<CSGPDF_SDK_DocRenderData>(),
                      std::make_unique<CSGPDF_SDK_DocPageData>()) {
    CSGPDF_SDK_Dictionary* pagesDict = NewIndirect<CSGPDF_SDK_Dictionary>();
    pagesDict->SetNewFor<CSGPDF_SDK_Name>("Type", "Pages");
    pagesDict->SetNewFor<CSGPDF_SDK_Number>("Count", 3);
    ResizePageListForTesting(10);
    SetRootForTesting(NewIndirect<CSGPDF_SDK_Dictionary>());
    GetRoot()->SetNewFor<CSGPDF_SDK_Reference>("Pages", this, pagesDict->GetObjNum());
  }
};

class CSGPDF_SDK_TestDocumentAllowSetParser final : public CSGPDF_SDK_Document {
 public:
  CSGPDF_SDK_TestDocumentAllowSetParser()
      : CSGPDF_SDK_Document(std::make_unique<CSGPDF_SDK_DocRenderData>(),
                      std::make_unique<CSGPDF_SDK_DocPageData>()) {}

  using CSGPDF_SDK_Document::SetParser;
};

}  // namespace

class cpdf_document_test : public testing::Test {
 public:
  void SetUp() override { CSGPDF_SDK_PageModule::Create(); }
  void TearDown() override { CSGPDF_SDK_PageModule::Destroy(); }
};

TEST_F(cpdf_document_test, GetPages) {
  std::unique_ptr<CSGPDF_SDK_TestDocumentForPages> document =
      std::make_unique<CSGPDF_SDK_TestDocumentForPages>();
  for (int i = 0; i < kNumTestPages; i++) {
    CSGPDF_SDK_Dictionary* page = document->GetPageDictionary(i);
    ASSERT_TRUE(page);
    ASSERT_TRUE(page->KeyExist("PageNumbering"));
    EXPECT_EQ(i, page->GetIntegerFor("PageNumbering"));
  }
  CSGPDF_SDK_Dictionary* page = document->GetPageDictionary(kNumTestPages);
  EXPECT_FALSE(page);
}

TEST_F(cpdf_document_test, GetPageWithoutObjNumTwice) {
  auto document = std::make_unique<CSGPDF_SDK_TestDocumentWithPageWithoutPageNum>();
  CSGPDF_SDK_Dictionary* page = document->GetPageDictionary(2);
  ASSERT_TRUE(page);
  ASSERT_EQ(document->inlined_page(), page);

  CSGPDF_SDK_Dictionary* second_call_page = document->GetPageDictionary(2);
  EXPECT_TRUE(second_call_page);
  EXPECT_EQ(page, second_call_page);
}

TEST_F(cpdf_document_test, GetPagesReverseOrder) {
  std::unique_ptr<CSGPDF_SDK_TestDocumentForPages> document =
      std::make_unique<CSGPDF_SDK_TestDocumentForPages>();
  for (int i = 6; i >= 0; i--) {
    CSGPDF_SDK_Dictionary* page = document->GetPageDictionary(i);
    ASSERT_TRUE(page);
    ASSERT_TRUE(page->KeyExist("PageNumbering"));
    EXPECT_EQ(i, page->GetIntegerFor("PageNumbering"));
  }
  CSGPDF_SDK_Dictionary* page = document->GetPageDictionary(kNumTestPages);
  EXPECT_FALSE(page);
}

TEST_F(cpdf_document_test, GetPagesInDisorder) {
  std::unique_ptr<CSGPDF_SDK_TestDocumentForPages> document =
      std::make_unique<CSGPDF_SDK_TestDocumentForPages>();

  CSGPDF_SDK_Dictionary* page = document->GetPageDictionary(1);
  ASSERT_TRUE(page);
  ASSERT_TRUE(page->KeyExist("PageNumbering"));
  EXPECT_EQ(1, page->GetIntegerFor("PageNumbering"));

  page = document->GetPageDictionary(3);
  ASSERT_TRUE(page);
  ASSERT_TRUE(page->KeyExist("PageNumbering"));
  EXPECT_EQ(3, page->GetIntegerFor("PageNumbering"));

  page = document->GetPageDictionary(kNumTestPages);
  EXPECT_FALSE(page);

  page = document->GetPageDictionary(6);
  ASSERT_TRUE(page);
  ASSERT_TRUE(page->KeyExist("PageNumbering"));
  EXPECT_EQ(6, page->GetIntegerFor("PageNumbering"));
}

TEST_F(cpdf_document_test, IsValidPageObject) {
  CSGPDF_SDK_TestDocumentForPages document;

  auto dict_type_name_page = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  dict_type_name_page->SetNewFor<CSGPDF_SDK_Name>("Type", "Page");
  EXPECT_TRUE(CSGPDF_SDK_Document::IsValidPageObject(
      document.AddIndirectObject(dict_type_name_page)));

  auto dict_type_string_page = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  dict_type_string_page->SetNewFor<CSGPDF_SDK_String>("Type", "Page", false);
  EXPECT_FALSE(CSGPDF_SDK_Document::IsValidPageObject(
      document.AddIndirectObject(dict_type_string_page)));

  auto dict_type_name_font = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  dict_type_name_font->SetNewFor<CSGPDF_SDK_Name>("Type", "Font");
  EXPECT_FALSE(CSGPDF_SDK_Document::IsValidPageObject(
      document.AddIndirectObject(dict_type_name_font)));

  CSGPDF_SDK_Object* obj_no_type = document.NewIndirect<CSGPDF_SDK_Dictionary>();
  EXPECT_FALSE(CSGPDF_SDK_Document::IsValidPageObject(obj_no_type));
}

TEST_F(cpdf_document_test, UseCachedPageObjNumIfHaveNotPagesDict) {
  // ObjNum can be added in CSGPDF_SDK_DataAvail::IsPageAvail(), and PagesDict may not
  // exist in this case, e.g. when hint table is used to page check in
  // CSGPDF_SDK_DataAvail.
  constexpr int kPageCount = 100;
  constexpr int kTestPageNum = 33;

  auto linearization_dict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  CSGPDF_SDK_TestDocumentAllowSetParser document;

  {
    CSGPDF_SDK_Object* first_page = document.AddIndirectObject(CreateNumberedPage(0));
    DCHECK(first_page);
    int first_page_obj_num = first_page->GetObjNum();
    ASSERT_NE(kTestPageNum, first_page_obj_num);

    linearization_dict->SetNewFor<CSGPDF_SDK_Boolean>("Linearized", true);
    linearization_dict->SetNewFor<CSGPDF_SDK_Number>("N", kPageCount);
    linearization_dict->SetNewFor<CSGPDF_SDK_Number>("O", first_page_obj_num);

    auto parser = std::make_unique<CSGPDF_SDK_Parser>();
    parser->SetLinearizedHeaderForTesting(
        std::make_unique<TestLinearized>(linearization_dict.Get()));
    document.SetParser(std::move(parser));
  }

  document.LoadPages();

  ASSERT_EQ(kPageCount, document.GetPageCount());
  CSGPDF_SDK_Object* page_stub = document.NewIndirect<CSGPDF_SDK_Dictionary>();
  const uint32_t obj_num = page_stub->GetObjNum();

  EXPECT_FALSE(document.IsPageLoaded(kTestPageNum));
  EXPECT_EQ(nullptr, document.GetPageDictionary(kTestPageNum));

  document.SetPageObjNum(kTestPageNum, obj_num);
  EXPECT_TRUE(document.IsPageLoaded(kTestPageNum));
  EXPECT_EQ(page_stub, document.GetPageDictionary(kTestPageNum));
}

TEST_F(cpdf_document_test, CountGreaterThanPageTree) {
  std::unique_ptr<CSGPDF_SDK_TestDocumentForPages> document =
      std::make_unique<CSGPDF_SDK_TestDocumentForPages>();
  document->SetTreeSize(kNumTestPages + 3);
  for (int i = 0; i < kNumTestPages; i++)
    EXPECT_TRUE(document->GetPageDictionary(i));
  for (int i = kNumTestPages; i < kNumTestPages + 4; i++)
    EXPECT_FALSE(document->GetPageDictionary(i));
  EXPECT_TRUE(document->GetPageDictionary(kNumTestPages - 1));
}

TEST_F(cpdf_document_test, PagesWithoutKids) {
  // Set up a document with Pages dict without kids, and Count = 3
  auto pDoc = std::make_unique<CSGPDF_SDK_TestDocPagesWithoutKids>();
  EXPECT_TRUE(pDoc->GetPageDictionary(0));
  // Test GetPage does not fetch pages out of range
  for (int i = 1; i < 5; i++)
    EXPECT_FALSE(pDoc->GetPageDictionary(i));

  EXPECT_TRUE(pDoc->GetPageDictionary(0));
}
