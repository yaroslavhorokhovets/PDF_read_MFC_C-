// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_STRING_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_STRING_H_

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/string_pool_template.h"
#include "core/fxcrt/weak_ptr.h"

class CSGPDF_SDK_String final : public CSGPDF_SDK_Object {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  // CSGPDF_SDK_Object:
  Type GetType() const override;
  RetainPtr<CSGPDF_SDK_Object> Clone() const override;
  ByteString GetString() const override;
  WideString GetUnicodeText() const override;
  void SetString(const ByteString& str) override;
  bool IsString() const override;
  CSGPDF_SDK_String* AsString() override;
  const CSGPDF_SDK_String* AsString() const override;
  bool WriteTo(IFX_ArchiveStream* archive,
               const CSGPDF_SDK_Encryptor* encryptor) const override;

  bool IsHex() const { return m_bHex; }

 private:
  CSGPDF_SDK_String();
  CSGPDF_SDK_String(WeakPtr<ByteStringPool> pPool, const ByteString& str, bool bHex);
  CSGPDF_SDK_String(WeakPtr<ByteStringPool> pPool, const WideString& str);
  ~CSGPDF_SDK_String() override;

  ByteString m_String;
  bool m_bHex = false;
};

inline CSGPDF_SDK_String* ToString(CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsString() : nullptr;
}

inline const CSGPDF_SDK_String* ToString(const CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsString() : nullptr;
}

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_STRING_H_
