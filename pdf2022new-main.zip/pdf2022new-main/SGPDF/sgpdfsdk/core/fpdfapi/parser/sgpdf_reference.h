// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_REFERENCE_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_REFERENCE_H_

#include <memory>
#include <set>

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_IndirectObjectHolder;

class CSGPDF_SDK_Reference final : public CSGPDF_SDK_Object {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  // CSGPDF_SDK_Object:
  Type GetType() const override;
  RetainPtr<CSGPDF_SDK_Object> Clone() const override;
  CSGPDF_SDK_Object* GetDirect() override;
  const CSGPDF_SDK_Object* GetDirect() const override;
  ByteString GetString() const override;
  float GetNumber() const override;
  int GetInteger() const override;
  CSGPDF_SDK_Dictionary* GetDict() override;
  const CSGPDF_SDK_Dictionary* GetDict() const override;
  bool IsReference() const override;
  CSGPDF_SDK_Reference* AsReference() override;
  const CSGPDF_SDK_Reference* AsReference() const override;
  bool WriteTo(IFX_ArchiveStream* archive,
               const CSGPDF_SDK_Encryptor* encryptor) const override;
  RetainPtr<CSGPDF_SDK_Object> MakeReference(
      CSGPDF_SDK_IndirectObjectHolder* holder) const override;

  CSGPDF_SDK_IndirectObjectHolder* GetObjList() const { return m_pObjList.Get(); }
  uint32_t GetRefObjNum() const { return m_RefObjNum; }
  void SetRef(CSGPDF_SDK_IndirectObjectHolder* pDoc, uint32_t objnum);

 private:
  CSGPDF_SDK_Reference(CSGPDF_SDK_IndirectObjectHolder* pDoc, uint32_t objnum);
  ~CSGPDF_SDK_Reference() override;

  RetainPtr<CSGPDF_SDK_Object> CloneNonCyclic(
      bool bDirect,
      std::set<const CSGPDF_SDK_Object*>* pVisited) const override;
  CSGPDF_SDK_Object* SafeGetDirect();
  const CSGPDF_SDK_Object* SafeGetDirect() const;

  UnownedPtr<CSGPDF_SDK_IndirectObjectHolder> m_pObjList;
  uint32_t m_RefObjNum;
};

inline CSGPDF_SDK_Reference* ToReference(CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsReference() : nullptr;
}

inline const CSGPDF_SDK_Reference* ToReference(const CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsReference() : nullptr;
}

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_REFERENCE_H_
