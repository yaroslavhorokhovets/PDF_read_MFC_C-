// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/parser/sgpdf_object_walker.h"

#include <sstream>
#include <string>
#include <utility>

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_boolean.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_null.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "testing/gtest/include/gtest/gtest.h"

namespace {

std::string Walk(CSGPDF_SDK_Object* object) {
  std::ostringstream result;
  CSGPDF_SDK_ObjectWalker walker(object);
  while (const CSGPDF_SDK_Object* obj = walker.GetNext()) {
    if (obj->IsDictionary())
      result << " Dict";
    else if (obj->IsArray())
      result << " Arr";
    else if (obj->IsString())
      result << " Str";
    else if (obj->IsBoolean())
      result << " Bool";
    else if (obj->IsStream())
      result << " Stream";
    else if (obj->IsReference())
      result << " Ref";
    else if (obj->IsNumber())
      result << " Num";
    else if (obj->IsNull())
      result << " Null";
    else
      result << " Unknown";
  }
  std::string result_str = result.str();
  if (!result_str.empty()) {
    result_str.erase(result_str.begin());  // remove start space
  }
  return result_str;
}

}  // namespace

TEST(CSGPDF_SDK_ObjectWalkerTest, Simple) {
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_Null>().Get()), "Null");
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_Dictionary>().Get()), "Dict");
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_Array>().Get()), "Arr");
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_String>().Get()), "Str");
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_Boolean>().Get()), "Bool");
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_Stream>().Get()), "Stream");
  EXPECT_EQ(Walk(pdfium::MakeRetain<CSGPDF_SDK_Reference>(nullptr, 0).Get()), "Ref");
}

TEST(CSGPDF_SDK_ObjectWalkerTest, CombinedObject) {
  auto dict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  dict->SetFor("1", pdfium::MakeRetain<CSGPDF_SDK_String>());
  dict->SetFor("2", pdfium::MakeRetain<CSGPDF_SDK_Boolean>());
  auto array = pdfium::MakeRetain<CSGPDF_SDK_Array>();
  array->Append(pdfium::MakeRetain<CSGPDF_SDK_Reference>(nullptr, 0));
  array->Append(pdfium::MakeRetain<CSGPDF_SDK_Null>());
  array->Append(pdfium::MakeRetain<CSGPDF_SDK_Stream>(
      nullptr, 0, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>()));
  dict->SetFor("3", std::move(array));
  // The last number for stream length.
  EXPECT_EQ(Walk(dict.Get()), "Dict Str Bool Arr Ref Null Stream Dict Num");
}

TEST(CSGPDF_SDK_ObjectWalkerTest, GetParent) {
  auto level_4 = pdfium::MakeRetain<CSGPDF_SDK_Number>(0);
  auto level_3 = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  level_3->SetFor("Length", std::move(level_4));
  auto level_2 =
      pdfium::MakeRetain<CSGPDF_SDK_Stream>(nullptr, 0, std::move(level_3));
  auto level_1 = pdfium::MakeRetain<CSGPDF_SDK_Array>();
  level_1->Append(std::move(level_2));
  auto level_0 = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  level_0->SetFor("Array", std::move(level_1));

  // We have <</Array [ stream( << /Length 0 >>) ]>>
  // In this case each step will increase depth.
  // And on each step the prev object should be parent for current.
  const CSGPDF_SDK_Object* cur_parent = nullptr;
  CSGPDF_SDK_ObjectWalker walker(level_0.Get());
  while (const CSGPDF_SDK_Object* obj = walker.GetNext()) {
    EXPECT_EQ(cur_parent, walker.GetParent());
    cur_parent = obj;
  }
}

TEST(CSGPDF_SDK_ObjectWalkerTest, SkipWalkIntoCurrentObject) {
  auto root_array = pdfium::MakeRetain<CSGPDF_SDK_Array>();
  // Add 2 null objects into |root_array|. [ null1, null2 ]
  root_array->AppendNew<CSGPDF_SDK_Null>();
  root_array->AppendNew<CSGPDF_SDK_Null>();
  // |root_array| will contain 4 null objects after this.
  // [ null1, null2, [ null3, null4 ] ]
  root_array->Append(root_array->Clone());

  int non_array_objects = 0;
  CSGPDF_SDK_ObjectWalker walker(root_array.Get());
  while (const CSGPDF_SDK_Object* obj = walker.GetNext()) {
    if (obj != root_array && obj->IsArray()) {
      // skip other array except root.
      walker.SkipWalkIntoCurrentObject();
    }
    if (!obj->IsArray())
      ++non_array_objects;
  }
  // 2 objects from child array should be skipped.
  EXPECT_EQ(2, non_array_objects);
}

TEST(CSGPDF_SDK_ObjectWalkerTest, DictionaryKey) {
  auto dict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  dict->SetFor("1", pdfium::MakeRetain<CSGPDF_SDK_Null>());
  dict->SetFor("2", pdfium::MakeRetain<CSGPDF_SDK_Null>());
  dict->SetFor("3", pdfium::MakeRetain<CSGPDF_SDK_Null>());
  dict->SetFor("4", pdfium::MakeRetain<CSGPDF_SDK_Null>());
  dict->SetFor("5", pdfium::MakeRetain<CSGPDF_SDK_Null>());

  CSGPDF_SDK_ObjectWalker walker(dict.Get());
  while (const CSGPDF_SDK_Object* obj = walker.GetNext()) {
    if (dict == obj) {
      // Ignore root dictinary object
      continue;
    }
    // Test that, dictionary key is correct.
    EXPECT_EQ(walker.GetParent()->AsDictionary()->GetObjectFor(
                  walker.dictionary_key()),
              obj);
  }
}
