// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_array.h"

#include <set>
#include <utility>

#include "core/fpdfapi/parser/sgpdf_boolean.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "core/fxcrt/fx_stream.h"
#include "third_party/base/check.h"
#include "third_party/base/notreached.h"
#include "third_party/base/stl_util.h"

CSGPDF_SDK_Array::CSGPDF_SDK_Array() = default;

CSGPDF_SDK_Array::CSGPDF_SDK_Array(const WeakPtr<ByteStringPool>& pPool) : m_pPool(pPool)
{
}

CSGPDF_SDK_Array::~CSGPDF_SDK_Array()
{
	// Break cycles for cyclic references.
	m_ObjNum = kInvalidObjNum;
	for (auto& it : m_Objects)
	{
		if (it && it->GetObjNum() == kInvalidObjNum)
			it.Leak();
	}
}

CSGPDF_SDK_Object::Type CSGPDF_SDK_Array::GetType() const
{
	return kArray;
}

bool CSGPDF_SDK_Array::IsArray() const
{
	return true;
}

CSGPDF_SDK_Array* CSGPDF_SDK_Array::AsArray()
{
	return this;
}

const CSGPDF_SDK_Array* CSGPDF_SDK_Array::AsArray() const
{
	return this;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Array::Clone() const
{
	return CloneObjectNonCyclic(false);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Array::CloneNonCyclic(
	bool bDirect,
	std::set<const CSGPDF_SDK_Object*>* pVisited) const
{
	pVisited->insert(this);
	auto pCopy = pdfium::MakeRetain<CSGPDF_SDK_Array>();
	for (const auto& pValue : m_Objects)
	{
		if (!pdfium::Contains(*pVisited, pValue.Get()))
		{
			std::set<const CSGPDF_SDK_Object*> visited(*pVisited);
			if (auto obj = pValue->CloneNonCyclic(bDirect, &visited))
				pCopy->m_Objects.push_back(std::move(obj));
		}
	}
	return pCopy;
}

CFX_FloatRect CSGPDF_SDK_Array::GetRect() const
{
	CFX_FloatRect rect;
	if (m_Objects.size() != 4)
		return rect;

	rect.left = GetNumberAt(0);
	rect.bottom = GetNumberAt(1);
	rect.right = GetNumberAt(2);
	rect.top = GetNumberAt(3);
	return rect;
}

CFX_Matrix CSGPDF_SDK_Array::GetMatrix() const
{
	if (m_Objects.size() != 6)
		return CFX_Matrix();

	return CFX_Matrix(GetNumberAt(0), GetNumberAt(1), GetNumberAt(2),
		GetNumberAt(3), GetNumberAt(4), GetNumberAt(5));
}

CSGPDF_SDK_Object* CSGPDF_SDK_Array::GetObjectAt(size_t index)
{
	if (index >= m_Objects.size())
		return nullptr;
	return m_Objects[index].Get();
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Array::GetObjectAt(size_t index) const
{
	if (index >= m_Objects.size())
		return nullptr;
	return m_Objects[index].Get();
}

CSGPDF_SDK_Object* CSGPDF_SDK_Array::GetDirectObjectAt(size_t index)
{
	if (index >= m_Objects.size())
		return nullptr;
	return m_Objects[index]->GetDirect();
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Array::GetDirectObjectAt(size_t index) const
{
	if (index >= m_Objects.size())
		return nullptr;
	return m_Objects[index]->GetDirect();
}

ByteString CSGPDF_SDK_Array::GetStringAt(size_t index) const
{
	if (index >= m_Objects.size())
		return ByteString();
	return m_Objects[index]->GetString();
}

WideString CSGPDF_SDK_Array::GetUnicodeTextAt(size_t index) const
{
	if (index >= m_Objects.size())
		return WideString();
	return m_Objects[index]->GetUnicodeText();
}

bool CSGPDF_SDK_Array::GetBooleanAt(size_t index, bool bDefault) const
{
	if (index >= m_Objects.size())
		return bDefault;
	const CSGPDF_SDK_Object* p = m_Objects[index].Get();
	return ToBoolean(p) ? p->GetInteger() != 0 : bDefault;
}

int CSGPDF_SDK_Array::GetIntegerAt(size_t index) const
{
	if (index >= m_Objects.size())
		return 0;
	return m_Objects[index]->GetInteger();
}

float CSGPDF_SDK_Array::GetNumberAt(size_t index) const
{
	if (index >= m_Objects.size())
		return 0;
	return m_Objects[index]->GetNumber();
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Array::GetDictAt(size_t index)
{
	CSGPDF_SDK_Object* p = GetDirectObjectAt(index);
	if (!p)
		return nullptr;
	if (CSGPDF_SDK_Dictionary* pDict = p->AsDictionary())
		return pDict;
	if (CSGPDF_SDK_Stream* pStream = p->AsStream())
		return pStream->GetDict();
	return nullptr;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Array::GetDictAt(size_t index) const
{
	const CSGPDF_SDK_Object* p = GetDirectObjectAt(index);
	if (!p)
		return nullptr;
	if (const CSGPDF_SDK_Dictionary* pDict = p->AsDictionary())
		return pDict;
	if (const CSGPDF_SDK_Stream* pStream = p->AsStream())
		return pStream->GetDict();
	return nullptr;
}

CSGPDF_SDK_Stream* CSGPDF_SDK_Array::GetStreamAt(size_t index)
{
	return ToStream(GetDirectObjectAt(index));
}

const CSGPDF_SDK_Stream* CSGPDF_SDK_Array::GetStreamAt(size_t index) const
{
	return ToStream(GetDirectObjectAt(index));
}

CSGPDF_SDK_Array* CSGPDF_SDK_Array::GetArrayAt(size_t index)
{
	return ToArray(GetDirectObjectAt(index));
}

const CSGPDF_SDK_Array* CSGPDF_SDK_Array::GetArrayAt(size_t index) const
{
	return ToArray(GetDirectObjectAt(index));
}

void CSGPDF_SDK_Array::Clear()
{
	CHECK(!IsLocked());
	m_Objects.clear();
}

void CSGPDF_SDK_Array::RemoveAt(size_t index)
{
	CHECK(!IsLocked());
	if (index < m_Objects.size())
		m_Objects.erase(m_Objects.begin() + index);
}

void CSGPDF_SDK_Array::ConvertToIndirectObjectAt(size_t index,
	CSGPDF_SDK_IndirectObjectHolder* pHolder)
{
	CHECK(!IsLocked());
	if (index >= m_Objects.size())
		return;

	if (!m_Objects[index] || m_Objects[index]->IsReference())
		return;

	CSGPDF_SDK_Object* pNew = pHolder->AddIndirectObject(std::move(m_Objects[index]));
	m_Objects[index] = pNew->MakeReference(pHolder);
}

CSGPDF_SDK_Object* CSGPDF_SDK_Array::SetAt(size_t index, RetainPtr<CSGPDF_SDK_Object> pObj)
{
	CHECK(!IsLocked());
	DCHECK(!pObj || pObj->IsInline());
	if (index >= m_Objects.size())
	{
		NOTREACHED();
		return nullptr;
	}
	CSGPDF_SDK_Object* pRet = pObj.Get();
	m_Objects[index] = std::move(pObj);
	return pRet;
}

CSGPDF_SDK_Object* CSGPDF_SDK_Array::InsertAt(size_t index, RetainPtr<CSGPDF_SDK_Object> pObj)
{
	CHECK(!IsLocked());
	CHECK(!pObj || pObj->IsInline());
	CSGPDF_SDK_Object* pRet = pObj.Get();
	if (index >= m_Objects.size())
	{
		// Allocate space first.
		m_Objects.resize(index + 1);
		m_Objects[index] = std::move(pObj);
	}
	else
	{
		// Directly insert.
		m_Objects.insert(m_Objects.begin() + index, std::move(pObj));
	}
	return pRet;
}

CSGPDF_SDK_Object* CSGPDF_SDK_Array::Append(RetainPtr<CSGPDF_SDK_Object> pObj)
{
	CHECK(!IsLocked());
	CHECK(!pObj || pObj->IsInline());
	CSGPDF_SDK_Object* pRet = pObj.Get();
	m_Objects.push_back(std::move(pObj));
	return pRet;
}

bool CSGPDF_SDK_Array::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	if (!archive->WriteString("["))
		return false;

	for (size_t i = 0; i < size(); ++i)
	{
		if (!GetObjectAt(i)->WriteTo(archive, encryptor))
			return false;
	}
	return archive->WriteString("]");
}

CSGPDF_SDK_ArrayLocker::CSGPDF_SDK_ArrayLocker(const CSGPDF_SDK_Array* pArray)
	: m_pArray(pArray)
{
	m_pArray->m_LockCount++;
}

CSGPDF_SDK_ArrayLocker::~CSGPDF_SDK_ArrayLocker()
{
	m_pArray->m_LockCount--;
}
