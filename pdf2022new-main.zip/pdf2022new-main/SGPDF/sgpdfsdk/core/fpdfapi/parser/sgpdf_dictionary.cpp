// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_dictionary.h"

#include <set>
#include <utility>

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_boolean.h"
#include "core/fpdfapi/parser/sgpdf_crypto_handler.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "core/fpdfapi/parser/fpdf_parser_utility.h"
#include "core/fxcrt/fx_stream.h"
#include "third_party/base/check.h"
#include "third_party/base/stl_util.h"

CSGPDF_SDK_Dictionary::CSGPDF_SDK_Dictionary()
	: CSGPDF_SDK_Dictionary(WeakPtr<ByteStringPool>())
{
}

CSGPDF_SDK_Dictionary::CSGPDF_SDK_Dictionary(const WeakPtr<ByteStringPool>& pPool)
	: m_pPool(pPool)
{
}

CSGPDF_SDK_Dictionary::~CSGPDF_SDK_Dictionary()
{
	// Mark the object as deleted so that it will not be deleted again,
	// and break cyclic references.
	m_ObjNum = kInvalidObjNum;
	for (auto& it : m_Map)
	{
		if (it.second && it.second->GetObjNum() == kInvalidObjNum)
			it.second.Leak();
	}
}

CSGPDF_SDK_Object::Type CSGPDF_SDK_Dictionary::GetType() const
{
	return kDictionary;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Dictionary::GetDict()
{
	return this;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Dictionary::GetDict() const
{
	return this;
}

bool CSGPDF_SDK_Dictionary::IsDictionary() const
{
	return true;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Dictionary::AsDictionary()
{
	return this;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Dictionary::AsDictionary() const
{
	return this;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Dictionary::Clone() const
{
	return CloneObjectNonCyclic(false);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Dictionary::CloneNonCyclic(
	bool bDirect,
	std::set<const CSGPDF_SDK_Object*>* pVisited) const
{
	pVisited->insert(this);
	auto pCopy = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(m_pPool);
	CSGPDF_SDK_DictionaryLocker locker(this);
	for (const auto& it : locker)
	{
		if (!pdfium::Contains(*pVisited, it.second.Get()))
		{
			std::set<const CSGPDF_SDK_Object*> visited(*pVisited);
			if (auto obj = it.second->CloneNonCyclic(bDirect, &visited))
				pCopy->m_Map.insert(std::make_pair(it.first, std::move(obj)));
		}
	}
	return pCopy;
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Dictionary::GetObjectFor(const ByteString& key) const
{
	auto it = m_Map.find(key);
	return it != m_Map.end() ? it->second.Get() : nullptr;
}

CSGPDF_SDK_Object* CSGPDF_SDK_Dictionary::GetObjectFor(const ByteString& key)
{
	return const_cast<CSGPDF_SDK_Object*>(
		static_cast<const CSGPDF_SDK_Dictionary*>(this)->GetObjectFor(key));
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Dictionary::GetDirectObjectFor(
	const ByteString& key) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return p ? p->GetDirect() : nullptr;
}

CSGPDF_SDK_Object* CSGPDF_SDK_Dictionary::GetDirectObjectFor(const ByteString& key)
{
	return const_cast<CSGPDF_SDK_Object*>(
		static_cast<const CSGPDF_SDK_Dictionary*>(this)->GetDirectObjectFor(key));
}

ByteString CSGPDF_SDK_Dictionary::GetStringFor(const ByteString& key) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return p ? p->GetString() : ByteString();
}

ByteString CSGPDF_SDK_Dictionary::GetStringFor(const ByteString& key,
	const ByteString& def) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return p ? p->GetString() : ByteString(def);
}

WideString CSGPDF_SDK_Dictionary::GetUnicodeTextFor(const ByteString& key) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	if (const CSGPDF_SDK_Reference* pRef = ToReference(p))
		p = pRef->GetDirect();
	return p ? p->GetUnicodeText() : WideString();
}

ByteString CSGPDF_SDK_Dictionary::GetNameFor(const ByteString& key) const
{
	const CSGPDF_SDK_Name* p = ToName(GetObjectFor(key));
	return p ? p->GetString() : ByteString();
}

bool CSGPDF_SDK_Dictionary::GetBooleanFor(const ByteString& key,
	bool bDefault) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return ToBoolean(p) ? p->GetInteger() != 0 : bDefault;
}

int CSGPDF_SDK_Dictionary::GetIntegerFor(const ByteString& key) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return p ? p->GetInteger() : 0;
}

int CSGPDF_SDK_Dictionary::GetIntegerFor(const ByteString& key, int def) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return p ? p->GetInteger() : def;
}

float CSGPDF_SDK_Dictionary::GetNumberFor(const ByteString& key) const
{
	const CSGPDF_SDK_Object* p = GetObjectFor(key);
	return p ? p->GetNumber() : 0;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Dictionary::GetDictFor(
	const ByteString& key) const
{
	const CSGPDF_SDK_Object* p = GetDirectObjectFor(key);
	if (!p)
		return nullptr;
	if (const CSGPDF_SDK_Dictionary* pDict = p->AsDictionary())
		return pDict;
	if (const CSGPDF_SDK_Stream* pStream = p->AsStream())
		return pStream->GetDict();
	return nullptr;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Dictionary::GetDictFor(const ByteString& key)
{
	return const_cast<CSGPDF_SDK_Dictionary*>(
		static_cast<const CSGPDF_SDK_Dictionary*>(this)->GetDictFor(key));
}

const CSGPDF_SDK_Array* CSGPDF_SDK_Dictionary::GetArrayFor(const ByteString& key) const
{
	return ToArray(GetDirectObjectFor(key));
}

CSGPDF_SDK_Array* CSGPDF_SDK_Dictionary::GetArrayFor(const ByteString& key)
{
	return ToArray(GetDirectObjectFor(key));
}

const CSGPDF_SDK_Stream* CSGPDF_SDK_Dictionary::GetStreamFor(const ByteString& key) const
{
	return ToStream(GetDirectObjectFor(key));
}

CSGPDF_SDK_Stream* CSGPDF_SDK_Dictionary::GetStreamFor(const ByteString& key)
{
	return ToStream(GetDirectObjectFor(key));
}

CFX_FloatRect CSGPDF_SDK_Dictionary::GetRectFor(const ByteString& key) const
{
	CFX_FloatRect rect;
	const CSGPDF_SDK_Array* pArray = GetArrayFor(key);
	if (pArray)
		rect = pArray->GetRect();
	return rect;
}

CFX_Matrix CSGPDF_SDK_Dictionary::GetMatrixFor(const ByteString& key) const
{
	CFX_Matrix matrix;
	const CSGPDF_SDK_Array* pArray = GetArrayFor(key);
	if (pArray)
		matrix = pArray->GetMatrix();
	return matrix;
}

bool CSGPDF_SDK_Dictionary::KeyExist(const ByteString& key) const
{
	return pdfium::Contains(m_Map, key);
}

std::vector<ByteString> CSGPDF_SDK_Dictionary::GetKeys() const
{
	std::vector<ByteString> result;
	CSGPDF_SDK_DictionaryLocker locker(this);
	for (const auto& item : locker)
		result.push_back(item.first);
	return result;
}

CSGPDF_SDK_Object* CSGPDF_SDK_Dictionary::SetFor(const ByteString& key,
	RetainPtr<CSGPDF_SDK_Object> pObj)
{
	CHECK(!IsLocked());
	if (!pObj)
	{
		m_Map.erase(key);
		return nullptr;
	}
	DCHECK(pObj->IsInline());
	CSGPDF_SDK_Object* pRet = pObj.Get();
	m_Map[MaybeIntern(key)] = std::move(pObj);
	return pRet;
}

void CSGPDF_SDK_Dictionary::ConvertToIndirectObjectFor(
	const ByteString& key,
	CSGPDF_SDK_IndirectObjectHolder* pHolder)
{
	CHECK(!IsLocked());
	auto it = m_Map.find(key);
	if (it == m_Map.end() || it->second->IsReference())
		return;

	CSGPDF_SDK_Object* pObj = pHolder->AddIndirectObject(std::move(it->second));
	it->second = pObj->MakeReference(pHolder);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Dictionary::RemoveFor(const ByteString& key)
{
	CHECK(!IsLocked());
	RetainPtr<CSGPDF_SDK_Object> result;
	auto it = m_Map.find(key);
	if (it != m_Map.end())
	{
		result = std::move(it->second);
		m_Map.erase(it);
	}
	return result;
}

void CSGPDF_SDK_Dictionary::ReplaceKey(const ByteString& oldkey,
	const ByteString& newkey)
{
	CHECK(!IsLocked());
	auto old_it = m_Map.find(oldkey);
	if (old_it == m_Map.end())
		return;

	auto new_it = m_Map.find(newkey);
	if (new_it == old_it)
		return;

	m_Map[MaybeIntern(newkey)] = std::move(old_it->second);
	m_Map.erase(old_it);
}

void CSGPDF_SDK_Dictionary::SetRectFor(const ByteString& key,
	const CFX_FloatRect& rect)
{
	CSGPDF_SDK_Array* pArray = SetNewFor<CSGPDF_SDK_Array>(key);
	pArray->AppendNew<CSGPDF_SDK_Number>(rect.left);
	pArray->AppendNew<CSGPDF_SDK_Number>(rect.bottom);
	pArray->AppendNew<CSGPDF_SDK_Number>(rect.right);
	pArray->AppendNew<CSGPDF_SDK_Number>(rect.top);
}

void CSGPDF_SDK_Dictionary::SetMatrixFor(const ByteString& key,
	const CFX_Matrix& matrix)
{
	CSGPDF_SDK_Array* pArray = SetNewFor<CSGPDF_SDK_Array>(key);
	pArray->AppendNew<CSGPDF_SDK_Number>(matrix.a);
	pArray->AppendNew<CSGPDF_SDK_Number>(matrix.b);
	pArray->AppendNew<CSGPDF_SDK_Number>(matrix.c);
	pArray->AppendNew<CSGPDF_SDK_Number>(matrix.d);
	pArray->AppendNew<CSGPDF_SDK_Number>(matrix.e);
	pArray->AppendNew<CSGPDF_SDK_Number>(matrix.f);
}

ByteString CSGPDF_SDK_Dictionary::MaybeIntern(const ByteString& str)
{
	return m_pPool ? m_pPool->Intern(str) : str;
}

bool CSGPDF_SDK_Dictionary::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	if (!archive->WriteString("<<"))
		return false;

	const bool is_signature = CSGPDF_SDK_CryptoHandler::IsSignatureDictionary(this);

	CSGPDF_SDK_DictionaryLocker locker(this);
	for (const auto& it : locker)
	{
		const ByteString& key = it.first;
		CSGPDF_SDK_Object* pValue = it.second.Get();
		if (!archive->WriteString("/") ||
			!archive->WriteString(PDF_NameEncode(key).AsStringView()))
		{
			return false;
		}
		if (!pValue->WriteTo(archive, !is_signature || key != "Contents"
			? encryptor
			: nullptr))
		{
			return false;
		}
	}
	return archive->WriteString(">>");
}

CSGPDF_SDK_DictionaryLocker::CSGPDF_SDK_DictionaryLocker(const CSGPDF_SDK_Dictionary* pDictionary)
	: m_pDictionary(pDictionary)
{
	m_pDictionary->m_LockCount++;
}

CSGPDF_SDK_DictionaryLocker::~CSGPDF_SDK_DictionaryLocker()
{
	m_pDictionary->m_LockCount--;
}
