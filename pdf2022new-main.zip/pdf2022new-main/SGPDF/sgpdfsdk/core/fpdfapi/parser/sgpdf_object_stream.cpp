// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/parser/sgpdf_object_stream.h"

#include <utility>

#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/sgpdf_stream_acc.h"
#include "core/fpdfapi/parser/sgpdf_syntax_parser.h"
#include "core/fxcrt/cfx_readonlymemorystream.h"
#include "core/fxcrt/fx_safe_types.h"
#include "third_party/base/check.h"
#include "third_party/base/ptr_util.h"
#include "third_party/base/stl_util.h"

// static
bool CSGPDF_SDK_ObjectStream::IsObjectsStreamObject(const CSGPDF_SDK_Object* object)
{
	const CSGPDF_SDK_Stream* stream = ToStream(object);
	if (!stream)
		return false;

	const CSGPDF_SDK_Dictionary* stream_dict = stream->GetDict();
	if (!stream_dict)
		return false;

	if (stream_dict->GetNameFor("Type") != "ObjStm")
		return false;

	const CSGPDF_SDK_Number* number_of_objects =
		ToNumber(stream_dict->GetObjectFor("N"));
	if (!number_of_objects || !number_of_objects->IsInteger() ||
		number_of_objects->GetInteger() < 0 ||
		number_of_objects->GetInteger() >=
		static_cast<int>(CSGPDF_SDK_Parser::kMaxObjectNumber))
	{
		return false;
	}

	const CSGPDF_SDK_Number* first_object_offset =
		ToNumber(stream_dict->GetObjectFor("First"));
	if (!first_object_offset || !first_object_offset->IsInteger() ||
		first_object_offset->GetInteger() < 0)
	{
		return false;
	}

	return true;
}

//  static
std::unique_ptr<CSGPDF_SDK_ObjectStream> CSGPDF_SDK_ObjectStream::Create(
	const CSGPDF_SDK_Stream* stream)
{
	if (!IsObjectsStreamObject(stream))
		return nullptr;

	// Protected constructor.
	return pdfium::WrapUnique(new CSGPDF_SDK_ObjectStream(stream));
}

CSGPDF_SDK_ObjectStream::CSGPDF_SDK_ObjectStream(const CSGPDF_SDK_Stream* obj_stream)
	: obj_num_(obj_stream->GetObjNum()),
	first_object_offset_(obj_stream->GetDict()->GetIntegerFor("First"))
{
	DCHECK(IsObjectsStreamObject(obj_stream));
	if (const auto* extends_ref =
		ToReference(obj_stream->GetDict()->GetObjectFor("Extends")))
	{
		extends_obj_num_ = extends_ref->GetRefObjNum();
	}
	Init(obj_stream);
}

CSGPDF_SDK_ObjectStream::~CSGPDF_SDK_ObjectStream() = default;

bool CSGPDF_SDK_ObjectStream::HasObject(uint32_t obj_number) const
{
	return pdfium::Contains(objects_offsets_, obj_number);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_ObjectStream::ParseObject(
	CSGPDF_SDK_IndirectObjectHolder* pObjList,
	uint32_t obj_number) const
{
	const auto it = objects_offsets_.find(obj_number);
	if (it == objects_offsets_.end())
		return nullptr;

	RetainPtr<CSGPDF_SDK_Object> result = ParseObjectAtOffset(pObjList, it->second);
	if (!result)
		return nullptr;

	result->SetObjNum(obj_number);
	return result;
}

void CSGPDF_SDK_ObjectStream::Init(const CSGPDF_SDK_Stream* stream)
{
	{
		auto stream_acc = pdfium::MakeRetain<CSGPDF_SDK_StreamAcc>(stream);
		stream_acc->LoadAllDataFiltered();
		const uint32_t data_size = stream_acc->GetSize();
		data_stream_ = pdfium::MakeRetain<CFX_ReadOnlyMemoryStream>(
			stream_acc->DetachData(), data_size);
	}

	CSGPDF_SDK_SyntaxParser syntax(data_stream_);
	const int object_count = stream->GetDict()->GetIntegerFor("N");
	for (int32_t i = object_count; i > 0; --i)
	{
		if (syntax.GetPos() >= data_stream_->GetSize())
			break;

		const uint32_t obj_num = syntax.GetDirectNum();
		const uint32_t obj_offset = syntax.GetDirectNum();
		if (!obj_num)
			continue;

		objects_offsets_[obj_num] = obj_offset;
	}
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_ObjectStream::ParseObjectAtOffset(
	CSGPDF_SDK_IndirectObjectHolder* pObjList,
	uint32_t object_offset) const
{
	FX_SAFE_FILESIZE offset_in_stream = first_object_offset_;
	offset_in_stream += object_offset;

	if (!offset_in_stream.IsValid())
		return nullptr;

	if (offset_in_stream.ValueOrDie() >= data_stream_->GetSize())
		return nullptr;

	CSGPDF_SDK_SyntaxParser syntax(data_stream_);
	syntax.SetPos(offset_in_stream.ValueOrDie());
	return syntax.GetObjectBody(pObjList);
}
