// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_SECURITY_HANDLER_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_SECURITY_HANDLER_H_

#include <memory>

#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"

#define FXCIPHER_NONE 0
#define FXCIPHER_RC4 1
#define FXCIPHER_AES 2
#define FXCIPHER_AES2 3

class CSGPDF_SDK_Array;
class CSGPDF_SDK_CryptoHandler;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Parser;

class CSGPDF_SDK_SecurityHandler : public Retainable {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  bool OnInit(const CSGPDF_SDK_Dictionary* pEncryptDict,
              const CSGPDF_SDK_Array* pIdArray,
              const ByteString& password);
  void OnCreate(CSGPDF_SDK_Dictionary* pEncryptDict,
                const CSGPDF_SDK_Array* pIdArray,
                const ByteString& user_password,
                const ByteString& owner_password);
  void OnCreate(CSGPDF_SDK_Dictionary* pEncryptDict,
                const CSGPDF_SDK_Array* pIdArray,
                const ByteString& user_password);

  uint32_t GetPermissions() const;
  bool IsMetadataEncrypted() const;

  CSGPDF_SDK_CryptoHandler* GetCryptoHandler() const {
    return m_pCryptoHandler.get();
  }

  // Take |password| and encode it, if necessary, based on the password encoding
  // conversion.
  ByteString GetEncodedPassword(ByteStringView password) const;

 private:
  enum PasswordEncodingConversion {
    kUnknown,
    kNone,
    kLatin1ToUtf8,
    kUtf8toLatin1,
  };

  CSGPDF_SDK_SecurityHandler();
  ~CSGPDF_SDK_SecurityHandler() override;

  bool LoadDict(const CSGPDF_SDK_Dictionary* pEncryptDict);
  bool LoadDict(const CSGPDF_SDK_Dictionary* pEncryptDict,
                int* cipher,
                size_t* key_len);

  ByteString GetUserPassword(const ByteString& owner_password) const;
  bool CheckPassword(const ByteString& user_password, bool bOwner);
  bool CheckPasswordImpl(const ByteString& password, bool bOwner);
  bool CheckUserPassword(const ByteString& password, bool bIgnoreEncryptMeta);
  bool CheckOwnerPassword(const ByteString& password);
  bool AES256_CheckPassword(const ByteString& password, bool bOwner);
  void AES256_SetPassword(CSGPDF_SDK_Dictionary* pEncryptDict,
                          const ByteString& password,
                          bool bOwner);
  void AES256_SetPerms(CSGPDF_SDK_Dictionary* pEncryptDict);
  void OnCreateInternal(CSGPDF_SDK_Dictionary* pEncryptDict,
                        const CSGPDF_SDK_Array* pIdArray,
                        const ByteString& user_password,
                        const ByteString& owner_password,
                        bool bDefault);
  bool CheckSecurity(const ByteString& password);

  void InitCryptoHandler();

  bool m_bOwnerUnlocked = false;
  int m_Version = 0;
  int m_Revision = 0;
  uint32_t m_Permissions = 0;
  int m_Cipher = FXCIPHER_NONE;
  size_t m_KeyLen = 0;
  PasswordEncodingConversion m_PasswordEncodingConversion = kUnknown;
  ByteString m_FileId;
  RetainPtr<const CSGPDF_SDK_Dictionary> m_pEncryptDict;
  std::unique_ptr<CSGPDF_SDK_CryptoHandler> m_pCryptoHandler;
  uint8_t m_EncryptKey[32];
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_SECURITY_HANDLER_H_
