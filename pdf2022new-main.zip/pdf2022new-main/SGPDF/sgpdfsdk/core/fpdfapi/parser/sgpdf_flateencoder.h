// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_FLATEENCODER_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_FLATEENCODER_H_

#include "core/fxcrt/fx_memory_wrappers.h"
#include "core/fxcrt/maybe_owned.h"
#include "core/fxcrt/retain_ptr.h"
#include "third_party/base/span.h"

class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Stream;
class CSGPDF_SDK_StreamAcc;

class CSGPDF_SDK_FlateEncoder {
 public:
  CSGPDF_SDK_FlateEncoder(const CSGPDF_SDK_Stream* pStream, bool bFlateEncode);
  ~CSGPDF_SDK_FlateEncoder();

  void CloneDict();
  CSGPDF_SDK_Dictionary* GetClonedDict();

  // Returns |m_pClonedDict| if it is valid. Otherwise returns |m_pDict|.
  const CSGPDF_SDK_Dictionary* GetDict() const;

  pdfium::span<const uint8_t> GetSpan() const {
    return pdfium::make_span(m_pData.Get(), m_dwSize);
  }

 private:
  RetainPtr<CSGPDF_SDK_StreamAcc> m_pAcc;

  uint32_t m_dwSize;
  MaybeOwned<uint8_t, FxFreeDeleter> m_pData;

  // Only one of these two pointers is valid at any time.
  RetainPtr<const CSGPDF_SDK_Dictionary> m_pDict;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pClonedDict;
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_FLATEENCODER_H_
