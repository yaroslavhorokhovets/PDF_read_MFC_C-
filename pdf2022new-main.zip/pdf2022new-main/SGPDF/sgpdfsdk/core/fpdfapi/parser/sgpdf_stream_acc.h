// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_STREAM_ACC_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_STREAM_ACC_H_

#include <memory>

#include "core/fxcrt/fx_memory_wrappers.h"
#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/maybe_owned.h"
#include "core/fxcrt/retain_ptr.h"
#include "third_party/base/span.h"

class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Stream;

class CSGPDF_SDK_StreamAcc final : public Retainable {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  CSGPDF_SDK_StreamAcc(const CSGPDF_SDK_StreamAcc&) = delete;
  CSGPDF_SDK_StreamAcc& operator=(const CSGPDF_SDK_StreamAcc&) = delete;

  void LoadAllDataFiltered();
  void LoadAllDataFilteredWithEstimatedSize(uint32_t estimated_size);
  void LoadAllDataImageAcc(uint32_t estimated_size);
  void LoadAllDataRaw();

  const CSGPDF_SDK_Stream* GetStream() const { return m_pStream.Get(); }
  const CSGPDF_SDK_Dictionary* GetDict() const;

  uint8_t* GetData() const;
  uint32_t GetSize() const;
  pdfium::span<uint8_t> GetSpan();
  pdfium::span<const uint8_t> GetSpan() const;
  ByteString ComputeDigest() const;
  ByteString GetImageDecoder() const { return m_ImageDecoder; }
  const CSGPDF_SDK_Dictionary* GetImageParam() const { return m_pImageParam.Get(); }
  std::unique_ptr<uint8_t, FxFreeDeleter> DetachData();

 private:
  explicit CSGPDF_SDK_StreamAcc(const CSGPDF_SDK_Stream* pStream);
  ~CSGPDF_SDK_StreamAcc() override;

  void LoadAllData(bool bRawAccess, uint32_t estimated_size, bool bImageAcc);
  void ProcessRawData();
  void ProcessFilteredData(uint32_t estimated_size, bool bImageAcc);

  // Reads the raw data from |m_pStream|, or return nullptr on failure.
  std::unique_ptr<uint8_t, FxFreeDeleter> ReadRawStream() const;

  MaybeOwned<uint8_t, FxFreeDeleter> m_pData;
  uint32_t m_dwSize = 0;
  ByteString m_ImageDecoder;
  RetainPtr<const CSGPDF_SDK_Dictionary> m_pImageParam;
  RetainPtr<const CSGPDF_SDK_Stream> const m_pStream;
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_STREAM_ACC_H_
