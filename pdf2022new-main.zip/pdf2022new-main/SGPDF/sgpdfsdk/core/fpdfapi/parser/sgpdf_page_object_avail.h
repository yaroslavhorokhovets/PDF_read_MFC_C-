// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_PAGE_OBJECT_AVAIL_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_PAGE_OBJECT_AVAIL_H_

#include "core/fpdfapi/parser/sgpdf_object_avail.h"

// Helper for check availability of page's object tree.
// Exclude references to pages.
class CSGPDF_SDK_PageObjectAvail final : public CSGPDF_SDK_ObjectAvail {
 public:
  using CSGPDF_SDK_ObjectAvail::CSGPDF_SDK_ObjectAvail;
  ~CSGPDF_SDK_PageObjectAvail() override;

 private:
  bool ExcludeObject(const CSGPDF_SDK_Object* object) const override;
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_PAGE_OBJECT_AVAIL_H_
