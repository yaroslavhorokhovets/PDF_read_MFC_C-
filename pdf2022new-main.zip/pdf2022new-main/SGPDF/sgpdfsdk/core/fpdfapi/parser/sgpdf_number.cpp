// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_number.h"

#include "core/fxcrt/fx_stream.h"

CSGPDF_SDK_Number::CSGPDF_SDK_Number() = default;

CSGPDF_SDK_Number::CSGPDF_SDK_Number(int value) : m_Number(value)
{
}

CSGPDF_SDK_Number::CSGPDF_SDK_Number(float value) : m_Number(value)
{
}

CSGPDF_SDK_Number::CSGPDF_SDK_Number(ByteStringView str) : m_Number(str)
{
}

CSGPDF_SDK_Number::~CSGPDF_SDK_Number() = default;

CSGPDF_SDK_Object::Type CSGPDF_SDK_Number::GetType() const
{
	return kNumber;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Number::Clone() const
{
	return m_Number.IsInteger()
		? pdfium::MakeRetain<CSGPDF_SDK_Number>(m_Number.GetSigned())
		: pdfium::MakeRetain<CSGPDF_SDK_Number>(m_Number.GetFloat());
}

float CSGPDF_SDK_Number::GetNumber() const
{
	return m_Number.GetFloat();
}

int CSGPDF_SDK_Number::GetInteger() const
{
	return m_Number.GetSigned();
}

bool CSGPDF_SDK_Number::IsNumber() const
{
	return true;
}

CSGPDF_SDK_Number* CSGPDF_SDK_Number::AsNumber()
{
	return this;
}

const CSGPDF_SDK_Number* CSGPDF_SDK_Number::AsNumber() const
{
	return this;
}

void CSGPDF_SDK_Number::SetString(const ByteString& str)
{
	m_Number = FX_Number(str.AsStringView());
}

ByteString CSGPDF_SDK_Number::GetString() const
{
	return m_Number.IsInteger() ? ByteString::FormatInteger(m_Number.GetSigned())
		: ByteString::FormatFloat(m_Number.GetFloat());
}

bool CSGPDF_SDK_Number::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	return archive->WriteString(" ") &&
		archive->WriteString(GetString().AsStringView());
}
