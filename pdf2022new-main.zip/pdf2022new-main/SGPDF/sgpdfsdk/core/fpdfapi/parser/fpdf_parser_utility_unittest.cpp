// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/parser/fpdf_parser_utility.h"

#include <memory>

#include "core/fpdfapi/page/sgpdf_docpagedata.h"
#include "core/fpdfapi/page/sgpdf_pagemodule.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "core/fpdfapi/render/sgpdf_docrenderdata.h"
#include "testing/gtest/include/gtest/gtest.h"

TEST(fpdf_parser_utility, PDF_NameDecode) {
  EXPECT_EQ("", PDF_NameDecode(""));
  EXPECT_EQ("A", PDF_NameDecode("A"));
  EXPECT_EQ("#", PDF_NameDecode("#"));
  EXPECT_EQ("#4", PDF_NameDecode("#4"));
  EXPECT_EQ("A", PDF_NameDecode("#41"));
  EXPECT_EQ("A1", PDF_NameDecode("#411"));
}

TEST(fpdf_parser_utility, PDF_NameEncode) {
  EXPECT_EQ("", PDF_NameEncode(""));
  EXPECT_EQ("A", PDF_NameEncode("A"));
  EXPECT_EQ("#23", PDF_NameEncode("#"));
  EXPECT_EQ("#20", PDF_NameEncode(" "));
  EXPECT_EQ("!@#23$#25^&*#28#29#3C#3E#5B#5D", PDF_NameEncode("!@#$%^&*()<>[]"));
  EXPECT_EQ("#C2", PDF_NameEncode("\xc2"));
  EXPECT_EQ("f#C2#A5", PDF_NameEncode("f\xc2\xa5"));
}

TEST(fpdf_parser_utility, ValidateDictType) {
  auto dict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();

  // No type.
  EXPECT_FALSE(ValidateDictType(dict.Get(), "foo"));
  EXPECT_FALSE(ValidateDictType(dict.Get(), "bar"));

  // Add the wrong object type.
  dict->SetNewFor<CSGPDF_SDK_String>("Type", L"foo");
  EXPECT_FALSE(ValidateDictType(dict.Get(), "foo"));
  EXPECT_FALSE(ValidateDictType(dict.Get(), "bar"));

  // Add the correct object type.
  dict->SetNewFor<CSGPDF_SDK_Name>("Type", "foo");
  EXPECT_TRUE(ValidateDictType(dict.Get(), "foo"));
  EXPECT_FALSE(ValidateDictType(dict.Get(), "bar"));
}

TEST(fpdf_parser_utility, ValidateDictAllResourcesOfType) {
  CSGPDF_SDK_PageModule::Create();

  {
    // Direct dictionary.
    auto dict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();

    // Empty dict is ok.
    EXPECT_TRUE(ValidateDictAllResourcesOfType(dict.Get(), "foo"));
    EXPECT_TRUE(ValidateDictAllResourcesOfType(dict.Get(), "bar"));

    // nullptr is not.
    EXPECT_FALSE(ValidateDictAllResourcesOfType(nullptr, "foo"));
    EXPECT_FALSE(ValidateDictAllResourcesOfType(nullptr, "bar"));

    // Add two correct dictionary entries and one string entry.
    CSGPDF_SDK_Dictionary* new_dict = dict->SetNewFor<CSGPDF_SDK_Dictionary>("f1");
    new_dict->SetNewFor<CSGPDF_SDK_Name>("Type", "foo");
    new_dict = dict->SetNewFor<CSGPDF_SDK_Dictionary>("f2");
    new_dict->SetNewFor<CSGPDF_SDK_Name>("Type", "foo");
    dict->SetNewFor<CSGPDF_SDK_String>("f3", L"foo");
    EXPECT_FALSE(ValidateDictAllResourcesOfType(dict.Get(), "foo"));
    EXPECT_FALSE(ValidateDictAllResourcesOfType(dict.Get(), "bar"));

    // Change the string entry to a dictionary, but with the wrong /Type.
    new_dict = dict->SetNewFor<CSGPDF_SDK_Dictionary>("f3");
    new_dict->SetNewFor<CSGPDF_SDK_Name>("Type", "bar");
    EXPECT_FALSE(ValidateDictAllResourcesOfType(dict.Get(), "foo"));
    EXPECT_FALSE(ValidateDictAllResourcesOfType(dict.Get(), "bar"));

    // Change the /Type to match.
    new_dict->SetNewFor<CSGPDF_SDK_Name>("Type", "foo");
    EXPECT_TRUE(ValidateDictAllResourcesOfType(dict.Get(), "foo"));
    EXPECT_FALSE(ValidateDictAllResourcesOfType(dict.Get(), "bar"));
  }

  {
    // Indirect dictionary.
    auto doc =
        std::make_unique<CSGPDF_SDK_Document>(std::make_unique<CSGPDF_SDK_DocRenderData>(),
                                        std::make_unique<CSGPDF_SDK_DocPageData>());

    auto dict = doc->New<CSGPDF_SDK_Dictionary>();

    // Add a correct dictionary entry.
    CSGPDF_SDK_Dictionary* new_dict = doc->NewIndirect<CSGPDF_SDK_Dictionary>();
    new_dict->SetNewFor<CSGPDF_SDK_Name>("Type", "foo");
    dict->SetNewFor<CSGPDF_SDK_Reference>("f1", doc.get(), new_dict->GetObjNum());

    EXPECT_TRUE(ValidateDictAllResourcesOfType(dict.Get(), "foo"));
    EXPECT_FALSE(ValidateDictAllResourcesOfType(dict.Get(), "bar"));
  }

  CSGPDF_SDK_PageModule::Destroy();
}
