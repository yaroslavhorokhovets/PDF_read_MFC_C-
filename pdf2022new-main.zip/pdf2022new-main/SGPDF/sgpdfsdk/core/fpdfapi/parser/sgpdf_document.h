// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_DOCUMENT_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_DOCUMENT_H_

#include <memory>
#include <set>
#include <utility>
#include <vector>

#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "core/fxcrt/observed_ptr.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_ReadValidator;
class CSGPDF_SDK_StreamAcc;
class IFX_SeekableReadStream;
class JBig2_DocumentContext;

class CSGPDF_SDK_Document : public Observable,
	public CSGPDF_SDK_Parser::ParsedObjectsHolder
{
	public:
	// Type from which the XFA extension can subclass itself.
	class Extension
	{
		public:
		virtual ~Extension() = default;
		virtual CSGPDF_SDK_Document* GetPDFDoc() const = 0;
		virtual int GetPageCount() const = 0;
		virtual void DeletePage(int page_index) = 0;
		virtual uint32_t GetUserPermissions() const = 0;
		virtual bool ContainsExtensionForm() const = 0;
		virtual bool ContainsExtensionFullForm() const = 0;
		virtual bool ContainsExtensionForegroundForm() const = 0;
	};

	class LinkListIface
	{
		public:
		// CSGPDF_SDK_Document merely helps manage the lifetime.
		virtual ~LinkListIface() = default;
	};

	class PageDataIface
	{
		public:
		PageDataIface();
		virtual ~PageDataIface();

		virtual void ClearStockFont() = 0;
		virtual RetainPtr<CSGPDF_SDK_StreamAcc> GetFontFileStreamAcc(
			const CSGPDF_SDK_Stream* pFontStream) = 0;
		virtual void MaybePurgeFontFileStreamAcc(
			const CSGPDF_SDK_Stream* pFontStream) = 0;

		void SetDocument(CSGPDF_SDK_Document* pDoc)
		{
			m_pDoc = pDoc;
		}
		CSGPDF_SDK_Document* GetDocument() const
		{
			return m_pDoc.Get();
		}

		private:
		UnownedPtr<CSGPDF_SDK_Document> m_pDoc;
	};

	class RenderDataIface
	{
		public:
		RenderDataIface();
		virtual ~RenderDataIface();

		void SetDocument(CSGPDF_SDK_Document* pDoc)
		{
			m_pDoc = pDoc;
		}
		CSGPDF_SDK_Document* GetDocument() const
		{
			return m_pDoc.Get();
		}

		private:
		UnownedPtr<CSGPDF_SDK_Document> m_pDoc;
	};

	static constexpr int kPageMaxNum = 0xFFFFF;

	static bool IsValidPageObject(const CSGPDF_SDK_Object* obj);

	CSGPDF_SDK_Document(std::unique_ptr<RenderDataIface> pRenderData,
		std::unique_ptr<PageDataIface> pPageData);
	~CSGPDF_SDK_Document() override;

	Extension* GetExtension() const
	{
		return m_pExtension.get();
	}
	void SetExtension(std::unique_ptr<Extension> pExt)
	{
		m_pExtension = std::move(pExt);
	}

	CSGPDF_SDK_Parser* GetParser() const
	{
		return m_pParser.get();
	}
	CSGPDF_SDK_Dictionary* GetRoot() const
	{
		return m_pRootDict.Get();
	}
	CSGPDF_SDK_Dictionary* GetInfo();
	const CSGPDF_SDK_Array* GetFileIdentifier() const;

	void DeletePage(int iPage);
	int GetPageCount() const;
	bool IsPageLoaded(int iPage) const;
	CSGPDF_SDK_Dictionary* GetPageDictionary(int iPage);
	int GetPageIndex(uint32_t objnum);
	uint32_t GetUserPermissions() const;

	// Returns a valid pointer, unless it is called during destruction.
	PageDataIface* GetPageData() const
	{
		return m_pDocPage.get();
	}
	RenderDataIface* GetRenderData() const
	{
		return m_pDocRender.get();
	}

	void SetPageObjNum(int iPage, uint32_t objNum);

	JBig2_DocumentContext* GetOrCreateCodecContext();
	LinkListIface* GetLinksContext() const
	{
		return m_pLinksContext.get();
	}
	void SetLinksContext(std::unique_ptr<LinkListIface> pContext)
	{
		m_pLinksContext = std::move(pContext);
	}

	// CSGPDF_SDK_Parser::ParsedObjectsHolder:
	bool TryInit() override;
	RetainPtr<CSGPDF_SDK_Object> ParseIndirectObject(uint32_t objnum) override;

	CSGPDF_SDK_Parser::Error LoadDoc(
		const RetainPtr<IFX_SeekableReadStream>& pFileAccess,
		const char* password);
	CSGPDF_SDK_Parser::Error LoadLinearizedDoc(
		const RetainPtr<CSGPDF_SDK_ReadValidator>& validator,
		const char* password);
	bool has_valid_cross_reference_table() const
	{
		return m_bHasValidCrossReferenceTable;
	}

	void LoadPages();
	void CreateNewDoc();
	CSGPDF_SDK_Dictionary* CreateNewPage(int iPage);

	void IncrementParsedPageCount()
	{
		++m_ParsedPageCount;
	}
	uint32_t GetParsedPageCountForTesting()
	{
		return m_ParsedPageCount;
	}

	protected:
	void SetParser(std::unique_ptr<CSGPDF_SDK_Parser> pParser);

	void SetRootForTesting(CSGPDF_SDK_Dictionary* root);
	void ResizePageListForTesting(size_t size);

	private:
	class StockFontClearer
	{
		public:
		explicit StockFontClearer(CSGPDF_SDK_Document::PageDataIface* pPageData);
		~StockFontClearer();

		private:
		UnownedPtr<CSGPDF_SDK_Document::PageDataIface> const m_pPageData;
	};

	// Retrieve page count information by getting count value from the tree nodes
	int RetrievePageCount();
	// When this method is called, m_pTreeTraversal[level] exists.
	CSGPDF_SDK_Dictionary* TraversePDFPages(int iPage, int* nPagesToGo, size_t level);

	const CSGPDF_SDK_Dictionary* GetPagesDict() const;
	CSGPDF_SDK_Dictionary* GetPagesDict();

	bool InsertDeletePDFPage(CSGPDF_SDK_Dictionary* pPages,
		int nPagesToGo,
		CSGPDF_SDK_Dictionary* pPageDict,
		bool bInsert,
		std::set<CSGPDF_SDK_Dictionary*>* pVisited);
	bool InsertNewPage(int iPage, CSGPDF_SDK_Dictionary* pPageDict);
	void ResetTraversal();
	CSGPDF_SDK_Parser::Error HandleLoadResult(CSGPDF_SDK_Parser::Error error);

	std::unique_ptr<CSGPDF_SDK_Parser> m_pParser;
	RetainPtr<CSGPDF_SDK_Dictionary> m_pRootDict;
	RetainPtr<CSGPDF_SDK_Dictionary> m_pInfoDict;

	// Vector of pairs to know current position in the page tree. The index in the
	// vector corresponds to the level being described. The pair contains a
	// pointer to the dictionary being processed at the level, and an index of the
	// of the child being processed within the dictionary's /Kids array.
	std::vector<std::pair<CSGPDF_SDK_Dictionary*, size_t>> m_pTreeTraversal;

	// True if the CSGPDF_SDK_Parser succeeded without having to rebuild the cross
	// reference table.
	bool m_bHasValidCrossReferenceTable = false;

	// Index of the next page that will be traversed from the page tree.
	bool m_bReachedMaxPageLevel = false;
	int m_iNextPageToTraverse = 0;
	uint32_t m_ParsedPageCount = 0;

	std::unique_ptr<RenderDataIface> m_pDocRender;
	std::unique_ptr<PageDataIface> m_pDocPage;  // Must be after |m_pDocRender|.
	std::unique_ptr<JBig2_DocumentContext> m_pCodecContext;
	std::unique_ptr<LinkListIface> m_pLinksContext;
	std::vector<uint32_t> m_PageList;  // Page number to page's dict objnum.

	// Must be second to last.
	StockFontClearer m_StockFontClearer;

	// Must be last. Destroy the extension before any non-extension teardown.
	std::unique_ptr<Extension> m_pExtension;
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_DOCUMENT_H_
