// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_stream_acc.h"

#include <utility>
#include <vector>

#include "core/fdrm/fx_crypt.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/fpdf_parser_decode.h"
#include "third_party/base/check.h"

CSGPDF_SDK_StreamAcc::CSGPDF_SDK_StreamAcc(const CSGPDF_SDK_Stream* pStream)
	: m_pStream(pStream)
{
}

CSGPDF_SDK_StreamAcc::~CSGPDF_SDK_StreamAcc() = default;

void CSGPDF_SDK_StreamAcc::LoadAllData(bool bRawAccess,
	uint32_t estimated_size,
	bool bImageAcc)
{
	if (bRawAccess)
	{
		DCHECK(!estimated_size);
		DCHECK(!bImageAcc);
	}

	if (!m_pStream)
		return;

	bool bProcessRawData = bRawAccess || !m_pStream->HasFilter();
	if (bProcessRawData)
		ProcessRawData();
	else
		ProcessFilteredData(estimated_size, bImageAcc);
}

void CSGPDF_SDK_StreamAcc::LoadAllDataFiltered()
{
	LoadAllData(false, 0, false);
}

void CSGPDF_SDK_StreamAcc::LoadAllDataFilteredWithEstimatedSize(
	uint32_t estimated_size)
{
	LoadAllData(false, estimated_size, false);
}

void CSGPDF_SDK_StreamAcc::LoadAllDataImageAcc(uint32_t estimated_size)
{
	LoadAllData(false, estimated_size, true);
}

void CSGPDF_SDK_StreamAcc::LoadAllDataRaw()
{
	LoadAllData(true, 0, false);
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_StreamAcc::GetDict() const
{
	return m_pStream ? m_pStream->GetDict() : nullptr;
}

uint8_t* CSGPDF_SDK_StreamAcc::GetData() const
{
	if (m_pData.IsOwned())
		return m_pData.Get();
	return m_pStream ? m_pStream->GetInMemoryRawData() : nullptr;
}

uint32_t CSGPDF_SDK_StreamAcc::GetSize() const
{
	if (m_pData.IsOwned())
		return m_dwSize;
	return (m_pStream && m_pStream->IsMemoryBased()) ? m_pStream->GetRawSize()
		: 0;
}

pdfium::span<uint8_t> CSGPDF_SDK_StreamAcc::GetSpan()
{
	return { GetData(), GetSize() };
}

pdfium::span<const uint8_t> CSGPDF_SDK_StreamAcc::GetSpan() const
{
	return { GetData(), GetSize() };
}

ByteString CSGPDF_SDK_StreamAcc::ComputeDigest() const
{
	uint8_t digest[20];
	CRYPT_SHA1Generate(GetData(), GetSize(), digest);
	return ByteString(digest, 20);
}

std::unique_ptr<uint8_t, FxFreeDeleter> CSGPDF_SDK_StreamAcc::DetachData()
{
	if (m_pData.IsOwned())
	{
		std::unique_ptr<uint8_t, FxFreeDeleter> p = m_pData.ReleaseAndClear();
		m_dwSize = 0;
		return p;
	}
	std::unique_ptr<uint8_t, FxFreeDeleter> p(FX_AllocUninit(uint8_t, m_dwSize));
	memcpy(p.get(), m_pData.Get(), m_dwSize);
	return p;
}

void CSGPDF_SDK_StreamAcc::ProcessRawData()
{
	uint32_t dwSrcSize = m_pStream->GetRawSize();
	if (dwSrcSize == 0)
		return;

	if (m_pStream->IsMemoryBased())
	{
		m_pData = m_pStream->GetInMemoryRawData();
		m_dwSize = dwSrcSize;
		return;
	}

	std::unique_ptr<uint8_t, FxFreeDeleter> pData = ReadRawStream();
	if (!pData)
		return;

	m_pData = std::move(pData);
	m_dwSize = dwSrcSize;
}

void CSGPDF_SDK_StreamAcc::ProcessFilteredData(uint32_t estimated_size,
	bool bImageAcc)
{
	uint32_t dwSrcSize = m_pStream->GetRawSize();
	if (dwSrcSize == 0)
		return;

	MaybeOwned<uint8_t, FxFreeDeleter> pSrcData;
	if (m_pStream->IsMemoryBased())
	{
		pSrcData = m_pStream->GetInMemoryRawData();
	}
	else
	{
		std::unique_ptr<uint8_t, FxFreeDeleter> pTempSrcData = ReadRawStream();
		if (!pTempSrcData)
			return;

		pSrcData = std::move(pTempSrcData);
	}

	std::unique_ptr<uint8_t, FxFreeDeleter> pDecodedData;
	uint32_t dwDecodedSize = 0;

	Optional<std::vector<std::pair<ByteString, const CSGPDF_SDK_Object*>>>
		decoder_array = GetDecoderArray(m_pStream->GetDict());
	if (!decoder_array.has_value() || decoder_array.value().empty() ||
		!PDF_DataDecode({ pSrcData.Get(), dwSrcSize }, estimated_size, bImageAcc,
			decoder_array.value(), &pDecodedData, &dwDecodedSize,
			&m_ImageDecoder, &m_pImageParam))
	{
		m_pData = std::move(pSrcData);
		m_dwSize = dwSrcSize;
		return;
	}

	if (pDecodedData)
	{
		DCHECK(pDecodedData.get() != pSrcData.Get());
		m_pData = std::move(pDecodedData);
		m_dwSize = dwDecodedSize;
	}
	else
	{
		m_pData = std::move(pSrcData);
		m_dwSize = dwSrcSize;
	}
}

std::unique_ptr<uint8_t, FxFreeDeleter> CSGPDF_SDK_StreamAcc::ReadRawStream() const
{
	DCHECK(m_pStream);
	DCHECK(!m_pStream->IsMemoryBased());

	uint32_t dwSrcSize = m_pStream->GetRawSize();
	DCHECK(dwSrcSize);
	std::unique_ptr<uint8_t, FxFreeDeleter> pSrcData(
		FX_Alloc(uint8_t, dwSrcSize));
	if (!m_pStream->ReadRawData(0, pSrcData.get(), dwSrcSize))
		return nullptr;
	return pSrcData;
}
