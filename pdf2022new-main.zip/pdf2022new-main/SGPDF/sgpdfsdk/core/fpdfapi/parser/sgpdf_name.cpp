// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_name.h"

#include "core/fpdfapi/parser/fpdf_parser_decode.h"
#include "core/fpdfapi/parser/fpdf_parser_utility.h"
#include "core/fxcrt/fx_stream.h"

CSGPDF_SDK_Name::CSGPDF_SDK_Name(WeakPtr<ByteStringPool> pPool, const ByteString& str)
	: m_Name(str)
{
	if (pPool)
		m_Name = pPool->Intern(m_Name);
}

CSGPDF_SDK_Name::~CSGPDF_SDK_Name() = default;

CSGPDF_SDK_Object::Type CSGPDF_SDK_Name::GetType() const
{
	return kName;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Name::Clone() const
{
	return pdfium::MakeRetain<CSGPDF_SDK_Name>(nullptr, m_Name);
}

ByteString CSGPDF_SDK_Name::GetString() const
{
	return m_Name;
}

void CSGPDF_SDK_Name::SetString(const ByteString& str)
{
	m_Name = str;
}

bool CSGPDF_SDK_Name::IsName() const
{
	return true;
}

CSGPDF_SDK_Name* CSGPDF_SDK_Name::AsName()
{
	return this;
}

const CSGPDF_SDK_Name* CSGPDF_SDK_Name::AsName() const
{
	return this;
}

WideString CSGPDF_SDK_Name::GetUnicodeText() const
{
	return PDF_DecodeText(m_Name.raw_span());
}

bool CSGPDF_SDK_Name::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	return archive->WriteString("/") &&
		archive->WriteString(PDF_NameEncode(GetString()).AsStringView());
}
