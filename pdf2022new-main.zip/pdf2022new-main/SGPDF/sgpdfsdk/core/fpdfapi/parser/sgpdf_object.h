// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_H_

#include <memory>
#include <set>
#include <type_traits>

#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_Array;
class CSGPDF_SDK_Boolean;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Encryptor;
class CSGPDF_SDK_IndirectObjectHolder;
class CSGPDF_SDK_Name;
class CSGPDF_SDK_Null;
class CSGPDF_SDK_Number;
class CSGPDF_SDK_Reference;
class CSGPDF_SDK_Stream;
class CSGPDF_SDK_String;
class IFX_ArchiveStream;

class CSGPDF_SDK_Object : public Retainable
{
	public:
	static constexpr uint32_t kInvalidObjNum = static_cast<uint32_t>(-1);
	enum Type
	{
		kBoolean = 1,
		kNumber,
		kString,
		kName,
		kArray,
		kDictionary,
		kStream,
		kNullobj,
		kReference
	};

	virtual Type GetType() const = 0;
	uint32_t GetObjNum() const
	{
		return m_ObjNum;
	}
	void SetObjNum(uint32_t objnum)
	{
		m_ObjNum = objnum;
	}
	uint32_t GetGenNum() const
	{
		return m_GenNum;
	}
	void SetGenNum(uint32_t gennum)
	{
		m_GenNum = gennum;
	}
	bool IsInline() const
	{
		return m_ObjNum == 0;
	}

	// Create a deep copy of the object.
	virtual RetainPtr<CSGPDF_SDK_Object> Clone() const = 0;

	// Create a deep copy of the object except any reference object be
	// copied to the object it points to directly.
	virtual RetainPtr<CSGPDF_SDK_Object> CloneDirectObject() const;

	virtual CSGPDF_SDK_Object* GetDirect();
	virtual const CSGPDF_SDK_Object* GetDirect() const;
	virtual ByteString GetString() const;
	virtual WideString GetUnicodeText() const;
	virtual float GetNumber() const;
	virtual int GetInteger() const;
	virtual CSGPDF_SDK_Dictionary* GetDict();
	virtual const CSGPDF_SDK_Dictionary* GetDict() const;

	virtual void SetString(const ByteString& str);

	virtual bool IsArray() const;
	virtual bool IsBoolean() const;
	virtual bool IsDictionary() const;
	virtual bool IsName() const;
	virtual bool IsNumber() const;
	virtual bool IsReference() const;
	virtual bool IsStream() const;
	virtual bool IsString() const;
	virtual bool IsNull() const;

	virtual CSGPDF_SDK_Array* AsArray();
	virtual const CSGPDF_SDK_Array* AsArray() const;
	virtual CSGPDF_SDK_Boolean* AsBoolean();
	virtual const CSGPDF_SDK_Boolean* AsBoolean() const;
	virtual CSGPDF_SDK_Dictionary* AsDictionary();
	virtual const CSGPDF_SDK_Dictionary* AsDictionary() const;
	virtual CSGPDF_SDK_Name* AsName();
	virtual const CSGPDF_SDK_Name* AsName() const;
	virtual CSGPDF_SDK_Number* AsNumber();
	virtual const CSGPDF_SDK_Number* AsNumber() const;
	virtual CSGPDF_SDK_Reference* AsReference();
	virtual const CSGPDF_SDK_Reference* AsReference() const;
	virtual CSGPDF_SDK_Stream* AsStream();
	virtual const CSGPDF_SDK_Stream* AsStream() const;
	virtual CSGPDF_SDK_String* AsString();
	virtual const CSGPDF_SDK_String* AsString() const;

	virtual bool WriteTo(IFX_ArchiveStream* archive,
		const CSGPDF_SDK_Encryptor* encryptor) const = 0;

	// Create a deep copy of the object with the option to either
	// copy a reference object or directly copy the object it refers to
	// when |bDirect| is true.
	// Also check cyclic reference against |pVisited|, no copy if it is found.
	// Complex objects should implement their own CloneNonCyclic()
	// function to properly check for possible loop.
	virtual RetainPtr<CSGPDF_SDK_Object> CloneNonCyclic(
		bool bDirect,
		std::set<const CSGPDF_SDK_Object*>* pVisited) const;

	// Return a reference to itself.
	// The object must be direct (!IsInlined).
	virtual RetainPtr<CSGPDF_SDK_Object> MakeReference(
		CSGPDF_SDK_IndirectObjectHolder* holder) const;

	protected:
	CSGPDF_SDK_Object() = default;
	CSGPDF_SDK_Object(const CSGPDF_SDK_Object& src) = delete;
	~CSGPDF_SDK_Object() override;

	RetainPtr<CSGPDF_SDK_Object> CloneObjectNonCyclic(bool bDirect) const;

	uint32_t m_ObjNum = 0;
	uint32_t m_GenNum = 0;
};

template <typename T>
struct CanInternStrings
{
	static constexpr bool value = std::is_same<T, CSGPDF_SDK_Array>::value ||
		std::is_same<T, CSGPDF_SDK_Dictionary>::value ||
		std::is_same<T, CSGPDF_SDK_Name>::value ||
		std::is_same<T, CSGPDF_SDK_String>::value;
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_H_
