// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_encryptor.h"

#include "core/fpdfapi/parser/sgpdf_crypto_handler.h"
#include "third_party/base/check.h"

CSGPDF_SDK_Encryptor::CSGPDF_SDK_Encryptor(CSGPDF_SDK_CryptoHandler* pHandler, int objnum)
	: m_pHandler(pHandler), m_ObjNum(objnum)
{
	DCHECK(m_pHandler);
}

std::vector<uint8_t, FxAllocAllocator<uint8_t>> CSGPDF_SDK_Encryptor::Encrypt(
	pdfium::span<const uint8_t> src_data) const
{
	if (src_data.empty())
		return std::vector<uint8_t, FxAllocAllocator<uint8_t>>();

	std::vector<uint8_t, FxAllocAllocator<uint8_t>> result;
	uint32_t buf_size = m_pHandler->EncryptGetSize(src_data);
	result.resize(buf_size);
	m_pHandler->EncryptContent(m_ObjNum, 0, src_data, result.data(),
		buf_size);  // Updates |buf_size| with actual.
	result.resize(buf_size);
	return result;
}

CSGPDF_SDK_Encryptor::~CSGPDF_SDK_Encryptor() = default;
