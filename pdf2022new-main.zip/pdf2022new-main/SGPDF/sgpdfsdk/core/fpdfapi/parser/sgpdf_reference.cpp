// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_reference.h"

#include "core/fpdfapi/parser/sgpdf_indirect_object_holder.h"
#include "core/fxcrt/fx_stream.h"
#include "third_party/base/check.h"
#include "third_party/base/stl_util.h"

CSGPDF_SDK_Reference::CSGPDF_SDK_Reference(CSGPDF_SDK_IndirectObjectHolder* pDoc, uint32_t objnum)
	: m_pObjList(pDoc), m_RefObjNum(objnum)
{
}

CSGPDF_SDK_Reference::~CSGPDF_SDK_Reference() = default;

CSGPDF_SDK_Object::Type CSGPDF_SDK_Reference::GetType() const
{
	return kReference;
}

ByteString CSGPDF_SDK_Reference::GetString() const
{
	const CSGPDF_SDK_Object* obj = SafeGetDirect();
	return obj ? obj->GetString() : ByteString();
}

float CSGPDF_SDK_Reference::GetNumber() const
{
	const CSGPDF_SDK_Object* obj = SafeGetDirect();
	return obj ? obj->GetNumber() : 0;
}

int CSGPDF_SDK_Reference::GetInteger() const
{
	const CSGPDF_SDK_Object* obj = SafeGetDirect();
	return obj ? obj->GetInteger() : 0;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Reference::GetDict()
{
	CSGPDF_SDK_Object* obj = SafeGetDirect();
	return obj ? obj->GetDict() : nullptr;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Reference::GetDict() const
{
	const CSGPDF_SDK_Object* obj = SafeGetDirect();
	return obj ? obj->GetDict() : nullptr;
}

bool CSGPDF_SDK_Reference::IsReference() const
{
	return true;
}

CSGPDF_SDK_Reference* CSGPDF_SDK_Reference::AsReference()
{
	return this;
}

const CSGPDF_SDK_Reference* CSGPDF_SDK_Reference::AsReference() const
{
	return this;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Reference::Clone() const
{
	return CloneObjectNonCyclic(false);
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Reference::CloneNonCyclic(
	bool bDirect,
	std::set<const CSGPDF_SDK_Object*>* pVisited) const
{
	pVisited->insert(this);
	if (bDirect)
	{
		auto* pDirect = GetDirect();
		return pDirect && !pdfium::Contains(*pVisited, pDirect)
			? pDirect->CloneNonCyclic(true, pVisited)
			: nullptr;
	}
	return pdfium::MakeRetain<CSGPDF_SDK_Reference>(m_pObjList.Get(), m_RefObjNum);
}

CSGPDF_SDK_Object* CSGPDF_SDK_Reference::SafeGetDirect()
{
	CSGPDF_SDK_Object* obj = GetDirect();
	return (obj && !obj->IsReference()) ? obj : nullptr;
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Reference::SafeGetDirect() const
{
	const CSGPDF_SDK_Object* obj = GetDirect();
	return (obj && !obj->IsReference()) ? obj : nullptr;
}

void CSGPDF_SDK_Reference::SetRef(CSGPDF_SDK_IndirectObjectHolder* pDoc, uint32_t objnum)
{
	m_pObjList = pDoc;
	m_RefObjNum = objnum;
}

CSGPDF_SDK_Object* CSGPDF_SDK_Reference::GetDirect()
{
	return m_pObjList ? m_pObjList->GetOrParseIndirectObject(m_RefObjNum)
		: nullptr;
}

const CSGPDF_SDK_Object* CSGPDF_SDK_Reference::GetDirect() const
{
	return m_pObjList ? m_pObjList->GetOrParseIndirectObject(m_RefObjNum)
		: nullptr;
}

bool CSGPDF_SDK_Reference::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	return archive->WriteString(" ") && archive->WriteDWord(GetRefObjNum()) &&
		archive->WriteString(" 0 R ");
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Reference::MakeReference(
	CSGPDF_SDK_IndirectObjectHolder* holder) const
{
	DCHECK(holder == m_pObjList);
	// Do not allow reference to reference, just create other reference for same
	// object.
	return pdfium::MakeRetain<CSGPDF_SDK_Reference>(holder, GetRefObjNum());
}
