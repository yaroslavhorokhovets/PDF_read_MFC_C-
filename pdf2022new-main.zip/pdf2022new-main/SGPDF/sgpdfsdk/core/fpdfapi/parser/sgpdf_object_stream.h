// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_STREAM_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_STREAM_H_

#include <map>
#include <memory>

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_IndirectObjectHolder;
class CSGPDF_SDK_Stream;
class IFX_SeekableReadStream;

// Implementation of logic of PDF "Object Streams".
// See "PDF 32000-1:2008" Spec. section 7.5.7.
class CSGPDF_SDK_ObjectStream {
 public:
  static bool IsObjectsStreamObject(const CSGPDF_SDK_Object* object);

  static std::unique_ptr<CSGPDF_SDK_ObjectStream> Create(const CSGPDF_SDK_Stream* stream);

  ~CSGPDF_SDK_ObjectStream();

  uint32_t obj_num() const { return obj_num_; }
  uint32_t extends_obj_num() const { return extends_obj_num_; }

  bool HasObject(uint32_t obj_number) const;
  RetainPtr<CSGPDF_SDK_Object> ParseObject(CSGPDF_SDK_IndirectObjectHolder* pObjList,
                                     uint32_t obj_number) const;
  const std::map<uint32_t, uint32_t>& objects_offsets() const {
    return objects_offsets_;
  }

 protected:
  explicit CSGPDF_SDK_ObjectStream(const CSGPDF_SDK_Stream* stream);

  void Init(const CSGPDF_SDK_Stream* stream);
  RetainPtr<CSGPDF_SDK_Object> ParseObjectAtOffset(
      CSGPDF_SDK_IndirectObjectHolder* pObjList,
      uint32_t object_offset) const;

  uint32_t obj_num_ = CSGPDF_SDK_Object::kInvalidObjNum;
  uint32_t extends_obj_num_ = CSGPDF_SDK_Object::kInvalidObjNum;

  RetainPtr<IFX_SeekableReadStream> data_stream_;
  int first_object_offset_ = 0;
  std::map<uint32_t, uint32_t> objects_offsets_;
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_STREAM_H_
