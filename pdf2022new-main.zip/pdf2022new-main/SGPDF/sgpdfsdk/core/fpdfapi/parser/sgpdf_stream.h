// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_STREAM_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_STREAM_H_

#include <memory>
#include <set>
#include <sstream>

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/fx_memory_wrappers.h"
#include "core/fxcrt/fx_stream.h"

class CSGPDF_SDK_Stream final : public CSGPDF_SDK_Object {
 public:
  static constexpr int kFileBufSize = 512;

  CONSTRUCT_VIA_MAKE_RETAIN;

  // CSGPDF_SDK_Object:
  Type GetType() const override;
  RetainPtr<CSGPDF_SDK_Object> Clone() const override;
  CSGPDF_SDK_Dictionary* GetDict() override;
  const CSGPDF_SDK_Dictionary* GetDict() const override;
  WideString GetUnicodeText() const override;
  bool IsStream() const override;
  CSGPDF_SDK_Stream* AsStream() override;
  const CSGPDF_SDK_Stream* AsStream() const override;
  bool WriteTo(IFX_ArchiveStream* archive,
               const CSGPDF_SDK_Encryptor* encryptor) const override;

  uint32_t GetRawSize() const { return m_dwSize; }
  // Will be null in case when stream is not memory based.
  // Use CSGPDF_SDK_StreamAcc to data access in all cases.
  uint8_t* GetInMemoryRawData() const { return m_pDataBuf.get(); }

  // Copies span into internally-owned buffer.
  void SetData(pdfium::span<const uint8_t> pData);

  void TakeData(std::unique_ptr<uint8_t, FxFreeDeleter> pData, uint32_t size);

  void SetDataFromStringstream(std::ostringstream* stream);

  // Set data and remove "Filter" and "DecodeParms" fields from stream
  // dictionary.
  void SetDataAndRemoveFilter(pdfium::span<const uint8_t> pData);
  void SetDataFromStringstreamAndRemoveFilter(std::ostringstream* stream);

  void InitStream(pdfium::span<const uint8_t> pData,
                  RetainPtr<CSGPDF_SDK_Dictionary> pDict);
  void InitStreamFromFile(const RetainPtr<IFX_SeekableReadStream>& pFile,
                          RetainPtr<CSGPDF_SDK_Dictionary> pDict);

  bool ReadRawData(FX_FILESIZE offset, uint8_t* pBuf, uint32_t buf_size) const;

  bool IsMemoryBased() const { return m_bMemoryBased; }
  bool HasFilter() const;

 private:
  CSGPDF_SDK_Stream();
  CSGPDF_SDK_Stream(std::unique_ptr<uint8_t, FxFreeDeleter> pData,
              uint32_t size,
              RetainPtr<CSGPDF_SDK_Dictionary> pDict);
  ~CSGPDF_SDK_Stream() override;

  RetainPtr<CSGPDF_SDK_Object> CloneNonCyclic(
      bool bDirect,
      std::set<const CSGPDF_SDK_Object*>* pVisited) const override;

  bool m_bMemoryBased = true;
  uint32_t m_dwSize = 0;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pDict;
  std::unique_ptr<uint8_t, FxFreeDeleter> m_pDataBuf;
  RetainPtr<IFX_SeekableReadStream> m_pFile;
};

inline CSGPDF_SDK_Stream* ToStream(CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsStream() : nullptr;
}

inline const CSGPDF_SDK_Stream* ToStream(const CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsStream() : nullptr;
}

inline RetainPtr<CSGPDF_SDK_Stream> ToStream(RetainPtr<CSGPDF_SDK_Object> obj) {
  return RetainPtr<CSGPDF_SDK_Stream>(ToStream(obj.Get()));
}

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_STREAM_H_
