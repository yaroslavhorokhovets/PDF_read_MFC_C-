// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/parser/sgpdf_object_avail.h"

#include <map>
#include <memory>
#include <utility>

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_indirect_object_holder.h"
#include "core/fpdfapi/parser/sgpdf_read_validator.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "core/fxcrt/fx_stream.h"
#include "testing/gtest/include/gtest/gtest.h"
#include "testing/invalid_seekable_read_stream.h"
#include "third_party/base/check.h"
#include "third_party/base/notreached.h"

namespace {

class TestReadValidator final : public CSGPDF_SDK_ReadValidator {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  void SimulateReadError() { ReadBlockAtOffset(nullptr, 0, 1); }

 private:
  TestReadValidator()
      : CSGPDF_SDK_ReadValidator(pdfium::MakeRetain<InvalidSeekableReadStream>(100),
                           nullptr) {}
  ~TestReadValidator() override {}
};

class TestHolder final : public CSGPDF_SDK_IndirectObjectHolder {
 public:
  enum class ObjectState {
    Unavailable,
    Available,
  };
  TestHolder() : validator_(pdfium::MakeRetain<TestReadValidator>()) {}
  ~TestHolder() override {}

  // CSGPDF_SDK_IndirectObjectHolder overrides:
  CSGPDF_SDK_Object* GetOrParseIndirectObject(uint32_t objnum) override {
    auto it = objects_data_.find(objnum);
    if (it == objects_data_.end())
      return nullptr;

    ObjectData& obj_data = it->second;
    if (obj_data.state == ObjectState::Unavailable) {
      validator_->SimulateReadError();
      return nullptr;
    }
    return obj_data.object.Get();
  }

  RetainPtr<CSGPDF_SDK_ReadValidator> GetValidator() { return validator_; }

  void AddObject(uint32_t objnum,
                 RetainPtr<CSGPDF_SDK_Object> object,
                 ObjectState state) {
    ObjectData object_data;
    object_data.object = std::move(object);
    object_data.state = state;
    DCHECK(objects_data_.find(objnum) == objects_data_.end());
    objects_data_[objnum] = std::move(object_data);
  }

  void SetObjectState(uint32_t objnum, ObjectState state) {
    auto it = objects_data_.find(objnum);
    DCHECK(it != objects_data_.end());
    ObjectData& obj_data = it->second;
    obj_data.state = state;
  }

  CSGPDF_SDK_Object* GetTestObject(uint32_t objnum) {
    auto it = objects_data_.find(objnum);
    if (it == objects_data_.end())
      return nullptr;
    return it->second.object.Get();
  }

 private:
  struct ObjectData {
    RetainPtr<CSGPDF_SDK_Object> object;
    ObjectState state = ObjectState::Unavailable;
  };
  std::map<uint32_t, ObjectData> objects_data_;
  RetainPtr<TestReadValidator> validator_;
};

class CSGPDF_SDK_ObjectAvailFailOnExclude final : public CSGPDF_SDK_ObjectAvail {
 public:
  using CSGPDF_SDK_ObjectAvail::CSGPDF_SDK_ObjectAvail;
  ~CSGPDF_SDK_ObjectAvailFailOnExclude() override {}
  bool ExcludeObject(const CSGPDF_SDK_Object* object) const override {
    NOTREACHED();
    return false;
  }
};

class CSGPDF_SDK_ObjectAvailExcludeArray final : public CSGPDF_SDK_ObjectAvail {
 public:
  using CSGPDF_SDK_ObjectAvail::CSGPDF_SDK_ObjectAvail;
  ~CSGPDF_SDK_ObjectAvailExcludeArray() override {}
  bool ExcludeObject(const CSGPDF_SDK_Object* object) const override {
    return object->IsArray();
  }
};

class CSGPDF_SDK_ObjectAvailExcludeTypeKey final : public CSGPDF_SDK_ObjectAvail {
 public:
  using CSGPDF_SDK_ObjectAvail::CSGPDF_SDK_ObjectAvail;
  ~CSGPDF_SDK_ObjectAvailExcludeTypeKey() override {}
  bool ExcludeObject(const CSGPDF_SDK_Object* object) const override {
    // The value of "Type" may be reference, and if it is not available, we can
    // incorrect filter objects.
    // In this case CSGPDF_SDK_ObjectAvail should wait availability of this item and
    // call ExcludeObject again.
    return object->IsDictionary() &&
           object->GetDict()->GetStringFor("Type") == "Exclude me";
  }
};

}  // namespace

TEST(CSGPDF_SDK_ObjectAvailTest, OneObject) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "string", false),
                   TestHolder::ObjectState::Unavailable);
  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());
  holder.SetObjectState(1, TestHolder::ObjectState::Available);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, OneReferencedObject) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Reference>(&holder, 2),
                   TestHolder::ObjectState::Unavailable);
  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "string", false),
                   TestHolder::ObjectState::Unavailable);
  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(1, TestHolder::ObjectState::Available);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(2, TestHolder::ObjectState::Available);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, CycledReferences) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Reference>(&holder, 2),
                   TestHolder::ObjectState::Unavailable);
  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_Reference>(&holder, 3),
                   TestHolder::ObjectState::Unavailable);
  holder.AddObject(3, pdfium::MakeRetain<CSGPDF_SDK_Reference>(&holder, 1),
                   TestHolder::ObjectState::Unavailable);

  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(1, TestHolder::ObjectState::Available);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(2, TestHolder::ObjectState::Available);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(3, TestHolder::ObjectState::Available);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, DoNotCheckParent) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Unavailable);
  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Unavailable);

  holder.GetTestObject(2)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>("Parent",
                                                                &holder, 1);

  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 2);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(2, TestHolder::ObjectState::Available);
  //  Object should be available in case when "Parent" object is unavailable.
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, Generic) {
  TestHolder holder;
  const uint32_t kDepth = 100;
  for (uint32_t i = 1; i < kDepth; ++i) {
    holder.AddObject(i, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                     TestHolder::ObjectState::Unavailable);
    // Add ref to next dictionary.
    holder.GetTestObject(i)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>(
        "Child", &holder, i + 1);
  }
  // Add final object
  holder.AddObject(kDepth, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Unavailable);

  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 1);
  for (uint32_t i = 1; i <= kDepth; ++i) {
    EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
              avail.CheckAvail());
    holder.SetObjectState(i, TestHolder::ObjectState::Available);
  }
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, NotExcludeRoot) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);
  CSGPDF_SDK_ObjectAvailFailOnExclude avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, NotExcludeReferedRoot) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Reference>(&holder, 2),
                   TestHolder::ObjectState::Available);
  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);
  CSGPDF_SDK_ObjectAvailFailOnExclude avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, Exclude) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);
  holder.GetTestObject(1)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>("ArrayRef",
                                                                &holder, 2);
  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_Array>(),
                   TestHolder::ObjectState::Available);
  holder.GetTestObject(2)->AsArray()->AppendNew<CSGPDF_SDK_Reference>(&holder, 2);

  // Add string, which is refered by array item. It is should not be checked.
  holder.AddObject(
      3,
      pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "Not available string", false),
      TestHolder::ObjectState::Unavailable);
  CSGPDF_SDK_ObjectAvailExcludeArray avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, ReadErrorOnExclude) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);
  holder.GetTestObject(1)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>("DictRef",
                                                                &holder, 2);
  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);

  holder.GetTestObject(2)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>("Type", &holder,
                                                                3);
  // The value of "Type" key is not available at start
  holder.AddObject(
      3, pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "Exclude me", false),
      TestHolder::ObjectState::Unavailable);

  holder.GetTestObject(2)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>("OtherData",
                                                                &holder, 4);
  // Add string, which is refered by dictionary item. It is should not be
  // checked, because the dictionary with it, should be skipped.
  holder.AddObject(
      4,
      pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "Not available string", false),
      TestHolder::ObjectState::Unavailable);

  CSGPDF_SDK_ObjectAvailExcludeTypeKey avail(holder.GetValidator(), &holder, 1);

  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  // Make "Type" value object available.
  holder.SetObjectState(3, TestHolder::ObjectState::Available);

  // Now object should be available, although the object '4' is not available,
  // because it is in skipped dictionary.
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, IgnoreNotExistsObject) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);
  holder.GetTestObject(1)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>(
      "NotExistsObjRef", &holder, 2);
  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 1);
  // Now object should be available, although the object '2' is not exists. But
  // all exists in file related data are checked.
  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, CheckTwice) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "string", false),
                   TestHolder::ObjectState::Unavailable);

  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, 1);
  EXPECT_EQ(avail.CheckAvail(), avail.CheckAvail());

  holder.SetObjectState(1, TestHolder::ObjectState::Available);
  EXPECT_EQ(avail.CheckAvail(), avail.CheckAvail());
}

TEST(CSGPDF_SDK_ObjectAvailTest, SelfReferedInlinedObject) {
  TestHolder holder;
  holder.AddObject(1, pdfium::MakeRetain<CSGPDF_SDK_Dictionary>(),
                   TestHolder::ObjectState::Available);

  holder.GetTestObject(1)->GetDict()->SetNewFor<CSGPDF_SDK_Reference>("Data", &holder,
                                                                2);
  auto* root =
      holder.GetTestObject(1)->GetDict()->SetNewFor<CSGPDF_SDK_Dictionary>("Dict");

  root->SetNewFor<CSGPDF_SDK_Reference>("Self", &holder, 1);

  holder.AddObject(2, pdfium::MakeRetain<CSGPDF_SDK_String>(nullptr, "Data", false),
                   TestHolder::ObjectState::Unavailable);

  CSGPDF_SDK_ObjectAvail avail(holder.GetValidator(), &holder, root);

  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataNotAvailable,
            avail.CheckAvail());

  holder.SetObjectState(2, TestHolder::ObjectState::Available);

  EXPECT_EQ(CSGPDF_SDK_DataAvail::DocAvailStatus::DataAvailable, avail.CheckAvail());
}
