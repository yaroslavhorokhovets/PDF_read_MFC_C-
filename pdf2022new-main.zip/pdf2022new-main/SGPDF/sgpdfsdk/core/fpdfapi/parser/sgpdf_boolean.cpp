// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_boolean.h"

#include "core/fxcrt/fx_stream.h"

CSGPDF_SDK_Boolean::CSGPDF_SDK_Boolean() = default;

CSGPDF_SDK_Boolean::CSGPDF_SDK_Boolean(bool value) : m_bValue(value)
{
}

CSGPDF_SDK_Boolean::~CSGPDF_SDK_Boolean() = default;

CSGPDF_SDK_Object::Type CSGPDF_SDK_Boolean::GetType() const
{
	return kBoolean;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Boolean::Clone() const
{
	return pdfium::MakeRetain<CSGPDF_SDK_Boolean>(m_bValue);
}

ByteString CSGPDF_SDK_Boolean::GetString() const
{
	return m_bValue ? "true" : "false";
}

int CSGPDF_SDK_Boolean::GetInteger() const
{
	return m_bValue;
}

void CSGPDF_SDK_Boolean::SetString(const ByteString& str)
{
	m_bValue = (str == "true");
}

bool CSGPDF_SDK_Boolean::IsBoolean() const
{
	return true;
}

CSGPDF_SDK_Boolean* CSGPDF_SDK_Boolean::AsBoolean()
{
	return this;
}

const CSGPDF_SDK_Boolean* CSGPDF_SDK_Boolean::AsBoolean() const
{
	return this;
}

bool CSGPDF_SDK_Boolean::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	return archive->WriteString(" ") &&
		archive->WriteString(GetString().AsStringView());
}
