// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_crypto_handler.h"

#include <time.h>

#include <algorithm>
#include <stack>
#include <utility>

#include "constants/form_fields.h"
#include "core/fdrm/fx_crypt.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_object_walker.h"
#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "core/fpdfapi/parser/sgpdf_security_handler.h"
#include "core/fpdfapi/parser/sgpdf_simple_parser.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/sgpdf_stream_acc.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "third_party/base/check.h"

namespace
{

	constexpr char kContentsKey[] = "Contents";
	constexpr char kTypeKey[] = "Type";

}  // namespace

// static
bool CSGPDF_SDK_CryptoHandler::IsSignatureDictionary(
	const CSGPDF_SDK_Dictionary* dictionary)
{
	if (!dictionary)
		return false;
	const CSGPDF_SDK_Object* type_obj = dictionary->GetDirectObjectFor(kTypeKey);
	if (!type_obj)
		type_obj = dictionary->GetDirectObjectFor(pdfium::form_fields::kFT);
	return type_obj && type_obj->GetString() == pdfium::form_fields::kSig;
}

void CSGPDF_SDK_CryptoHandler::CryptBlock(bool bEncrypt,
	uint32_t objnum,
	uint32_t gennum,
	pdfium::span<const uint8_t> source,
	uint8_t* dest_buf,
	uint32_t& dest_size)
{
	if (m_Cipher == FXCIPHER_NONE)
	{
		memcpy(dest_buf, source.data(), source.size());
		return;
	}
	uint8_t realkey[16];
	size_t realkeylen = sizeof(realkey);
	if (m_Cipher != FXCIPHER_AES || m_KeyLen != 32)
	{
		uint8_t key1[32];
		PopulateKey(objnum, gennum, key1);

		if (m_Cipher == FXCIPHER_AES)
			memcpy(key1 + m_KeyLen + 5, "sAlT", 4);
		size_t len = m_Cipher == FXCIPHER_AES ? m_KeyLen + 9 : m_KeyLen + 5;
		CRYPT_MD5Generate({ key1, len }, realkey);
		realkeylen = std::min(m_KeyLen + 5, sizeof(realkey));
	}
	if (m_Cipher == FXCIPHER_AES)
	{
		CRYPT_AESSetKey(m_pAESContext.get(),
			m_KeyLen == 32 ? m_EncryptKey : realkey, m_KeyLen,
			bEncrypt);
		if (bEncrypt)
		{
			uint8_t iv[16];
			for (int i = 0; i < 16; i++)
			{
				iv[i] = (uint8_t)rand();
			}
			CRYPT_AESSetIV(m_pAESContext.get(), iv);
			memcpy(dest_buf, iv, 16);
			int nblocks = source.size() / 16;
			CRYPT_AESEncrypt(m_pAESContext.get(), dest_buf + 16, source.data(),
				nblocks * 16);
			uint8_t padding[16];
			memcpy(padding, source.data() + nblocks * 16, source.size() % 16);
			memset(padding + source.size() % 16, 16 - source.size() % 16,
				16 - source.size() % 16);
			CRYPT_AESEncrypt(m_pAESContext.get(), dest_buf + nblocks * 16 + 16,
				padding, 16);
			dest_size = 32 + nblocks * 16;
		}
		else
		{
			CRYPT_AESSetIV(m_pAESContext.get(), source.data());
			CRYPT_AESDecrypt(m_pAESContext.get(), dest_buf, source.data() + 16,
				source.size() - 16);
			dest_size = source.size() - 16;
			dest_size -= dest_buf[dest_size - 1];
		}
	}
	else
	{
		DCHECK(dest_size == source.size());
		if (dest_buf != source.data())
			memcpy(dest_buf, source.data(), source.size());
		CRYPT_ArcFourCryptBlock({ dest_buf, dest_size }, { realkey, realkeylen });
	}
}

struct AESCryptContext
{
	bool m_bIV;
	uint32_t m_BlockOffset;
	CRYPT_aes_context m_Context;
	uint8_t m_Block[16];
};

void* CSGPDF_SDK_CryptoHandler::CryptStart(uint32_t objnum,
	uint32_t gennum,
	bool bEncrypt)
{
	if (m_Cipher == FXCIPHER_NONE)
	{
		return this;
	}
	if (m_Cipher == FXCIPHER_AES && m_KeyLen == 32)
	{
		AESCryptContext* pContext = FX_Alloc(AESCryptContext, 1);
		pContext->m_bIV = true;
		pContext->m_BlockOffset = 0;
		CRYPT_AESSetKey(&pContext->m_Context, m_EncryptKey, 32, bEncrypt);
		if (bEncrypt)
		{
			for (int i = 0; i < 16; i++)
			{
				pContext->m_Block[i] = (uint8_t)rand();
			}
			CRYPT_AESSetIV(&pContext->m_Context, pContext->m_Block);
		}
		return pContext;
	}
	uint8_t key1[48];
	PopulateKey(objnum, gennum, key1);

	if (m_Cipher == FXCIPHER_AES)
		memcpy(key1 + m_KeyLen + 5, "sAlT", 4);

	uint8_t realkey[16];
	size_t len = m_Cipher == FXCIPHER_AES ? m_KeyLen + 9 : m_KeyLen + 5;
	CRYPT_MD5Generate({ key1, len }, realkey);
	size_t realkeylen = std::min(m_KeyLen + 5, sizeof(realkey));

	if (m_Cipher == FXCIPHER_AES)
	{
		AESCryptContext* pContext = FX_Alloc(AESCryptContext, 1);
		pContext->m_bIV = true;
		pContext->m_BlockOffset = 0;
		CRYPT_AESSetKey(&pContext->m_Context, realkey, 16, bEncrypt);
		if (bEncrypt)
		{
			for (int i = 0; i < 16; i++)
			{
				pContext->m_Block[i] = (uint8_t)rand();
			}
			CRYPT_AESSetIV(&pContext->m_Context, pContext->m_Block);
		}
		return pContext;
	}
	CRYPT_rc4_context* pContext = FX_Alloc(CRYPT_rc4_context, 1);
	CRYPT_ArcFourSetup(pContext, { realkey, realkeylen });
	return pContext;
}

bool CSGPDF_SDK_CryptoHandler::CryptStream(void* context,
	pdfium::span<const uint8_t> source,
	CFX_BinaryBuf& dest_buf,
	bool bEncrypt)
{
	if (!context)
		return false;

	if (m_Cipher == FXCIPHER_NONE)
	{
		dest_buf.AppendBlock(source.data(), source.size());
		return true;
	}
	if (m_Cipher == FXCIPHER_RC4)
	{
		int old_size = dest_buf.GetSize();
		dest_buf.AppendBlock(source.data(), source.size());
		CRYPT_ArcFourCrypt(static_cast<CRYPT_rc4_context*>(context),
			dest_buf.GetSpan().subspan(old_size, source.size()));
		return true;
	}
	AESCryptContext* pContext = static_cast<AESCryptContext*>(context);
	if (pContext->m_bIV && bEncrypt)
	{
		dest_buf.AppendBlock(pContext->m_Block, 16);
		pContext->m_bIV = false;
	}
	uint32_t src_off = 0;
	uint32_t src_left = source.size();
	while (1)
	{
		uint32_t copy_size = 16 - pContext->m_BlockOffset;
		if (copy_size > src_left)
		{
			copy_size = src_left;
		}
		memcpy(pContext->m_Block + pContext->m_BlockOffset, source.data() + src_off,
			copy_size);
		src_off += copy_size;
		src_left -= copy_size;
		pContext->m_BlockOffset += copy_size;
		if (pContext->m_BlockOffset == 16)
		{
			if (!bEncrypt && pContext->m_bIV)
			{
				CRYPT_AESSetIV(&pContext->m_Context, pContext->m_Block);
				pContext->m_bIV = false;
				pContext->m_BlockOffset = 0;
			}
			else if (src_off < source.size())
			{
				uint8_t block_buf[16];
				if (bEncrypt)
				{
					CRYPT_AESEncrypt(&pContext->m_Context, block_buf, pContext->m_Block,
						16);
				}
				else
				{
					CRYPT_AESDecrypt(&pContext->m_Context, block_buf, pContext->m_Block,
						16);
				}
				dest_buf.AppendBlock(block_buf, 16);
				pContext->m_BlockOffset = 0;
			}
		}
		if (!src_left)
		{
			break;
		}
	}
	return true;
}
bool CSGPDF_SDK_CryptoHandler::CryptFinish(void* context,
	CFX_BinaryBuf& dest_buf,
	bool bEncrypt)
{
	if (!context)
	{
		return false;
	}
	if (m_Cipher == FXCIPHER_NONE)
	{
		return true;
	}
	if (m_Cipher == FXCIPHER_RC4)
	{
		FX_Free(context);
		return true;
	}
	auto* pContext = static_cast<AESCryptContext*>(context);
	if (bEncrypt)
	{
		uint8_t block_buf[16];
		if (pContext->m_BlockOffset == 16)
		{
			CRYPT_AESEncrypt(&pContext->m_Context, block_buf, pContext->m_Block, 16);
			dest_buf.AppendBlock(block_buf, 16);
			pContext->m_BlockOffset = 0;
		}
		memset(pContext->m_Block + pContext->m_BlockOffset,
			(uint8_t)(16 - pContext->m_BlockOffset),
			16 - pContext->m_BlockOffset);
		CRYPT_AESEncrypt(&pContext->m_Context, block_buf, pContext->m_Block, 16);
		dest_buf.AppendBlock(block_buf, 16);
	}
	else if (pContext->m_BlockOffset == 16)
	{
		uint8_t block_buf[16];
		CRYPT_AESDecrypt(&pContext->m_Context, block_buf, pContext->m_Block, 16);
		if (block_buf[15] <= 16)
		{
			dest_buf.AppendBlock(block_buf, 16 - block_buf[15]);
		}
	}
	FX_Free(pContext);
	return true;
}

ByteString CSGPDF_SDK_CryptoHandler::Decrypt(uint32_t objnum,
	uint32_t gennum,
	const ByteString& str)
{
	CFX_BinaryBuf dest_buf;
	void* context = DecryptStart(objnum, gennum);
	DecryptStream(context, str.raw_span(), dest_buf);
	DecryptFinish(context, dest_buf);
	return ByteString(dest_buf.GetBuffer(), dest_buf.GetSize());
}

void* CSGPDF_SDK_CryptoHandler::DecryptStart(uint32_t objnum, uint32_t gennum)
{
	return CryptStart(objnum, gennum, false);
}
uint32_t CSGPDF_SDK_CryptoHandler::DecryptGetSize(uint32_t src_size)
{
	return m_Cipher == FXCIPHER_AES ? src_size - 16 : src_size;
}

bool CSGPDF_SDK_CryptoHandler::IsCipherAES() const
{
	return m_Cipher == FXCIPHER_AES;
}

bool CSGPDF_SDK_CryptoHandler::DecryptObjectTree(RetainPtr<CSGPDF_SDK_Object> object)
{
	if (!object)
		return false;

	struct MayBeSignature
	{
		const CSGPDF_SDK_Dictionary* parent;
		CSGPDF_SDK_Object* contents;
	};

	std::stack<MayBeSignature> may_be_sign_dictionaries;
	const uint32_t obj_num = object->GetObjNum();
	const uint32_t gen_num = object->GetGenNum();

	CSGPDF_SDK_Object* object_to_decrypt = object.Get();
	while (object_to_decrypt)
	{
		CSGPDF_SDK_NonConstObjectWalker walker(object_to_decrypt);
		object_to_decrypt = nullptr;
		while (CSGPDF_SDK_Object* child = walker.GetNext())
		{
			const CSGPDF_SDK_Dictionary* parent_dict =
				walker.GetParent() ? walker.GetParent()->GetDict() : nullptr;
			if (walker.dictionary_key() == kContentsKey &&
				(parent_dict->KeyExist(kTypeKey) ||
					parent_dict->KeyExist(pdfium::form_fields::kFT)))
			{
				// This object may be contents of signature dictionary.
				// But now values of 'Type' and 'FT' of dictionary keys are encrypted,
				// and we can not check this.
				// Temporary skip it, to prevent signature corruption.
				// It will be decrypted on next interations, if this is not contents of
				// signature dictionary.
				may_be_sign_dictionaries.push(MayBeSignature({ parent_dict, child }));
				walker.SkipWalkIntoCurrentObject();
				continue;
			}
			// Strings decryption.
			if (child->IsString())
			{
				// TODO(art-snake): Move decryption into the CSGPDF_SDK_String class.
				CSGPDF_SDK_String* str = child->AsString();
				str->SetString(Decrypt(obj_num, gen_num, str->GetString()));
			}
			// Stream decryption.
			if (child->IsStream())
			{
				// TODO(art-snake): Move decryption into the CSGPDF_SDK_Stream class.
				CSGPDF_SDK_Stream* stream = child->AsStream();
				auto stream_access = pdfium::MakeRetain<CSGPDF_SDK_StreamAcc>(stream);
				stream_access->LoadAllDataRaw();

				if (IsCipherAES() && stream_access->GetSize() < 16)
				{
					stream->SetData({});
					continue;
				}

				CFX_BinaryBuf decrypted_buf;
				decrypted_buf.EstimateSize(DecryptGetSize(stream_access->GetSize()));

				void* context = DecryptStart(obj_num, gen_num);
				bool decrypt_result =
					DecryptStream(context, stream_access->GetSpan(), decrypted_buf);
				decrypt_result &= DecryptFinish(context, decrypted_buf);
				if (decrypt_result)
				{
					const uint32_t decrypted_size = decrypted_buf.GetSize();
					stream->TakeData(decrypted_buf.DetachBuffer(), decrypted_size);
				}
				else
				{
					// Decryption failed, set the stream to empty
					stream->SetData({});
				}
			}
		}
		// Signature dictionaries check.
		while (!may_be_sign_dictionaries.empty())
		{
			auto dict_and_contents = may_be_sign_dictionaries.top();
			may_be_sign_dictionaries.pop();
			if (!IsSignatureDictionary(dict_and_contents.parent))
			{
				// This is not signature dictionary. Do decrypt its contents.
				object_to_decrypt = dict_and_contents.contents;
				break;
			}
		}
	}
	return true;
}

bool CSGPDF_SDK_CryptoHandler::DecryptStream(void* context,
	pdfium::span<const uint8_t> source,
	CFX_BinaryBuf& dest_buf)
{
	return CryptStream(context, source, dest_buf, false);
}

bool CSGPDF_SDK_CryptoHandler::DecryptFinish(void* context, CFX_BinaryBuf& dest_buf)
{
	return CryptFinish(context, dest_buf, false);
}

size_t CSGPDF_SDK_CryptoHandler::EncryptGetSize(
	pdfium::span<const uint8_t> source) const
{
	return m_Cipher == FXCIPHER_AES ? source.size() + 32 : source.size();
}

bool CSGPDF_SDK_CryptoHandler::EncryptContent(uint32_t objnum,
	uint32_t gennum,
	pdfium::span<const uint8_t> source,
	uint8_t* dest_buf,
	uint32_t& dest_size)
{
	CryptBlock(true, objnum, gennum, source, dest_buf, dest_size);
	return true;
}

CSGPDF_SDK_CryptoHandler::CSGPDF_SDK_CryptoHandler(int cipher,
	const uint8_t* key,
	size_t keylen)
	: m_KeyLen(std::min<size_t>(keylen, 32)), m_Cipher(cipher)
{
	DCHECK(cipher != FXCIPHER_AES || keylen == 16 || keylen == 24 ||
		keylen == 32);
	DCHECK(cipher != FXCIPHER_AES2 || keylen == 32);
	DCHECK(cipher != FXCIPHER_RC4 || (keylen >= 5 && keylen <= 16));

	if (m_Cipher != FXCIPHER_NONE)
		memcpy(m_EncryptKey, key, m_KeyLen);

	if (m_Cipher == FXCIPHER_AES)
		m_pAESContext.reset(FX_Alloc(CRYPT_aes_context, 1));
}

CSGPDF_SDK_CryptoHandler::~CSGPDF_SDK_CryptoHandler() = default;

void CSGPDF_SDK_CryptoHandler::PopulateKey(uint32_t objnum,
	uint32_t gennum,
	uint8_t* key)
{
	memcpy(key, m_EncryptKey, m_KeyLen);
	key[m_KeyLen + 0] = (uint8_t)objnum;
	key[m_KeyLen + 1] = (uint8_t)(objnum >> 8);
	key[m_KeyLen + 2] = (uint8_t)(objnum >> 16);
	key[m_KeyLen + 3] = (uint8_t)gennum;
	key[m_KeyLen + 4] = (uint8_t)(gennum >> 8);
}
