// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_null.h"

#include "core/fxcrt/fx_stream.h"

CSGPDF_SDK_Null::CSGPDF_SDK_Null() = default;

CSGPDF_SDK_Object::Type CSGPDF_SDK_Null::GetType() const
{
	return kNullobj;
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Null::Clone() const
{
	return pdfium::MakeRetain<CSGPDF_SDK_Null>();
}

bool CSGPDF_SDK_Null::WriteTo(IFX_ArchiveStream* archive,
	const CSGPDF_SDK_Encryptor* encryptor) const
{
	return archive->WriteString(" null");
}

bool CSGPDF_SDK_Null::IsNull() const
{
	return true;
}
