// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_document.h"

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_linearized_header.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "core/fpdfapi/parser/sgpdf_read_validator.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fxcodec/jbig2/JBig2_DocumentContext.h"
#include "core/fxcrt/fx_codepage.h"
#include "third_party/base/check.h"
#include "third_party/base/stl_util.h"

namespace
{

	const int kMaxPageLevel = 1024;

	int CountPages(CSGPDF_SDK_Dictionary* pPages,
		std::set<CSGPDF_SDK_Dictionary*>* visited_pages)
	{
		int count = pPages->GetIntegerFor("Count");
		if (count > 0 && count < CSGPDF_SDK_Document::kPageMaxNum)
			return count;
		CSGPDF_SDK_Array* pKidList = pPages->GetArrayFor("Kids");
		if (!pKidList)
			return 0;
		count = 0;
		for (size_t i = 0; i < pKidList->size(); i++)
		{
			CSGPDF_SDK_Dictionary* pKid = pKidList->GetDictAt(i);
			if (!pKid || pdfium::Contains(*visited_pages, pKid))
				continue;
			if (pKid->KeyExist("Kids"))
			{
				// Use |visited_pages| to help detect circular references of pages.
				pdfium::ScopedSetInsertion<CSGPDF_SDK_Dictionary*> local_add(visited_pages,
					pKid);
				count += CountPages(pKid, visited_pages);
			}
			else
			{
				// This page is a leaf node.
				count++;
			}
		}
		pPages->SetNewFor<CSGPDF_SDK_Number>("Count", count);
		return count;
	}

	int FindPageIndex(const CSGPDF_SDK_Dictionary* pNode,
		uint32_t* skip_count,
		uint32_t objnum,
		int* index,
		int level)
	{
		if (!pNode->KeyExist("Kids"))
		{
			if (objnum == pNode->GetObjNum())
				return *index;

			if (*skip_count != 0)
				(*skip_count)--;

			(*index)++;
			return -1;
		}

		const CSGPDF_SDK_Array* pKidList = pNode->GetArrayFor("Kids");
		if (!pKidList)
			return -1;

		if (level >= kMaxPageLevel)
			return -1;

		size_t count = pNode->GetIntegerFor("Count");
		if (count <= *skip_count)
		{
			(*skip_count) -= count;
			(*index) += count;
			return -1;
		}

		if (count && count == pKidList->size())
		{
			for (size_t i = 0; i < count; i++)
			{
				const CSGPDF_SDK_Reference* pKid = ToReference(pKidList->GetObjectAt(i));
				if (pKid && pKid->GetRefObjNum() == objnum)
					return static_cast<int>(*index + i);
			}
		}

		for (size_t i = 0; i < pKidList->size(); i++)
		{
			const CSGPDF_SDK_Dictionary* pKid = pKidList->GetDictAt(i);
			if (!pKid || pKid == pNode)
				continue;

			int found_index = FindPageIndex(pKid, skip_count, objnum, index, level + 1);
			if (found_index >= 0)
				return found_index;
		}
		return -1;
	}

}  // namespace

CSGPDF_SDK_Document::CSGPDF_SDK_Document(std::unique_ptr<RenderDataIface> pRenderData,
	std::unique_ptr<PageDataIface> pPageData)
	: m_pDocRender(std::move(pRenderData)),
	m_pDocPage(std::move(pPageData)),
	m_StockFontClearer(m_pDocPage.get())
{
	m_pDocRender->SetDocument(this);
	m_pDocPage->SetDocument(this);
}

CSGPDF_SDK_Document::~CSGPDF_SDK_Document()
{
	// Be absolutely certain that |m_pExtension| is null before destroying
	// the extension, to avoid re-entering it while being destroyed. clang
	// seems to already do this for us, but the C++ standards seem to
	// indicate the opposite.
	m_pExtension.reset();
}

// static
bool CSGPDF_SDK_Document::IsValidPageObject(const CSGPDF_SDK_Object* obj)
{
	const CSGPDF_SDK_Dictionary* dict = ToDictionary(obj);
	return dict && dict->GetNameFor("Type") == "Page";
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_Document::ParseIndirectObject(uint32_t objnum)
{
	return m_pParser ? m_pParser->ParseIndirectObject(objnum) : nullptr;
}

bool CSGPDF_SDK_Document::TryInit()
{
	SetLastObjNum(m_pParser->GetLastObjNum());

	CSGPDF_SDK_Object* pRootObj = GetOrParseIndirectObject(m_pParser->GetRootObjNum());
	if (pRootObj)
		m_pRootDict.Reset(pRootObj->GetDict());

	LoadPages();
	return GetRoot() && GetPageCount() > 0;
}

CSGPDF_SDK_Parser::Error CSGPDF_SDK_Document::LoadDoc(
	const RetainPtr<IFX_SeekableReadStream>& pFileAccess,
	const char* password)
{
	if (!m_pParser)
		SetParser(std::make_unique<CSGPDF_SDK_Parser>(this));

	return HandleLoadResult(m_pParser->StartParse(pFileAccess, password));
}

CSGPDF_SDK_Parser::Error CSGPDF_SDK_Document::LoadLinearizedDoc(
	const RetainPtr<CSGPDF_SDK_ReadValidator>& validator,
	const char* password)
{
	if (!m_pParser)
		SetParser(std::make_unique<CSGPDF_SDK_Parser>(this));

	return HandleLoadResult(m_pParser->StartLinearizedParse(validator, password));
}

void CSGPDF_SDK_Document::LoadPages()
{
	const CSGPDF_SDK_LinearizedHeader* linearized_header =
		m_pParser->GetLinearizedHeader();
	if (!linearized_header)
	{
		m_PageList.resize(RetrievePageCount());
		return;
	}

	uint32_t objnum = linearized_header->GetFirstPageObjNum();
	if (!IsValidPageObject(GetOrParseIndirectObject(objnum)))
	{
		m_PageList.resize(RetrievePageCount());
		return;
	}

	uint32_t first_page_num = linearized_header->GetFirstPageNo();
	uint32_t page_count = linearized_header->GetPageCount();
	DCHECK(first_page_num < page_count);
	m_PageList.resize(page_count);
	m_PageList[first_page_num] = objnum;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Document::TraversePDFPages(int iPage,
	int* nPagesToGo,
	size_t level)
{
	if (*nPagesToGo < 0 || m_bReachedMaxPageLevel)
		return nullptr;

	CSGPDF_SDK_Dictionary* pPages = m_pTreeTraversal[level].first;
	CSGPDF_SDK_Array* pKidList = pPages->GetArrayFor("Kids");
	if (!pKidList)
	{
		m_pTreeTraversal.pop_back();
		if (*nPagesToGo != 1)
			return nullptr;
		m_PageList[iPage] = pPages->GetObjNum();
		return pPages;
	}
	if (level >= kMaxPageLevel)
	{
		m_pTreeTraversal.pop_back();
		m_bReachedMaxPageLevel = true;
		return nullptr;
	}
	CSGPDF_SDK_Dictionary* page = nullptr;
	for (size_t i = m_pTreeTraversal[level].second; i < pKidList->size(); i++)
	{
		if (*nPagesToGo == 0)
			break;
		pKidList->ConvertToIndirectObjectAt(i, this);
		CSGPDF_SDK_Dictionary* pKid = pKidList->GetDictAt(i);
		if (!pKid)
		{
			(*nPagesToGo)--;
			m_pTreeTraversal[level].second++;
			continue;
		}
		if (pKid == pPages)
		{
			m_pTreeTraversal[level].second++;
			continue;
		}
		if (!pKid->KeyExist("Kids"))
		{
			m_PageList[iPage - (*nPagesToGo) + 1] = pKid->GetObjNum();
			(*nPagesToGo)--;
			m_pTreeTraversal[level].second++;
			if (*nPagesToGo == 0)
			{
				page = pKid;
				break;
			}
		}
		else
		{
			// If the vector has size level+1, the child is not in yet
			if (m_pTreeTraversal.size() == level + 1)
				m_pTreeTraversal.push_back(std::make_pair(pKid, 0));
			// Now m_pTreeTraversal[level+1] should exist and be equal to pKid.
			CSGPDF_SDK_Dictionary* pageKid = TraversePDFPages(iPage, nPagesToGo, level + 1);
			// Check if child was completely processed, i.e. it popped itself out
			if (m_pTreeTraversal.size() == level + 1)
				m_pTreeTraversal[level].second++;
			// If child did not finish, no pages to go, or max level reached, end
			if (m_pTreeTraversal.size() != level + 1 || *nPagesToGo == 0 ||
				m_bReachedMaxPageLevel)
			{
				page = pageKid;
				break;
			}
		}
	}
	if (m_pTreeTraversal[level].second == pKidList->size())
		m_pTreeTraversal.pop_back();
	return page;
}

void CSGPDF_SDK_Document::ResetTraversal()
{
	m_iNextPageToTraverse = 0;
	m_bReachedMaxPageLevel = false;
	m_pTreeTraversal.clear();
}

void CSGPDF_SDK_Document::SetParser(std::unique_ptr<CSGPDF_SDK_Parser> pParser)
{
	DCHECK(!m_pParser);
	m_pParser = std::move(pParser);
}

CSGPDF_SDK_Parser::Error CSGPDF_SDK_Document::HandleLoadResult(CSGPDF_SDK_Parser::Error error)
{
	if (error == CSGPDF_SDK_Parser::SUCCESS)
		m_bHasValidCrossReferenceTable = !m_pParser->xref_table_rebuilt();
	return error;
}

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_Document::GetPagesDict() const
{
	const CSGPDF_SDK_Dictionary* pRoot = GetRoot();
	return pRoot ? pRoot->GetDictFor("Pages") : nullptr;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Document::GetPagesDict()
{
	return const_cast<CSGPDF_SDK_Dictionary*>(
		static_cast<const CSGPDF_SDK_Document*>(this)->GetPagesDict());
}

bool CSGPDF_SDK_Document::IsPageLoaded(int iPage) const
{
	return !!m_PageList[iPage];
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Document::GetPageDictionary(int iPage)
{
	if (!pdfium::IndexInBounds(m_PageList, iPage))
		return nullptr;

	const uint32_t objnum = m_PageList[iPage];
	if (objnum)
	{
		CSGPDF_SDK_Dictionary* result = ToDictionary(GetOrParseIndirectObject(objnum));
		if (result)
			return result;
	}

	CSGPDF_SDK_Dictionary* pPages = GetPagesDict();
	if (!pPages)
		return nullptr;

	if (m_pTreeTraversal.empty())
	{
		ResetTraversal();
		m_pTreeTraversal.push_back(std::make_pair(pPages, 0));
	}
	int nPagesToGo = iPage - m_iNextPageToTraverse + 1;
	CSGPDF_SDK_Dictionary* pPage = TraversePDFPages(iPage, &nPagesToGo, 0);
	m_iNextPageToTraverse = iPage + 1;
	return pPage;
}

void CSGPDF_SDK_Document::SetPageObjNum(int iPage, uint32_t objNum)
{
	m_PageList[iPage] = objNum;
}

JBig2_DocumentContext* CSGPDF_SDK_Document::GetOrCreateCodecContext()
{
	if (!m_pCodecContext)
		m_pCodecContext = std::make_unique<JBig2_DocumentContext>();
	return m_pCodecContext.get();
}

int CSGPDF_SDK_Document::GetPageIndex(uint32_t objnum)
{
	uint32_t skip_count = 0;
	bool bSkipped = false;
	for (uint32_t i = 0; i < m_PageList.size(); ++i)
	{
		if (m_PageList[i] == objnum)
			return i;

		if (!bSkipped && m_PageList[i] == 0)
		{
			skip_count = i;
			bSkipped = true;
		}
	}
	const CSGPDF_SDK_Dictionary* pPages = GetPagesDict();
	if (!pPages)
		return -1;

	int start_index = 0;
	int found_index = FindPageIndex(pPages, &skip_count, objnum, &start_index, 0);

	// Corrupt page tree may yield out-of-range results.
	if (!pdfium::IndexInBounds(m_PageList, found_index))
		return -1;

	// Only update |m_PageList| when |objnum| points to a /Page object.
	if (IsValidPageObject(GetOrParseIndirectObject(objnum)))
		m_PageList[found_index] = objnum;
	return found_index;
}

int CSGPDF_SDK_Document::GetPageCount() const
{
	return pdfium::CollectionSize<int>(m_PageList);
}

int CSGPDF_SDK_Document::RetrievePageCount()
{
	CSGPDF_SDK_Dictionary* pPages = GetPagesDict();
	if (!pPages)
		return 0;

	if (!pPages->KeyExist("Kids"))
		return 1;

	std::set<CSGPDF_SDK_Dictionary*> visited_pages;
	visited_pages.insert(pPages);
	return CountPages(pPages, &visited_pages);
}

uint32_t CSGPDF_SDK_Document::GetUserPermissions() const
{
	if (m_pParser)
		return m_pParser->GetPermissions();

	return m_pExtension ? m_pExtension->GetUserPermissions() : 0;
}

void CSGPDF_SDK_Document::CreateNewDoc()
{
	DCHECK(!m_pRootDict);
	DCHECK(!m_pInfoDict);
	m_pRootDict.Reset(NewIndirect<CSGPDF_SDK_Dictionary>());
	m_pRootDict->SetNewFor<CSGPDF_SDK_Name>("Type", "Catalog");

	CSGPDF_SDK_Dictionary* pPages = NewIndirect<CSGPDF_SDK_Dictionary>();
	pPages->SetNewFor<CSGPDF_SDK_Name>("Type", "Pages");
	pPages->SetNewFor<CSGPDF_SDK_Number>("Count", 0);
	pPages->SetNewFor<CSGPDF_SDK_Array>("Kids");
	m_pRootDict->SetNewFor<CSGPDF_SDK_Reference>("Pages", this, pPages->GetObjNum());
	m_pInfoDict.Reset(NewIndirect<CSGPDF_SDK_Dictionary>());
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Document::CreateNewPage(int iPage)
{
	CSGPDF_SDK_Dictionary* pDict = NewIndirect<CSGPDF_SDK_Dictionary>();
	pDict->SetNewFor<CSGPDF_SDK_Name>("Type", "Page");
	uint32_t dwObjNum = pDict->GetObjNum();
	if (!InsertNewPage(iPage, pDict))
	{
		DeleteIndirectObject(dwObjNum);
		return nullptr;
	}
	return pDict;
}

bool CSGPDF_SDK_Document::InsertDeletePDFPage(CSGPDF_SDK_Dictionary* pPages,
	int nPagesToGo,
	CSGPDF_SDK_Dictionary* pPageDict,
	bool bInsert,
	std::set<CSGPDF_SDK_Dictionary*>* pVisited)
{
	CSGPDF_SDK_Array* pKidList = pPages->GetArrayFor("Kids");
	if (!pKidList)
		return false;

	for (size_t i = 0; i < pKidList->size(); i++)
	{
		CSGPDF_SDK_Dictionary* pKid = pKidList->GetDictAt(i);
		if (pKid->GetNameFor("Type") == "Page")
		{
			if (nPagesToGo != 0)
			{
				nPagesToGo--;
				continue;
			}
			if (bInsert)
			{
				pKidList->InsertNewAt<CSGPDF_SDK_Reference>(i, this, pPageDict->GetObjNum());
				pPageDict->SetNewFor<CSGPDF_SDK_Reference>("Parent", this,
					pPages->GetObjNum());
			}
			else
			{
				pKidList->RemoveAt(i);
			}
			pPages->SetNewFor<CSGPDF_SDK_Number>(
				"Count", pPages->GetIntegerFor("Count") + (bInsert ? 1 : -1));
			ResetTraversal();
			break;
		}
		int nPages = pKid->GetIntegerFor("Count");
		if (nPagesToGo >= nPages)
		{
			nPagesToGo -= nPages;
			continue;
		}
		if (pdfium::Contains(*pVisited, pKid))
			return false;

		pdfium::ScopedSetInsertion<CSGPDF_SDK_Dictionary*> insertion(pVisited, pKid);
		if (!InsertDeletePDFPage(pKid, nPagesToGo, pPageDict, bInsert, pVisited))
			return false;

		pPages->SetNewFor<CSGPDF_SDK_Number>(
			"Count", pPages->GetIntegerFor("Count") + (bInsert ? 1 : -1));
		break;
	}
	return true;
}

bool CSGPDF_SDK_Document::InsertNewPage(int iPage, CSGPDF_SDK_Dictionary* pPageDict)
{
	CSGPDF_SDK_Dictionary* pRoot = GetRoot();
	CSGPDF_SDK_Dictionary* pPages = pRoot ? pRoot->GetDictFor("Pages") : nullptr;
	if (!pPages)
		return false;

	int nPages = GetPageCount();
	if (iPage < 0 || iPage > nPages)
		return false;

	if (iPage == nPages)
	{
		CSGPDF_SDK_Array* pPagesList = pPages->GetArrayFor("Kids");
		if (!pPagesList)
			pPagesList = pPages->SetNewFor<CSGPDF_SDK_Array>("Kids");
		pPagesList->AppendNew<CSGPDF_SDK_Reference>(this, pPageDict->GetObjNum());
		pPages->SetNewFor<CSGPDF_SDK_Number>("Count", nPages + 1);
		pPageDict->SetNewFor<CSGPDF_SDK_Reference>("Parent", this, pPages->GetObjNum());
		ResetTraversal();
	}
	else
	{
		std::set<CSGPDF_SDK_Dictionary*> stack = { pPages };
		if (!InsertDeletePDFPage(pPages, iPage, pPageDict, true, &stack))
			return false;
	}
	m_PageList.insert(m_PageList.begin() + iPage, pPageDict->GetObjNum());
	return true;
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_Document::GetInfo()
{
	if (m_pInfoDict)
		return m_pInfoDict.Get();

	if (!m_pParser || !m_pParser->GetInfoObjNum())
		return nullptr;

	auto ref =
		pdfium::MakeRetain<CSGPDF_SDK_Reference>(this, m_pParser->GetInfoObjNum());
	m_pInfoDict.Reset(ToDictionary(ref->GetDirect()));
	return m_pInfoDict.Get();
}

const CSGPDF_SDK_Array* CSGPDF_SDK_Document::GetFileIdentifier() const
{
	return m_pParser ? m_pParser->GetIDArray() : nullptr;
}

void CSGPDF_SDK_Document::DeletePage(int iPage)
{
	CSGPDF_SDK_Dictionary* pPages = GetPagesDict();
	if (!pPages)
		return;

	int nPages = pPages->GetIntegerFor("Count");
	if (iPage < 0 || iPage >= nPages)
		return;

	std::set<CSGPDF_SDK_Dictionary*> stack = { pPages };
	if (!InsertDeletePDFPage(pPages, iPage, nullptr, false, &stack))
		return;

	m_PageList.erase(m_PageList.begin() + iPage);
}

void CSGPDF_SDK_Document::SetRootForTesting(CSGPDF_SDK_Dictionary* root)
{
	m_pRootDict.Reset(root);
}

void CSGPDF_SDK_Document::ResizePageListForTesting(size_t size)
{
	m_PageList.resize(size);
}

CSGPDF_SDK_Document::StockFontClearer::StockFontClearer(
	CSGPDF_SDK_Document::PageDataIface* pPageData)
	: m_pPageData(pPageData)
{
}

CSGPDF_SDK_Document::StockFontClearer::~StockFontClearer()
{
	m_pPageData->ClearStockFont();
}

CSGPDF_SDK_Document::PageDataIface::PageDataIface() = default;

CSGPDF_SDK_Document::PageDataIface::~PageDataIface() = default;

CSGPDF_SDK_Document::RenderDataIface::RenderDataIface() = default;

CSGPDF_SDK_Document::RenderDataIface::~RenderDataIface() = default;
