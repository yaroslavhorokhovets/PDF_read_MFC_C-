// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_ARRAY_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_ARRAY_H_

#include <memory>
#include <set>
#include <type_traits>
#include <utility>
#include <vector>

#include "core/fpdfapi/parser/sgpdf_indirect_object_holder.h"
#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/retain_ptr.h"
#include "third_party/base/check.h"

class CSGPDF_SDK_Array final : public CSGPDF_SDK_Object
{
	public:
	using const_iterator = std::vector<RetainPtr<CSGPDF_SDK_Object>>::const_iterator;

	CONSTRUCT_VIA_MAKE_RETAIN;

	// CSGPDF_SDK_Object:
	Type GetType() const override;
	RetainPtr<CSGPDF_SDK_Object> Clone() const override;
	bool IsArray() const override;
	CSGPDF_SDK_Array* AsArray() override;
	const CSGPDF_SDK_Array* AsArray() const override;
	bool WriteTo(IFX_ArchiveStream* archive,
		const CSGPDF_SDK_Encryptor* encryptor) const override;

	bool IsEmpty() const
	{
		return m_Objects.empty();
	}
	size_t size() const
	{
		return m_Objects.size();
	}
	CSGPDF_SDK_Object* GetObjectAt(size_t index);
	const CSGPDF_SDK_Object* GetObjectAt(size_t index) const;
	CSGPDF_SDK_Object* GetDirectObjectAt(size_t index);
	const CSGPDF_SDK_Object* GetDirectObjectAt(size_t index) const;
	ByteString GetStringAt(size_t index) const;
	WideString GetUnicodeTextAt(size_t index) const;
	bool GetBooleanAt(size_t index, bool bDefault) const;
	int GetIntegerAt(size_t index) const;
	float GetNumberAt(size_t index) const;
	CSGPDF_SDK_Dictionary* GetDictAt(size_t index);
	const CSGPDF_SDK_Dictionary* GetDictAt(size_t index) const;
	CSGPDF_SDK_Stream* GetStreamAt(size_t index);
	const CSGPDF_SDK_Stream* GetStreamAt(size_t index) const;
	CSGPDF_SDK_Array* GetArrayAt(size_t index);
	const CSGPDF_SDK_Array* GetArrayAt(size_t index) const;
	CFX_Matrix GetMatrix() const;
	CFX_FloatRect GetRect() const;

	// Creates object owned by the array, returns unowned pointer to it.
	// We have special cases for objects that can intern strings from
	// a ByteStringPool. Prefer using these templates over direct calls
	// to Append()/SetAt()/InsertAt() since by creating a new object with no
	// previous references, they ensure cycles can not be introduced.
	template <typename T, typename... Args>
	typename std::enable_if<!CanInternStrings<T>::value, T*>::type AppendNew(
		Args&&... args)
	{
		return static_cast<T*>(
			Append(pdfium::MakeRetain<T>(std::forward<Args>(args)...)));
	}
	template <typename T, typename... Args>
	typename std::enable_if<CanInternStrings<T>::value, T*>::type AppendNew(
		Args&&... args)
	{
		return static_cast<T*>(
			Append(pdfium::MakeRetain<T>(m_pPool, std::forward<Args>(args)...)));
	}
	template <typename T, typename... Args>
	typename std::enable_if<!CanInternStrings<T>::value, T*>::type SetNewAt(
		size_t index,
		Args&&... args)
	{
		return static_cast<T*>(
			SetAt(index, pdfium::MakeRetain<T>(std::forward<Args>(args)...)));
	}
	template <typename T, typename... Args>
	typename std::enable_if<CanInternStrings<T>::value, T*>::type SetNewAt(
		size_t index,
		Args&&... args)
	{
		return static_cast<T*>(SetAt(
			index, pdfium::MakeRetain<T>(m_pPool, std::forward<Args>(args)...)));
	}
	template <typename T, typename... Args>
	typename std::enable_if<!CanInternStrings<T>::value, T*>::type InsertNewAt(
		size_t index,
		Args&&... args)
	{
		return static_cast<T*>(
			InsertAt(index, pdfium::MakeRetain<T>(std::forward<Args>(args)...)));
	}
	template <typename T, typename... Args>
	typename std::enable_if<CanInternStrings<T>::value, T*>::type InsertNewAt(
		size_t index,
		Args&&... args)
	{
		return static_cast<T*>(InsertAt(
			index, pdfium::MakeRetain<T>(m_pPool, std::forward<Args>(args)...)));
	}

	// Takes ownership of |pObj|, returns unowned pointer to it.
	CSGPDF_SDK_Object* Append(RetainPtr<CSGPDF_SDK_Object> pObj);
	CSGPDF_SDK_Object* SetAt(size_t index, RetainPtr<CSGPDF_SDK_Object> pObj);
	CSGPDF_SDK_Object* InsertAt(size_t index, RetainPtr<CSGPDF_SDK_Object> pObj);

	void Clear();
	void RemoveAt(size_t index);
	void ConvertToIndirectObjectAt(size_t index,
		CSGPDF_SDK_IndirectObjectHolder* pHolder);
	bool IsLocked() const
	{
		return !!m_LockCount;
	}

	private:
	friend class CSGPDF_SDK_ArrayLocker;

	CSGPDF_SDK_Array();
	explicit CSGPDF_SDK_Array(const WeakPtr<ByteStringPool>& pPool);
	~CSGPDF_SDK_Array() override;

	RetainPtr<CSGPDF_SDK_Object> CloneNonCyclic(
		bool bDirect,
		std::set<const CSGPDF_SDK_Object*>* pVisited) const override;

	std::vector<RetainPtr<CSGPDF_SDK_Object>> m_Objects;
	WeakPtr<ByteStringPool> m_pPool;
	mutable uint32_t m_LockCount = 0;
};

class CSGPDF_SDK_ArrayLocker
{
	public:
	using const_iterator = CSGPDF_SDK_Array::const_iterator;

	explicit CSGPDF_SDK_ArrayLocker(const CSGPDF_SDK_Array* pArray);
	~CSGPDF_SDK_ArrayLocker();

	const_iterator begin() const
	{
		CHECK(m_pArray->IsLocked());
		return m_pArray->m_Objects.begin();
	}
	const_iterator end() const
	{
		CHECK(m_pArray->IsLocked());
		return m_pArray->m_Objects.end();
	}

	private:
	RetainPtr<const CSGPDF_SDK_Array> const m_pArray;
};

inline CSGPDF_SDK_Array* ToArray(CSGPDF_SDK_Object* obj)
{
	return obj ? obj->AsArray() : nullptr;
}

inline const CSGPDF_SDK_Array* ToArray(const CSGPDF_SDK_Object* obj)
{
	return obj ? obj->AsArray() : nullptr;
}

inline RetainPtr<CSGPDF_SDK_Array> ToArray(RetainPtr<CSGPDF_SDK_Object> obj)
{
	return RetainPtr<CSGPDF_SDK_Array>(ToArray(obj.Get()));
}

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_ARRAY_H_
