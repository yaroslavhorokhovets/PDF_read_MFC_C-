// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_WALKER_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_WALKER_H_

#include <memory>
#include <stack>

#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_Object;

// Walk on all non-null sub-objects in an object in depth, include itself,
// like in flat list.
class CSGPDF_SDK_ObjectWalker {
 public:
  class SubobjectIterator {
   public:
    virtual ~SubobjectIterator();
    virtual bool IsFinished() const = 0;
    bool IsStarted() const { return is_started_; }
    const CSGPDF_SDK_Object* Increment();
    const CSGPDF_SDK_Object* object() const { return object_.Get(); }

   protected:
    explicit SubobjectIterator(const CSGPDF_SDK_Object* object);

    virtual const CSGPDF_SDK_Object* IncrementImpl() = 0;
    virtual void Start() = 0;

   private:
    RetainPtr<const CSGPDF_SDK_Object> object_;
    bool is_started_ = false;
  };

  explicit CSGPDF_SDK_ObjectWalker(const CSGPDF_SDK_Object* root);
  ~CSGPDF_SDK_ObjectWalker();

  const CSGPDF_SDK_Object* GetNext();
  void SkipWalkIntoCurrentObject();

  size_t current_depth() const { return current_depth_; }
  const CSGPDF_SDK_Object* GetParent() const { return parent_object_.Get(); }
  const ByteString& dictionary_key() const { return dict_key_; }

 private:
  static std::unique_ptr<SubobjectIterator> MakeIterator(
      const CSGPDF_SDK_Object* object);

  RetainPtr<const CSGPDF_SDK_Object> next_object_;
  RetainPtr<const CSGPDF_SDK_Object> parent_object_;
  ByteString dict_key_;
  size_t current_depth_ = 0;
  std::stack<std::unique_ptr<SubobjectIterator>> stack_;
};

class CSGPDF_SDK_NonConstObjectWalker final : public CSGPDF_SDK_ObjectWalker {
 public:
  explicit CSGPDF_SDK_NonConstObjectWalker(CSGPDF_SDK_Object* root)
      : CSGPDF_SDK_ObjectWalker(root) {}

  CSGPDF_SDK_Object* GetNext() {
    return const_cast<CSGPDF_SDK_Object*>(CSGPDF_SDK_ObjectWalker::GetNext());
  }
};

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_OBJECT_WALKER_H_
