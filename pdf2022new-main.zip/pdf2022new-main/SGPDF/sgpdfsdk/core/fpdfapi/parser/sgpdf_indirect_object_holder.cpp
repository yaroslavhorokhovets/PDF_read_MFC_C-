// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/parser/sgpdf_indirect_object_holder.h"

#include <algorithm>
#include <utility>

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fpdfapi/parser/sgpdf_parser.h"
#include "third_party/base/check.h"

namespace
{

	CSGPDF_SDK_Object* FilterInvalidObjNum(CSGPDF_SDK_Object* obj)
	{
		return obj && obj->GetObjNum() != CSGPDF_SDK_Object::kInvalidObjNum ? obj : nullptr;
	}

}  // namespace

CSGPDF_SDK_IndirectObjectHolder::CSGPDF_SDK_IndirectObjectHolder()
	: m_LastObjNum(0), m_pByteStringPool(std::make_unique<ByteStringPool>())
{
}

CSGPDF_SDK_IndirectObjectHolder::~CSGPDF_SDK_IndirectObjectHolder()
{
	m_pByteStringPool.DeleteObject();  // Make weak.
}

CSGPDF_SDK_Object* CSGPDF_SDK_IndirectObjectHolder::GetIndirectObject(
	uint32_t objnum) const
{
	auto it = m_IndirectObjs.find(objnum);
	return (it != m_IndirectObjs.end()) ? FilterInvalidObjNum(it->second.Get())
		: nullptr;
}

CSGPDF_SDK_Object* CSGPDF_SDK_IndirectObjectHolder::GetOrParseIndirectObject(
	uint32_t objnum)
{
	if (objnum == 0 || objnum == CSGPDF_SDK_Object::kInvalidObjNum)
		return nullptr;

	// Add item anyway to prevent recursively parsing of same object.
	auto insert_result = m_IndirectObjs.insert(std::make_pair(objnum, nullptr));
	if (!insert_result.second)
		return FilterInvalidObjNum(insert_result.first->second.Get());

	RetainPtr<CSGPDF_SDK_Object> pNewObj = ParseIndirectObject(objnum);
	if (!pNewObj)
	{
		m_IndirectObjs.erase(insert_result.first);
		return nullptr;
	}

	pNewObj->SetObjNum(objnum);
	m_LastObjNum = std::max(m_LastObjNum, objnum);
	insert_result.first->second = std::move(pNewObj);
	return insert_result.first->second.Get();
}

RetainPtr<CSGPDF_SDK_Object> CSGPDF_SDK_IndirectObjectHolder::ParseIndirectObject(
	uint32_t objnum)
{
	return nullptr;
}

CSGPDF_SDK_Object* CSGPDF_SDK_IndirectObjectHolder::AddIndirectObject(
	RetainPtr<CSGPDF_SDK_Object> pObj)
{
	CHECK(!pObj->GetObjNum());
	pObj->SetObjNum(++m_LastObjNum);

	auto& obj_holder = m_IndirectObjs[m_LastObjNum];
	obj_holder = std::move(pObj);
	return obj_holder.Get();
}

bool CSGPDF_SDK_IndirectObjectHolder::ReplaceIndirectObjectIfHigherGeneration(
	uint32_t objnum,
	RetainPtr<CSGPDF_SDK_Object> pObj)
{
	DCHECK(objnum);
	if (!pObj || objnum == CSGPDF_SDK_Object::kInvalidObjNum)
		return false;

	auto& obj_holder = m_IndirectObjs[objnum];
	const CSGPDF_SDK_Object* old_object = FilterInvalidObjNum(obj_holder.Get());
	if (old_object && pObj->GetGenNum() <= old_object->GetGenNum())
		return false;

	pObj->SetObjNum(objnum);
	obj_holder = std::move(pObj);
	m_LastObjNum = std::max(m_LastObjNum, objnum);
	return true;
}

void CSGPDF_SDK_IndirectObjectHolder::DeleteIndirectObject(uint32_t objnum)
{
	auto it = m_IndirectObjs.find(objnum);
	if (it == m_IndirectObjs.end() || !FilterInvalidObjNum(it->second.Get()))
		return;

	m_IndirectObjs.erase(it);
}
