// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PARSER_CSGPDF_SDK_BOOLEAN_H_
#define CORE_FPDFAPI_PARSER_CSGPDF_SDK_BOOLEAN_H_

#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_Boolean final : public CSGPDF_SDK_Object {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  // CSGPDF_SDK_Object:
  Type GetType() const override;
  RetainPtr<CSGPDF_SDK_Object> Clone() const override;
  ByteString GetString() const override;
  int GetInteger() const override;
  void SetString(const ByteString& str) override;
  bool IsBoolean() const override;
  CSGPDF_SDK_Boolean* AsBoolean() override;
  const CSGPDF_SDK_Boolean* AsBoolean() const override;
  bool WriteTo(IFX_ArchiveStream* archive,
               const CSGPDF_SDK_Encryptor* encryptor) const override;

 private:
  CSGPDF_SDK_Boolean();
  explicit CSGPDF_SDK_Boolean(bool value);
  ~CSGPDF_SDK_Boolean() override;

  bool m_bValue = false;
};

inline CSGPDF_SDK_Boolean* ToBoolean(CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsBoolean() : nullptr;
}

inline const CSGPDF_SDK_Boolean* ToBoolean(const CSGPDF_SDK_Object* obj) {
  return obj ? obj->AsBoolean() : nullptr;
}

#endif  // CORE_FPDFAPI_PARSER_CSGPDF_SDK_BOOLEAN_H_
