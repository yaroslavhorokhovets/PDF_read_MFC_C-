// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_shadingobject.h"

#include "core/fpdfapi/page/sgpdf_shadingpattern.h"

CSGPDF_SDK_ShadingObject::CSGPDF_SDK_ShadingObject(int32_t content_stream,
	CSGPDF_SDK_ShadingPattern* pattern,
	const CFX_Matrix& matrix)
	: CSGPDF_SDK_PageObject(content_stream), m_pShading(pattern), m_Matrix(matrix)
{
}

CSGPDF_SDK_ShadingObject::~CSGPDF_SDK_ShadingObject() = default;

CSGPDF_SDK_PageObject::Type CSGPDF_SDK_ShadingObject::GetType() const
{
	return SHADING;
}

void CSGPDF_SDK_ShadingObject::Transform(const CFX_Matrix& matrix)
{
	if (m_ClipPath.HasRef())
		m_ClipPath.Transform(matrix);

	m_Matrix.Concat(matrix);
	if (m_ClipPath.HasRef())
	{
		CalcBoundingBox();
		return;
	}

	SetRect(matrix.TransformRect(GetRect()));
}

bool CSGPDF_SDK_ShadingObject::IsShading() const
{
	return true;
}

CSGPDF_SDK_ShadingObject* CSGPDF_SDK_ShadingObject::AsShading()
{
	return this;
}

const CSGPDF_SDK_ShadingObject* CSGPDF_SDK_ShadingObject::AsShading() const
{
	return this;
}

void CSGPDF_SDK_ShadingObject::CalcBoundingBox()
{
	if (!m_ClipPath.HasRef())
		return;
	SetRect(m_ClipPath.GetClipBox());
}
