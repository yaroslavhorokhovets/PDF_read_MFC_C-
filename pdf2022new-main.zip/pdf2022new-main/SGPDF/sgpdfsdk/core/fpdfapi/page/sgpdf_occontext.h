// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_OCCONTEXT_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_OCCONTEXT_H_

#include <map>

#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Array;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_PageObject;

class CSGPDF_SDK_OCContext final : public Retainable {
 public:
  enum UsageType { View = 0, Design, Print, Export };

  CONSTRUCT_VIA_MAKE_RETAIN;

  bool CheckOCGVisible(const CSGPDF_SDK_Dictionary* pOCGDict) const;
  bool CheckObjectVisible(const CSGPDF_SDK_PageObject* pObj) const;

 private:
  CSGPDF_SDK_OCContext(CSGPDF_SDK_Document* pDoc, UsageType eUsageType);
  ~CSGPDF_SDK_OCContext() override;

  bool LoadOCGStateFromConfig(const ByteString& csConfig,
                              const CSGPDF_SDK_Dictionary* pOCGDict) const;
  bool LoadOCGState(const CSGPDF_SDK_Dictionary* pOCGDict) const;
  bool GetOCGVisible(const CSGPDF_SDK_Dictionary* pOCGDict) const;
  bool GetOCGVE(const CSGPDF_SDK_Array* pExpression, int nLevel) const;
  bool LoadOCMDState(const CSGPDF_SDK_Dictionary* pOCMDDict) const;

  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  const UsageType m_eUsageType;
  mutable std::map<const CSGPDF_SDK_Dictionary*, bool> m_OGCStateCache;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_OCCONTEXT_H_
