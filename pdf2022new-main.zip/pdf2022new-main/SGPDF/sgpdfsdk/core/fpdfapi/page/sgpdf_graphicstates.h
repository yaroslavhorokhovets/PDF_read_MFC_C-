// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_GRAPHICSTATES_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_GRAPHICSTATES_H_

#include "core/fpdfapi/page/sgpdf_clippath.h"
#include "core/fpdfapi/page/sgpdf_colorstate.h"
#include "core/fpdfapi/page/sgpdf_generalstate.h"
#include "core/fpdfapi/page/sgpdf_textstate.h"
#include "core/fxge/cfx_graphstate.h"

class CSGPDF_SDK_GraphicStates {
 public:
  CSGPDF_SDK_GraphicStates();
  virtual ~CSGPDF_SDK_GraphicStates();

  void CopyStates(const CSGPDF_SDK_GraphicStates& src);
  void DefaultStates();

  CSGPDF_SDK_ClipPath m_ClipPath;
  CFX_GraphState m_GraphState;
  CSGPDF_SDK_ColorState m_ColorState;
  CSGPDF_SDK_TextState m_TextState;
  CSGPDF_SDK_GeneralState m_GeneralState;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_GRAPHICSTATES_H_
