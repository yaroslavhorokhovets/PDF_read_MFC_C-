// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_generalstate.h"

#include "core/fpdfapi/page/sgpdf_transferfunc.h"
#include "core/fpdfapi/parser/sgpdf_object.h"

namespace
{

	int RI_StringToId(const ByteString& ri)
	{
		uint32_t id = ri.GetID();
		if (id == FXBSTR_ID('A', 'b', 's', 'o'))
			return 1;

		if (id == FXBSTR_ID('S', 'a', 't', 'u'))
			return 2;

		if (id == FXBSTR_ID('P', 'e', 'r', 'c'))
			return 3;

		return 0;
	}

	BlendMode GetBlendTypeInternal(const ByteString& mode)
	{
		switch (mode.GetID())
		{
			case FXBSTR_ID('N', 'o', 'r', 'm'):
			case FXBSTR_ID('C', 'o', 'm', 'p'):
				return BlendMode::kNormal;
			case FXBSTR_ID('M', 'u', 'l', 't'):
				return BlendMode::kMultiply;
			case FXBSTR_ID('S', 'c', 'r', 'e'):
				return BlendMode::kScreen;
			case FXBSTR_ID('O', 'v', 'e', 'r'):
				return BlendMode::kOverlay;
			case FXBSTR_ID('D', 'a', 'r', 'k'):
				return BlendMode::kDarken;
			case FXBSTR_ID('L', 'i', 'g', 'h'):
				return BlendMode::kLighten;
			case FXBSTR_ID('C', 'o', 'l', 'o'):
				if (mode.GetLength() == 10)
					return BlendMode::kColorDodge;
				if (mode.GetLength() == 9)
					return BlendMode::kColorBurn;
				return BlendMode::kColor;
			case FXBSTR_ID('H', 'a', 'r', 'd'):
				return BlendMode::kHardLight;
			case FXBSTR_ID('S', 'o', 'f', 't'):
				return BlendMode::kSoftLight;
			case FXBSTR_ID('D', 'i', 'f', 'f'):
				return BlendMode::kDifference;
			case FXBSTR_ID('E', 'x', 'c', 'l'):
				return BlendMode::kExclusion;
			case FXBSTR_ID('H', 'u', 'e', 0):
				return BlendMode::kHue;
			case FXBSTR_ID('S', 'a', 't', 'u'):
				return BlendMode::kSaturation;
			case FXBSTR_ID('L', 'u', 'm', 'i'):
				return BlendMode::kLuminosity;
		}
		return BlendMode::kNormal;
	}

}  // namespace

CSGPDF_SDK_GeneralState::CSGPDF_SDK_GeneralState() = default;

CSGPDF_SDK_GeneralState::CSGPDF_SDK_GeneralState(const CSGPDF_SDK_GeneralState& that)
	: m_Ref(that.m_Ref)
{
}

CSGPDF_SDK_GeneralState::~CSGPDF_SDK_GeneralState() = default;

void CSGPDF_SDK_GeneralState::SetRenderIntent(const ByteString& ri)
{
	m_Ref.GetPrivateCopy()->m_RenderIntent = RI_StringToId(ri);
}

ByteString CSGPDF_SDK_GeneralState::GetBlendMode() const
{
	switch (GetBlendType())
	{
		case BlendMode::kNormal:
			return ByteString(pdfium::transparency::kNormal);
		case BlendMode::kMultiply:
			return ByteString(pdfium::transparency::kMultiply);
		case BlendMode::kScreen:
			return ByteString(pdfium::transparency::kScreen);
		case BlendMode::kOverlay:
			return ByteString(pdfium::transparency::kOverlay);
		case BlendMode::kDarken:
			return ByteString(pdfium::transparency::kDarken);
		case BlendMode::kLighten:
			return ByteString(pdfium::transparency::kLighten);
		case BlendMode::kColorDodge:
			return ByteString(pdfium::transparency::kColorDodge);
		case BlendMode::kColorBurn:
			return ByteString(pdfium::transparency::kColorBurn);
		case BlendMode::kHardLight:
			return ByteString(pdfium::transparency::kHardLight);
		case BlendMode::kSoftLight:
			return ByteString(pdfium::transparency::kSoftLight);
		case BlendMode::kDifference:
			return ByteString(pdfium::transparency::kDifference);
		case BlendMode::kExclusion:
			return ByteString(pdfium::transparency::kExclusion);
		case BlendMode::kHue:
			return ByteString(pdfium::transparency::kHue);
		case BlendMode::kSaturation:
			return ByteString(pdfium::transparency::kSaturation);
		case BlendMode::kColor:
			return ByteString(pdfium::transparency::kColor);
		case BlendMode::kLuminosity:
			return ByteString(pdfium::transparency::kLuminosity);
	}
	return ByteString(pdfium::transparency::kNormal);
}

BlendMode CSGPDF_SDK_GeneralState::GetBlendType() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? pData->m_BlendType : BlendMode::kNormal;
}

void CSGPDF_SDK_GeneralState::SetBlendType(BlendMode type)
{
	m_Ref.GetPrivateCopy()->m_BlendType = type;
}

float CSGPDF_SDK_GeneralState::GetFillAlpha() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? pData->m_FillAlpha : 1.0f;
}

void CSGPDF_SDK_GeneralState::SetFillAlpha(float alpha)
{
	m_Ref.GetPrivateCopy()->m_FillAlpha = alpha;
}

float CSGPDF_SDK_GeneralState::GetStrokeAlpha() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? pData->m_StrokeAlpha : 1.0f;
}

void CSGPDF_SDK_GeneralState::SetStrokeAlpha(float alpha)
{
	m_Ref.GetPrivateCopy()->m_StrokeAlpha = alpha;
}

CSGPDF_SDK_Object* CSGPDF_SDK_GeneralState::GetSoftMask() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? pData->m_pSoftMask.Get() : nullptr;
}

void CSGPDF_SDK_GeneralState::SetSoftMask(CSGPDF_SDK_Object* pObject)
{
	m_Ref.GetPrivateCopy()->m_pSoftMask.Reset(pObject);
}

const CSGPDF_SDK_Object* CSGPDF_SDK_GeneralState::GetTR() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? pData->m_pTR.Get() : nullptr;
}

void CSGPDF_SDK_GeneralState::SetTR(CSGPDF_SDK_Object* pObject)
{
	m_Ref.GetPrivateCopy()->m_pTR.Reset(pObject);
}

RetainPtr<CSGPDF_SDK_TransferFunc> CSGPDF_SDK_GeneralState::GetTransferFunc() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? pData->m_pTransferFunc : nullptr;
}

void CSGPDF_SDK_GeneralState::SetTransferFunc(
	const RetainPtr<CSGPDF_SDK_TransferFunc>& pFunc)
{
	m_Ref.GetPrivateCopy()->m_pTransferFunc = pFunc;
}

void CSGPDF_SDK_GeneralState::SetBlendMode(const ByteString& mode)
{
	StateData* pData = m_Ref.GetPrivateCopy();
	pData->m_BlendMode = mode;
	pData->m_BlendType = GetBlendTypeInternal(mode);
}

const CFX_Matrix* CSGPDF_SDK_GeneralState::GetSMaskMatrix() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData ? &pData->m_SMaskMatrix : nullptr;
}

void CSGPDF_SDK_GeneralState::SetSMaskMatrix(const CFX_Matrix& matrix)
{
	m_Ref.GetPrivateCopy()->m_SMaskMatrix = matrix;
}

bool CSGPDF_SDK_GeneralState::GetFillOP() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData && pData->m_FillOP;
}

void CSGPDF_SDK_GeneralState::SetFillOP(bool op)
{
	m_Ref.GetPrivateCopy()->m_FillOP = op;
}

void CSGPDF_SDK_GeneralState::SetStrokeOP(bool op)
{
	m_Ref.GetPrivateCopy()->m_StrokeOP = op;
}

bool CSGPDF_SDK_GeneralState::GetStrokeOP() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData && pData->m_StrokeOP;
}

int CSGPDF_SDK_GeneralState::GetOPMode() const
{
	return m_Ref.GetObject()->m_OPMode;
}

void CSGPDF_SDK_GeneralState::SetOPMode(int mode)
{
	m_Ref.GetPrivateCopy()->m_OPMode = mode;
}

void CSGPDF_SDK_GeneralState::SetBG(CSGPDF_SDK_Object* pObject)
{
	m_Ref.GetPrivateCopy()->m_pBG.Reset(pObject);
}

void CSGPDF_SDK_GeneralState::SetUCR(CSGPDF_SDK_Object* pObject)
{
	m_Ref.GetPrivateCopy()->m_pUCR.Reset(pObject);
}

void CSGPDF_SDK_GeneralState::SetHT(CSGPDF_SDK_Object* pObject)
{
	m_Ref.GetPrivateCopy()->m_pHT.Reset(pObject);
}

void CSGPDF_SDK_GeneralState::SetFlatness(float flatness)
{
	m_Ref.GetPrivateCopy()->m_Flatness = flatness;
}

void CSGPDF_SDK_GeneralState::SetSmoothness(float smoothness)
{
	m_Ref.GetPrivateCopy()->m_Smoothness = smoothness;
}

bool CSGPDF_SDK_GeneralState::GetStrokeAdjust() const
{
	const StateData* pData = m_Ref.GetObject();
	return pData && pData->m_StrokeAdjust;
}

void CSGPDF_SDK_GeneralState::SetStrokeAdjust(bool adjust)
{
	m_Ref.GetPrivateCopy()->m_StrokeAdjust = adjust;
}

void CSGPDF_SDK_GeneralState::SetAlphaSource(bool source)
{
	m_Ref.GetPrivateCopy()->m_AlphaSource = source;
}

void CSGPDF_SDK_GeneralState::SetTextKnockout(bool knockout)
{
	m_Ref.GetPrivateCopy()->m_TextKnockout = knockout;
}

void CSGPDF_SDK_GeneralState::SetMatrix(const CFX_Matrix& matrix)
{
	m_Ref.GetPrivateCopy()->m_Matrix = matrix;
}

CFX_Matrix* CSGPDF_SDK_GeneralState::GetMutableMatrix()
{
	return &m_Ref.GetPrivateCopy()->m_Matrix;
}

CSGPDF_SDK_GeneralState::StateData::StateData() = default;

CSGPDF_SDK_GeneralState::StateData::StateData(const StateData& that)
	: m_BlendMode(that.m_BlendMode),
	m_BlendType(that.m_BlendType),
	m_pSoftMask(that.m_pSoftMask),
	m_SMaskMatrix(that.m_SMaskMatrix),
	m_StrokeAlpha(that.m_StrokeAlpha),
	m_FillAlpha(that.m_FillAlpha),
	m_pTR(that.m_pTR),
	m_pTransferFunc(that.m_pTransferFunc),
	m_Matrix(that.m_Matrix),
	m_RenderIntent(that.m_RenderIntent),
	m_StrokeAdjust(that.m_StrokeAdjust),
	m_AlphaSource(that.m_AlphaSource),
	m_TextKnockout(that.m_TextKnockout),
	m_StrokeOP(that.m_StrokeOP),
	m_FillOP(that.m_FillOP),
	m_OPMode(that.m_OPMode),
	m_pBG(that.m_pBG),
	m_pUCR(that.m_pUCR),
	m_pHT(that.m_pHT),
	m_Flatness(that.m_Flatness),
	m_Smoothness(that.m_Smoothness)
{
}

CSGPDF_SDK_GeneralState::StateData::~StateData() = default;

RetainPtr<CSGPDF_SDK_GeneralState::StateData> CSGPDF_SDK_GeneralState::StateData::Clone()
const
{
	return pdfium::MakeRetain<CSGPDF_SDK_GeneralState::StateData>(*this);
}
