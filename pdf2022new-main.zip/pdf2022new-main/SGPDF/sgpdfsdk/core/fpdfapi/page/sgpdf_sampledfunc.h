// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_SAMPLEDFUNC_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_SAMPLEDFUNC_H_

#include <set>
#include <vector>

#include "core/fpdfapi/page/sgpdf_function.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_StreamAcc;

class CSGPDF_SDK_SampledFunc final : public CSGPDF_SDK_Function {
 public:
  struct SampleEncodeInfo {
    float encode_max;
    float encode_min;
    uint32_t sizes;
  };

  struct SampleDecodeInfo {
    float decode_max;
    float decode_min;
  };

  CSGPDF_SDK_SampledFunc();
  ~CSGPDF_SDK_SampledFunc() override;

  // CSGPDF_SDK_Function
  bool v_Init(const CSGPDF_SDK_Object* pObj,
              std::set<const CSGPDF_SDK_Object*>* pVisited) override;
  bool v_Call(const float* inputs, float* results) const override;

  const std::vector<SampleEncodeInfo>& GetEncodeInfo() const {
    return m_EncodeInfo;
  }
  uint32_t GetBitsPerSample() const { return m_nBitsPerSample; }

#if defined(_SKIA_SUPPORT_) || defined(_SKIA_SUPPORT_PATHS_)
  RetainPtr<CSGPDF_SDK_StreamAcc> GetSampleStream() const;
#endif

 private:
  std::vector<SampleEncodeInfo> m_EncodeInfo;
  std::vector<SampleDecodeInfo> m_DecodeInfo;
  uint32_t m_nBitsPerSample;
  uint32_t m_SampleMax;
  RetainPtr<CSGPDF_SDK_StreamAcc> m_pSampleStream;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_SAMPLEDFUNC_H_
