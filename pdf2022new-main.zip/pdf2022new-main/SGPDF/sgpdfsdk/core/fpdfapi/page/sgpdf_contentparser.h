// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_CONTENTPARSER_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_CONTENTPARSER_H_

#include <memory>
#include <set>
#include <vector>

#include "core/fpdfapi/page/sgpdf_streamcontentparser.h"
#include "core/fxcrt/fx_memory_wrappers.h"
#include "core/fxcrt/maybe_owned.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_AllStates;
class CSGPDF_SDK_Array;
class CSGPDF_SDK_Form;
class CSGPDF_SDK_Page;
class CSGPDF_SDK_PageObjectHolder;
class CSGPDF_SDK_Stream;
class CSGPDF_SDK_StreamAcc;
class CSGPDF_SDK_Type3Char;
class PauseIndicatorIface;

class CSGPDF_SDK_ContentParser {
 public:
  explicit CSGPDF_SDK_ContentParser(CSGPDF_SDK_Page* pPage);
  CSGPDF_SDK_ContentParser(CSGPDF_SDK_Form* pForm,
                     const CSGPDF_SDK_AllStates* pGraphicStates,
                     const CFX_Matrix* pParentMatrix,
                     CSGPDF_SDK_Type3Char* pType3Char,
                     std::set<const uint8_t*>* pParsedSet);
  ~CSGPDF_SDK_ContentParser();

  const CSGPDF_SDK_AllStates* GetCurStates() const {
    return m_pParser ? m_pParser->GetCurStates() : nullptr;
  }
  // Returns whether to continue or not.
  bool Continue(PauseIndicatorIface* pPause);

 private:
  enum class Stage : uint8_t {
    kGetContent = 1,
    kPrepareContent,
    kParse,
    kCheckClip,
    kComplete,
  };

  Stage GetContent();
  Stage PrepareContent();
  Stage Parse();
  Stage CheckClip();

  void HandlePageContentStream(CSGPDF_SDK_Stream* pStream);
  bool HandlePageContentArray(CSGPDF_SDK_Array* pArray);
  void HandlePageContentFailure();

  Stage m_CurrentStage;
  UnownedPtr<CSGPDF_SDK_PageObjectHolder> const m_pObjectHolder;
  UnownedPtr<CSGPDF_SDK_Type3Char> m_pType3Char;  // Only used when parsing forms.
  RetainPtr<CSGPDF_SDK_StreamAcc> m_pSingleStream;
  std::vector<RetainPtr<CSGPDF_SDK_StreamAcc>> m_StreamArray;
  std::vector<uint32_t> m_StreamSegmentOffsets;
  MaybeOwned<uint8_t, FxFreeDeleter> m_pData;
  uint32_t m_nStreams = 0;
  uint32_t m_Size = 0;
  uint32_t m_CurrentOffset = 0;

  // Only used when parsing pages.
  std::unique_ptr<std::set<const uint8_t*>> m_pParsedSet;

  // |m_pParser| has a reference to |m_pParsedSet|, so must be below and thus
  // destroyed first.
  std::unique_ptr<CSGPDF_SDK_StreamContentParser> m_pParser;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_CONTENTPARSER_H_
