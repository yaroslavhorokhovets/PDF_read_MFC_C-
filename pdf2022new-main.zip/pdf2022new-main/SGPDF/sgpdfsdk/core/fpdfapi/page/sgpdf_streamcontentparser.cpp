// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_streamcontentparser.h"

#include <algorithm>
#include <memory>
#include <utility>
#include <vector>

#include "core/fpdfapi/font/sgpdf_font.h"
#include "core/fpdfapi/font/sgpdf_type3font.h"
#include "core/fpdfapi/page/sgpdf_allstates.h"
#include "core/fpdfapi/page/sgpdf_docpagedata.h"
#include "core/fpdfapi/page/sgpdf_form.h"
#include "core/fpdfapi/page/sgpdf_formobject.h"
#include "core/fpdfapi/page/sgpdf_image.h"
#include "core/fpdfapi/page/sgpdf_imageobject.h"
#include "core/fpdfapi/page/sgpdf_meshstream.h"
#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fpdfapi/page/sgpdf_pathobject.h"
#include "core/fpdfapi/page/sgpdf_shadingobject.h"
#include "core/fpdfapi/page/sgpdf_shadingpattern.h"
#include "core/fpdfapi/page/sgpdf_streamparser.h"
#include "core/fpdfapi/page/sgpdf_textobject.h"
#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fpdfapi/parser/sgpdf_name.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fpdfapi/parser/sgpdf_reference.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/fpdf_parser_utility.h"
#include "core/fxcrt/autonuller.h"
#include "core/fxcrt/fx_safe_types.h"
#include "core/fxge/cfx_graphstatedata.h"
#include "third_party/base/check.h"
#include "third_party/base/notreached.h"
#include "third_party/base/span.h"
#include "third_party/base/stl_util.h"

namespace
{

	const int kMaxFormLevel = 40;

	const int kSingleCoordinatePair = 1;
	const int kTensorCoordinatePairs = 16;
	const int kCoonsCoordinatePairs = 12;
	const int kSingleColorPerPatch = 1;
	const int kQuadColorsPerPatch = 4;

	const char kPathOperatorSubpath = 'm';
	const char kPathOperatorLine = 'l';
	const char kPathOperatorCubicBezier1 = 'c';
	const char kPathOperatorCubicBezier2 = 'v';
	const char kPathOperatorCubicBezier3 = 'y';
	const char kPathOperatorClosePath = 'h';
	const char kPathOperatorRectangle[] = "re";

	CFX_FloatRect GetShadingBBox(CSGPDF_SDK_ShadingPattern* pShading,
		const CFX_Matrix& matrix)
	{
		ShadingType type = pShading->GetShadingType();
		const CSGPDF_SDK_Stream* pStream = ToStream(pShading->GetShadingObject());
		RetainPtr<CSGPDF_SDK_ColorSpace> pCS = pShading->GetCS();
		if (!pStream || !pCS)
			return CFX_FloatRect();

		CSGPDF_SDK_MeshStream stream(type, pShading->GetFuncs(), pStream, pCS);
		if (!stream.Load())
			return CFX_FloatRect();

		CFX_FloatRect rect;
		bool bStarted = false;
		bool bGouraud = type == kFreeFormGouraudTriangleMeshShading ||
			type == kLatticeFormGouraudTriangleMeshShading;

		int point_count = kSingleCoordinatePair;
		if (type == kTensorProductPatchMeshShading)
			point_count = kTensorCoordinatePairs;
		else if (type == kCoonsPatchMeshShading)
			point_count = kCoonsCoordinatePairs;

		int color_count = kSingleColorPerPatch;
		if (type == kCoonsPatchMeshShading || type == kTensorProductPatchMeshShading)
			color_count = kQuadColorsPerPatch;

		while (!stream.BitStream()->IsEOF())
		{
			uint32_t flag = 0;
			if (type != kLatticeFormGouraudTriangleMeshShading)
			{
				if (!stream.CanReadFlag())
					break;
				flag = stream.ReadFlag();
			}

			if (!bGouraud && flag)
			{
				point_count -= 4;
				color_count -= 2;
			}

			for (int i = 0; i < point_count; i++)
			{
				if (!stream.CanReadCoords())
					break;
				CFX_PointF origin = stream.ReadCoords();
				if (bStarted)
				{
					rect.UpdateRect(origin);
				}
				else
				{
					rect.InitRect(origin);
					bStarted = true;
				}
			}
			FX_SAFE_UINT32 nBits = stream.Components();
			nBits *= stream.ComponentBits();
			nBits *= color_count;
			if (!nBits.IsValid())
				break;

			stream.BitStream()->SkipBits(nBits.ValueOrDie());
			if (bGouraud)
				stream.BitStream()->ByteAlign();
		}
		return matrix.TransformRect(rect);
	}

	struct AbbrPair
	{
		const char* abbr;
		const char* full_name;
	};

	const AbbrPair kInlineKeyAbbr[] = {
		{"BPC", "BitsPerComponent"}, {"CS", "ColorSpace"}, {"D", "Decode"},
		{"DP", "DecodeParms"},       {"F", "Filter"},      {"H", "Height"},
		{"IM", "ImageMask"},         {"I", "Interpolate"}, {"W", "Width"},
	};

	const AbbrPair kInlineValueAbbr[] = {
		{"G", "DeviceGray"},       {"RGB", "DeviceRGB"},
		{"CMYK", "DeviceCMYK"},    {"I", "Indexed"},
		{"AHx", "ASCIIHexDecode"}, {"A85", "ASCII85Decode"},
		{"LZW", "LZWDecode"},      {"Fl", "FlateDecode"},
		{"RL", "RunLengthDecode"}, {"CCF", "CCITTFaxDecode"},
		{"DCT", "DCTDecode"},
	};

	struct AbbrReplacementOp
	{
		bool is_replace_key;
		ByteString key;
		ByteStringView replacement;
	};

	ByteStringView FindFullName(const AbbrPair* table,
		size_t count,
		ByteStringView abbr)
	{
		auto* it = std::find_if(table, table + count, [abbr](const AbbrPair& pair)
			{
				return pair.abbr == abbr;
			});
		return it != table + count ? ByteStringView(it->full_name) : ByteStringView();
	}

	void ReplaceAbbr(CSGPDF_SDK_Object* pObj);

	void ReplaceAbbrInDictionary(CSGPDF_SDK_Dictionary* pDict)
	{
		std::vector<AbbrReplacementOp> replacements;
		{
			CSGPDF_SDK_DictionaryLocker locker(pDict);
			for (const auto& it : locker)
			{
				ByteString key = it.first;
				CSGPDF_SDK_Object* value = it.second.Get();
				ByteStringView fullname = FindFullName(
					kInlineKeyAbbr, pdfium::size(kInlineKeyAbbr), key.AsStringView());
				if (!fullname.IsEmpty())
				{
					AbbrReplacementOp op;
					op.is_replace_key = true;
					op.key = std::move(key);
					op.replacement = fullname;
					replacements.push_back(op);
					key = fullname;
				}

				if (value->IsName())
				{
					ByteString name = value->GetString();
					fullname =
						FindFullName(kInlineValueAbbr, pdfium::size(kInlineValueAbbr),
							name.AsStringView());
					if (!fullname.IsEmpty())
					{
						AbbrReplacementOp op;
						op.is_replace_key = false;
						op.key = key;
						op.replacement = fullname;
						replacements.push_back(op);
					}
				}
				else
				{
					ReplaceAbbr(value);
				}
			}
		}
		for (const auto& op : replacements)
		{
			if (op.is_replace_key)
				pDict->ReplaceKey(op.key, ByteString(op.replacement));
			else
				pDict->SetNewFor<CSGPDF_SDK_Name>(op.key, ByteString(op.replacement));
		}
	}

	void ReplaceAbbrInArray(CSGPDF_SDK_Array* pArray)
	{
		for (size_t i = 0; i < pArray->size(); ++i)
		{
			CSGPDF_SDK_Object* pElement = pArray->GetObjectAt(i);
			if (pElement->IsName())
			{
				ByteString name = pElement->GetString();
				ByteStringView fullname =
					FindFullName(kInlineValueAbbr, pdfium::size(kInlineValueAbbr),
						name.AsStringView());
				if (!fullname.IsEmpty())
					pArray->SetNewAt<CSGPDF_SDK_Name>(i, ByteString(fullname));
			}
			else
			{
				ReplaceAbbr(pElement);
			}
		}
	}

	void ReplaceAbbr(CSGPDF_SDK_Object* pObj)
	{
		CSGPDF_SDK_Dictionary* pDict = pObj->AsDictionary();
		if (pDict)
		{
			ReplaceAbbrInDictionary(pDict);
			return;
		}

		CSGPDF_SDK_Array* pArray = pObj->AsArray();
		if (pArray)
			ReplaceAbbrInArray(pArray);
	}

}  // namespace

CSGPDF_SDK_StreamContentParser::CSGPDF_SDK_StreamContentParser(
	CSGPDF_SDK_Document* pDocument,
	CSGPDF_SDK_Dictionary* pPageResources,
	CSGPDF_SDK_Dictionary* pParentResources,
	const CFX_Matrix* pmtContentToUser,
	CSGPDF_SDK_PageObjectHolder* pObjHolder,
	CSGPDF_SDK_Dictionary* pResources,
	const CFX_FloatRect& rcBBox,
	const CSGPDF_SDK_AllStates* pStates,
	std::set<const uint8_t*>* pParsedSet)
	: m_pDocument(pDocument),
	m_pPageResources(pPageResources),
	m_pParentResources(pParentResources),
	m_pResources(CSGPDF_SDK_Form::ChooseResourcesDict(pResources,
		pParentResources,
		pPageResources)),
	m_pObjectHolder(pObjHolder),
	m_ParsedSet(pParsedSet),
	m_BBox(rcBBox),
	m_pCurStates(std::make_unique<CSGPDF_SDK_AllStates>())
{
	if (pmtContentToUser)
		m_mtContentToUser = *pmtContentToUser;
	if (pStates)
	{
		m_pCurStates->Copy(*pStates);
	}
	else
	{
		m_pCurStates->m_GeneralState.Emplace();
		m_pCurStates->m_GraphState.Emplace();
		m_pCurStates->m_TextState.Emplace();
		m_pCurStates->m_ColorState.Emplace();
	}

	// Add the sentinel.
	m_ContentMarksStack.push(std::make_unique<CSGPDF_SDK_ContentMarks>());
}

CSGPDF_SDK_StreamContentParser::~CSGPDF_SDK_StreamContentParser()
{
	ClearAllParams();
}

int CSGPDF_SDK_StreamContentParser::GetNextParamPos()
{
	if (m_ParamCount == kParamBufSize)
	{
		m_ParamStartPos++;
		if (m_ParamStartPos == kParamBufSize)
		{
			m_ParamStartPos = 0;
		}
		if (m_ParamBuf[m_ParamStartPos].m_Type == ContentParam::OBJECT)
			m_ParamBuf[m_ParamStartPos].m_pObject.Reset();

		return m_ParamStartPos;
	}
	int index = m_ParamStartPos + m_ParamCount;
	if (index >= kParamBufSize)
	{
		index -= kParamBufSize;
	}
	m_ParamCount++;
	return index;
}

void CSGPDF_SDK_StreamContentParser::AddNameParam(ByteStringView bsName)
{
	ContentParam& param = m_ParamBuf[GetNextParamPos()];
	param.m_Type = ContentParam::NAME;
	param.m_Name = PDF_NameDecode(bsName);
}

void CSGPDF_SDK_StreamContentParser::AddNumberParam(ByteStringView str)
{
	ContentParam& param = m_ParamBuf[GetNextParamPos()];
	param.m_Type = ContentParam::NUMBER;
	param.m_Number = FX_Number(str);
}

void CSGPDF_SDK_StreamContentParser::AddObjectParam(RetainPtr<CSGPDF_SDK_Object> pObj)
{
	ContentParam& param = m_ParamBuf[GetNextParamPos()];
	param.m_Type = ContentParam::OBJECT;
	param.m_pObject = std::move(pObj);
}

void CSGPDF_SDK_StreamContentParser::ClearAllParams()
{
	uint32_t index = m_ParamStartPos;
	for (uint32_t i = 0; i < m_ParamCount; i++)
	{
		if (m_ParamBuf[index].m_Type == ContentParam::OBJECT)
			m_ParamBuf[index].m_pObject.Reset();
		index++;
		if (index == kParamBufSize)
			index = 0;
	}
	m_ParamStartPos = 0;
	m_ParamCount = 0;
}

CSGPDF_SDK_Object* CSGPDF_SDK_StreamContentParser::GetObject(uint32_t index)
{
	if (index >= m_ParamCount)
	{
		return nullptr;
	}
	int real_index = m_ParamStartPos + m_ParamCount - index - 1;
	if (real_index >= kParamBufSize)
	{
		real_index -= kParamBufSize;
	}
	ContentParam& param = m_ParamBuf[real_index];
	if (param.m_Type == ContentParam::NUMBER)
	{
		param.m_Type = ContentParam::OBJECT;
		param.m_pObject =
			param.m_Number.IsInteger()
			? pdfium::MakeRetain<CSGPDF_SDK_Number>(param.m_Number.GetSigned())
			: pdfium::MakeRetain<CSGPDF_SDK_Number>(param.m_Number.GetFloat());
		return param.m_pObject.Get();
	}
	if (param.m_Type == ContentParam::NAME)
	{
		param.m_Type = ContentParam::OBJECT;
		param.m_pObject = m_pDocument->New<CSGPDF_SDK_Name>(param.m_Name);
		return param.m_pObject.Get();
	}
	if (param.m_Type == ContentParam::OBJECT)
		return param.m_pObject.Get();

	NOTREACHED();
	return nullptr;
}

ByteString CSGPDF_SDK_StreamContentParser::GetString(uint32_t index) const
{
	if (index >= m_ParamCount)
		return ByteString();

	int real_index = m_ParamStartPos + m_ParamCount - index - 1;
	if (real_index >= kParamBufSize)
		real_index -= kParamBufSize;

	const ContentParam& param = m_ParamBuf[real_index];
	if (param.m_Type == ContentParam::NAME)
		return param.m_Name;

	if (param.m_Type == 0 && param.m_pObject)
		return param.m_pObject->GetString();

	return ByteString();
}

float CSGPDF_SDK_StreamContentParser::GetNumber(uint32_t index) const
{
	if (index >= m_ParamCount)
		return 0;

	int real_index = m_ParamStartPos + m_ParamCount - index - 1;
	if (real_index >= kParamBufSize)
		real_index -= kParamBufSize;

	const ContentParam& param = m_ParamBuf[real_index];
	if (param.m_Type == ContentParam::NUMBER)
		return param.m_Number.GetFloat();

	if (param.m_Type == 0 && param.m_pObject)
		return param.m_pObject->GetNumber();

	return 0;
}

std::vector<float> CSGPDF_SDK_StreamContentParser::GetNumbers(size_t count) const
{
	std::vector<float> values(count);
	for (size_t i = 0; i < count; ++i)
		values[i] = GetNumber(count - i - 1);
	return values;
}

void CSGPDF_SDK_StreamContentParser::SetGraphicStates(CSGPDF_SDK_PageObject* pObj,
	bool bColor,
	bool bText,
	bool bGraph)
{
	pObj->m_GeneralState = m_pCurStates->m_GeneralState;
	pObj->m_ClipPath = m_pCurStates->m_ClipPath;
	pObj->m_ContentMarks = *m_ContentMarksStack.top();
	if (bColor)
	{
		pObj->m_ColorState = m_pCurStates->m_ColorState;
	}
	if (bGraph)
	{
		pObj->m_GraphState = m_pCurStates->m_GraphState;
	}
	if (bText)
	{
		pObj->m_TextState = m_pCurStates->m_TextState;
	}
}

// static
CSGPDF_SDK_StreamContentParser::OpCodes
CSGPDF_SDK_StreamContentParser::InitializeOpCodes()
{
	return OpCodes({
		{FXBSTR_ID('"', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_NextLineShowText_Space},
		{FXBSTR_ID('\'', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_NextLineShowText},
		{FXBSTR_ID('B', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_FillStrokePath},
		{FXBSTR_ID('B', '*', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_EOFillStrokePath},
		{FXBSTR_ID('B', 'D', 'C', 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_BeginMarkedContent_Dictionary},
		{FXBSTR_ID('B', 'I', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_BeginImage},
		{FXBSTR_ID('B', 'M', 'C', 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_BeginMarkedContent},
		{FXBSTR_ID('B', 'T', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_BeginText},
		{FXBSTR_ID('C', 'S', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetColorSpace_Stroke},
		{FXBSTR_ID('D', 'P', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_MarkPlace_Dictionary},
		{FXBSTR_ID('D', 'o', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_ExecuteXObject},
		{FXBSTR_ID('E', 'I', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_EndImage},
		{FXBSTR_ID('E', 'M', 'C', 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_EndMarkedContent},
		{FXBSTR_ID('E', 'T', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_EndText},
		{FXBSTR_ID('F', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_FillPathOld},
		{FXBSTR_ID('G', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetGray_Stroke},
		{FXBSTR_ID('I', 'D', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_BeginImageData},
		{FXBSTR_ID('J', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetLineCap},
		{FXBSTR_ID('K', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetCMYKColor_Stroke},
		{FXBSTR_ID('M', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetMiterLimit},
		{FXBSTR_ID('M', 'P', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_MarkPlace},
		{FXBSTR_ID('Q', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_RestoreGraphState},
		{FXBSTR_ID('R', 'G', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetRGBColor_Stroke},
		{FXBSTR_ID('S', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_StrokePath},
		{FXBSTR_ID('S', 'C', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetColor_Stroke},
		{FXBSTR_ID('S', 'C', 'N', 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetColorPS_Stroke},
		{FXBSTR_ID('T', '*', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_MoveToNextLine},
		{FXBSTR_ID('T', 'D', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_MoveTextPoint_SetLeading},
		{FXBSTR_ID('T', 'J', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_ShowText_Positioning},
		{FXBSTR_ID('T', 'L', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetTextLeading},
		{FXBSTR_ID('T', 'c', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetCharSpace},
		{FXBSTR_ID('T', 'd', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_MoveTextPoint},
		{FXBSTR_ID('T', 'f', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetFont},
		{FXBSTR_ID('T', 'j', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_ShowText},
		{FXBSTR_ID('T', 'm', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetTextMatrix},
		{FXBSTR_ID('T', 'r', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetTextRenderMode},
		{FXBSTR_ID('T', 's', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetTextRise},
		{FXBSTR_ID('T', 'w', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetWordSpace},
		{FXBSTR_ID('T', 'z', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetHorzScale},
		{FXBSTR_ID('W', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_Clip},
		{FXBSTR_ID('W', '*', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_EOClip},
		{FXBSTR_ID('b', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_CloseFillStrokePath},
		{FXBSTR_ID('b', '*', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_CloseEOFillStrokePath},
		{FXBSTR_ID('c', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_CurveTo_123},
		{FXBSTR_ID('c', 'm', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_ConcatMatrix},
		{FXBSTR_ID('c', 's', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetColorSpace_Fill},
		{FXBSTR_ID('d', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetDash},
		{FXBSTR_ID('d', '0', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetCharWidth},
		{FXBSTR_ID('d', '1', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetCachedDevice},
		{FXBSTR_ID('f', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_FillPath},
		{FXBSTR_ID('f', '*', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_EOFillPath},
		{FXBSTR_ID('g', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetGray_Fill},
		{FXBSTR_ID('g', 's', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetExtendGraphState},
		{FXBSTR_ID('h', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_ClosePath},
		{FXBSTR_ID('i', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetFlat},
		{FXBSTR_ID('j', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetLineJoin},
		{FXBSTR_ID('k', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetCMYKColor_Fill},
		{FXBSTR_ID('l', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_LineTo},
		{FXBSTR_ID('m', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_MoveTo},
		{FXBSTR_ID('n', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_EndPath},
		{FXBSTR_ID('q', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SaveGraphState},
		{FXBSTR_ID('r', 'e', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_Rectangle},
		{FXBSTR_ID('r', 'g', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetRGBColor_Fill},
		{FXBSTR_ID('r', 'i', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetRenderIntent},
		{FXBSTR_ID('s', 0, 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_CloseStrokePath},
		{FXBSTR_ID('s', 'c', 0, 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetColor_Fill},
		{FXBSTR_ID('s', 'c', 'n', 0),
		 &CSGPDF_SDK_StreamContentParser::Handle_SetColorPS_Fill},
		{FXBSTR_ID('s', 'h', 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_ShadeFill},
		{FXBSTR_ID('v', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_CurveTo_23},
		{FXBSTR_ID('w', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_SetLineWidth},
		{FXBSTR_ID('y', 0, 0, 0), &CSGPDF_SDK_StreamContentParser::Handle_CurveTo_13},
		});
}

void CSGPDF_SDK_StreamContentParser::OnOperator(ByteStringView op)
{
	static const OpCodes s_OpCodes = InitializeOpCodes();

	auto it = s_OpCodes.find(op.GetID());
	if (it != s_OpCodes.end())
		(this->*it->second)();
}

void CSGPDF_SDK_StreamContentParser::Handle_CloseFillStrokePath()
{
	Handle_ClosePath();
	AddPathObject(CFX_FillRenderOptions::FillType::kWinding, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_FillStrokePath()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kWinding, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_CloseEOFillStrokePath()
{
	AddPathPoint(m_PathStartX, m_PathStartY, FXPT_TYPE::LineTo, true);
	AddPathObject(CFX_FillRenderOptions::FillType::kEvenOdd, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_EOFillStrokePath()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kEvenOdd, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_BeginMarkedContent_Dictionary()
{
	CSGPDF_SDK_Object* pProperty = GetObject(0);
	if (!pProperty)
		return;

	ByteString tag = GetString(1);
	std::unique_ptr<CSGPDF_SDK_ContentMarks> new_marks =
		m_ContentMarksStack.top()->Clone();

	if (pProperty->IsName())
	{
		ByteString property_name = pProperty->GetString();
		CSGPDF_SDK_Dictionary* pHolder = FindResourceHolder("Properties");
		if (!pHolder || !pHolder->GetDictFor(property_name))
			return;
		new_marks->AddMarkWithPropertiesHolder(tag, pHolder, property_name);
	}
	else if (pProperty->IsDictionary())
	{
		new_marks->AddMarkWithDirectDict(tag, pProperty->AsDictionary());
	}
	else
	{
		return;
	}
	m_ContentMarksStack.push(std::move(new_marks));
}

void CSGPDF_SDK_StreamContentParser::Handle_BeginImage()
{
	FX_FILESIZE savePos = m_pSyntax->GetPos();
	auto pDict = m_pDocument->New<CSGPDF_SDK_Dictionary>();
	while (1)
	{
		CSGPDF_SDK_StreamParser::SyntaxType type = m_pSyntax->ParseNextElement();
		if (type == CSGPDF_SDK_StreamParser::Keyword)
		{
			if (m_pSyntax->GetWord() != "ID")
			{
				m_pSyntax->SetPos(savePos);
				return;
			}
		}
		if (type != CSGPDF_SDK_StreamParser::Name)
		{
			break;
		}
		auto word = m_pSyntax->GetWord();
		ByteString key(word.Last(word.GetLength() - 1));
		auto pObj = m_pSyntax->ReadNextObject(false, false, 0);
		if (!key.IsEmpty())
		{
			if (pObj && !pObj->IsInline())
			{
				pDict->SetNewFor<CSGPDF_SDK_Reference>(key, m_pDocument.Get(),
					pObj->GetObjNum());
			}
			else
			{
				pDict->SetFor(key, std::move(pObj));
			}
		}
	}
	ReplaceAbbr(pDict.Get());
	CSGPDF_SDK_Object* pCSObj = nullptr;
	if (pDict->KeyExist("ColorSpace"))
	{
		pCSObj = pDict->GetDirectObjectFor("ColorSpace");
		if (pCSObj->IsName())
		{
			ByteString name = pCSObj->GetString();
			if (name != "DeviceRGB" && name != "DeviceGray" && name != "DeviceCMYK")
			{
				pCSObj = FindResourceObj("ColorSpace", name);
				if (pCSObj && pCSObj->IsInline())
					pDict->SetFor("ColorSpace", pCSObj->Clone());
			}
		}
	}
	pDict->SetNewFor<CSGPDF_SDK_Name>("Subtype", "Image");
	RetainPtr<CSGPDF_SDK_Stream> pStream =
		m_pSyntax->ReadInlineStream(m_pDocument.Get(), std::move(pDict), pCSObj);
	while (1)
	{
		CSGPDF_SDK_StreamParser::SyntaxType type = m_pSyntax->ParseNextElement();
		if (type == CSGPDF_SDK_StreamParser::EndOfData)
		{
			break;
		}
		if (type != CSGPDF_SDK_StreamParser::Keyword)
		{
			continue;
		}
		if (m_pSyntax->GetWord() == "EI")
		{
			break;
		}
	}
	CSGPDF_SDK_ImageObject* pObj = AddImage(std::move(pStream));
	// Record the bounding box of this image, so rendering code can draw it
	// properly.
	if (pObj && pObj->GetImage()->IsMask())
		m_pObjectHolder->AddImageMaskBoundingBox(pObj->GetRect());
}

void CSGPDF_SDK_StreamContentParser::Handle_BeginMarkedContent()
{
	std::unique_ptr<CSGPDF_SDK_ContentMarks> new_marks =
		m_ContentMarksStack.top()->Clone();
	new_marks->AddMark(GetString(0));
	m_ContentMarksStack.push(std::move(new_marks));
}

void CSGPDF_SDK_StreamContentParser::Handle_BeginText()
{
	m_pCurStates->m_TextMatrix = CFX_Matrix();
	OnChangeTextMatrix();
	m_pCurStates->m_TextPos = CFX_PointF();
	m_pCurStates->m_TextLinePos = CFX_PointF();
}

void CSGPDF_SDK_StreamContentParser::Handle_CurveTo_123()
{
	AddPathPoint(GetNumber(5), GetNumber(4), FXPT_TYPE::BezierTo, false);
	AddPathPoint(GetNumber(3), GetNumber(2), FXPT_TYPE::BezierTo, false);
	AddPathPoint(GetNumber(1), GetNumber(0), FXPT_TYPE::BezierTo, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_ConcatMatrix()
{
	CFX_Matrix new_matrix(GetNumber(5), GetNumber(4), GetNumber(3), GetNumber(2),
		GetNumber(1), GetNumber(0));
	m_pCurStates->m_CTM = new_matrix * m_pCurStates->m_CTM;
	OnChangeTextMatrix();
}

void CSGPDF_SDK_StreamContentParser::Handle_SetColorSpace_Fill()
{
	RetainPtr<CSGPDF_SDK_ColorSpace> pCS = FindColorSpace(GetString(0));
	if (!pCS)
		return;

	m_pCurStates->m_ColorState.GetMutableFillColor()->SetColorSpace(pCS);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetColorSpace_Stroke()
{
	RetainPtr<CSGPDF_SDK_ColorSpace> pCS = FindColorSpace(GetString(0));
	if (!pCS)
		return;

	m_pCurStates->m_ColorState.GetMutableStrokeColor()->SetColorSpace(pCS);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetDash()
{
	CSGPDF_SDK_Array* pArray = ToArray(GetObject(1));
	if (!pArray)
		return;

	m_pCurStates->SetLineDash(pArray, GetNumber(0), 1.0f);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetCharWidth()
{
	m_Type3Data[0] = GetNumber(1);
	m_Type3Data[1] = GetNumber(0);
	m_bColored = true;
}

void CSGPDF_SDK_StreamContentParser::Handle_SetCachedDevice()
{
	for (int i = 0; i < 6; i++)
	{
		m_Type3Data[i] = GetNumber(5 - i);
	}
	m_bColored = false;
}

void CSGPDF_SDK_StreamContentParser::Handle_ExecuteXObject()
{
	ByteString name = GetString(0);
	if (name == m_LastImageName && m_pLastImage && m_pLastImage->GetStream() &&
		m_pLastImage->GetStream()->GetObjNum())
	{
		CSGPDF_SDK_ImageObject* pObj = AddImage(m_pLastImage);
		// Record the bounding box of this image, so rendering code can draw it
		// properly.
		if (pObj && pObj->GetImage()->IsMask())
			m_pObjectHolder->AddImageMaskBoundingBox(pObj->GetRect());
		return;
	}

	CSGPDF_SDK_Stream* pXObject = ToStream(FindResourceObj("XObject", name));
	if (!pXObject)
	{
		m_bResourceMissing = true;
		return;
	}

	ByteString type;
	if (pXObject->GetDict())
		type = pXObject->GetDict()->GetStringFor("Subtype");

	if (type == "Form")
	{
		AddForm(pXObject);
		return;
	}

	if (type == "Image")
	{
		CSGPDF_SDK_ImageObject* pObj = pXObject->IsInline()
			? AddImage(ToStream(pXObject->Clone()))
			: AddImage(pXObject->GetObjNum());

		m_LastImageName = std::move(name);
		if (pObj)
		{
			m_pLastImage = pObj->GetImage();
			if (m_pLastImage->IsMask())
				m_pObjectHolder->AddImageMaskBoundingBox(pObj->GetRect());
		}
	}
}

void CSGPDF_SDK_StreamContentParser::AddForm(CSGPDF_SDK_Stream* pStream)
{
	CSGPDF_SDK_AllStates status;
	status.m_GeneralState = m_pCurStates->m_GeneralState;
	status.m_GraphState = m_pCurStates->m_GraphState;
	status.m_ColorState = m_pCurStates->m_ColorState;
	status.m_TextState = m_pCurStates->m_TextState;
	auto form = std::make_unique<CSGPDF_SDK_Form>(
		m_pDocument.Get(), m_pPageResources.Get(), pStream, m_pResources.Get());
	form->ParseContent(&status, nullptr, m_ParsedSet.Get());

	CFX_Matrix matrix = m_pCurStates->m_CTM * m_mtContentToUser;

	auto pFormObj = std::make_unique<CSGPDF_SDK_FormObject>(GetCurrentStreamIndex(),
		std::move(form), matrix);
	if (!m_pObjectHolder->BackgroundAlphaNeeded() &&
		pFormObj->form()->BackgroundAlphaNeeded())
	{
		m_pObjectHolder->SetBackgroundAlphaNeeded(true);
	}
	pFormObj->CalcBoundingBox();
	SetGraphicStates(pFormObj.get(), true, true, true);
	m_pObjectHolder->AppendPageObject(std::move(pFormObj));
}

CSGPDF_SDK_ImageObject* CSGPDF_SDK_StreamContentParser::AddImage(
	RetainPtr<CSGPDF_SDK_Stream> pStream)
{
	if (!pStream)
		return nullptr;

	auto pImageObj = std::make_unique<CSGPDF_SDK_ImageObject>(GetCurrentStreamIndex());
	pImageObj->SetImage(
		pdfium::MakeRetain<CSGPDF_SDK_Image>(m_pDocument.Get(), std::move(pStream)));

	return AddImageObject(std::move(pImageObj));
}

CSGPDF_SDK_ImageObject* CSGPDF_SDK_StreamContentParser::AddImage(uint32_t streamObjNum)
{
	auto pImageObj = std::make_unique<CSGPDF_SDK_ImageObject>(GetCurrentStreamIndex());
	pImageObj->SetImage(CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get())
		->GetImage(streamObjNum));

	return AddImageObject(std::move(pImageObj));
}

CSGPDF_SDK_ImageObject* CSGPDF_SDK_StreamContentParser::AddImage(
	const RetainPtr<CSGPDF_SDK_Image>& pImage)
{
	if (!pImage)
		return nullptr;

	auto pImageObj = std::make_unique<CSGPDF_SDK_ImageObject>(GetCurrentStreamIndex());
	pImageObj->SetImage(CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get())
		->GetImage(pImage->GetStream()->GetObjNum()));

	return AddImageObject(std::move(pImageObj));
}

CSGPDF_SDK_ImageObject* CSGPDF_SDK_StreamContentParser::AddImageObject(
	std::unique_ptr<CSGPDF_SDK_ImageObject> pImageObj)
{
	SetGraphicStates(pImageObj.get(), pImageObj->GetImage()->IsMask(), false,
		false);

	CFX_Matrix ImageMatrix = m_pCurStates->m_CTM * m_mtContentToUser;
	pImageObj->set_matrix(ImageMatrix);
	pImageObj->CalcBoundingBox();

	CSGPDF_SDK_ImageObject* pRet = pImageObj.get();
	m_pObjectHolder->AppendPageObject(std::move(pImageObj));
	return pRet;
}

std::vector<float> CSGPDF_SDK_StreamContentParser::GetColors() const
{
	DCHECK(m_ParamCount > 0);
	return GetNumbers(m_ParamCount);
}

std::vector<float> CSGPDF_SDK_StreamContentParser::GetNamedColors() const
{
	DCHECK(m_ParamCount > 0);
	const uint32_t nvalues = m_ParamCount - 1;
	std::vector<float> values(nvalues);
	for (size_t i = 0; i < nvalues; ++i)
		values[i] = GetNumber(m_ParamCount - i - 1);
	return values;
}

void CSGPDF_SDK_StreamContentParser::Handle_MarkPlace_Dictionary()
{
}

void CSGPDF_SDK_StreamContentParser::Handle_EndImage()
{
}

void CSGPDF_SDK_StreamContentParser::Handle_EndMarkedContent()
{
	// First element is a sentinel, so do not pop it, ever. This may come up if
	// the EMCs are mismatched with the BMC/BDCs.
	if (m_ContentMarksStack.size() > 1)
		m_ContentMarksStack.pop();
}

void CSGPDF_SDK_StreamContentParser::Handle_EndText()
{
	if (m_ClipTextList.empty())
		return;

	if (TextRenderingModeIsClipMode(m_pCurStates->m_TextState.GetTextMode()))
		m_pCurStates->m_ClipPath.AppendTexts(&m_ClipTextList);

	m_ClipTextList.clear();
}

void CSGPDF_SDK_StreamContentParser::Handle_FillPath()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kWinding, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_FillPathOld()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kWinding, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_EOFillPath()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kEvenOdd, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetGray_Fill()
{
	RetainPtr<CSGPDF_SDK_ColorSpace> pCS =
		CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICEGRAY);
	m_pCurStates->m_ColorState.SetFillColor(pCS, GetNumbers(1));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetGray_Stroke()
{
	RetainPtr<CSGPDF_SDK_ColorSpace> pCS =
		CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICEGRAY);
	m_pCurStates->m_ColorState.SetStrokeColor(pCS, GetNumbers(1));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetExtendGraphState()
{
	ByteString name = GetString(0);
	CSGPDF_SDK_Dictionary* pGS = ToDictionary(FindResourceObj("ExtGState", name));
	if (!pGS)
	{
		m_bResourceMissing = true;
		return;
	}
	m_pCurStates->ProcessExtGS(pGS, this);
}

void CSGPDF_SDK_StreamContentParser::Handle_ClosePath()
{
	if (m_PathPoints.empty())
		return;

	if (m_PathStartX != m_PathCurrentX || m_PathStartY != m_PathCurrentY)
		AddPathPoint(m_PathStartX, m_PathStartY, FXPT_TYPE::LineTo, true);
	else if (m_PathPoints.back().m_Type != FXPT_TYPE::MoveTo)
		m_PathPoints.back().m_CloseFigure = true;
}

void CSGPDF_SDK_StreamContentParser::Handle_SetFlat()
{
	m_pCurStates->m_GeneralState.SetFlatness(GetNumber(0));
}

void CSGPDF_SDK_StreamContentParser::Handle_BeginImageData()
{
}

void CSGPDF_SDK_StreamContentParser::Handle_SetLineJoin()
{
	m_pCurStates->m_GraphState.SetLineJoin(
		static_cast<CFX_GraphStateData::LineJoin>(GetInteger(0)));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetLineCap()
{
	m_pCurStates->m_GraphState.SetLineCap(
		static_cast<CFX_GraphStateData::LineCap>(GetInteger(0)));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetCMYKColor_Fill()
{
	if (m_ParamCount != 4)
		return;

	RetainPtr<CSGPDF_SDK_ColorSpace> pCS =
		CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICECMYK);
	m_pCurStates->m_ColorState.SetFillColor(pCS, GetNumbers(4));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetCMYKColor_Stroke()
{
	if (m_ParamCount != 4)
		return;

	RetainPtr<CSGPDF_SDK_ColorSpace> pCS =
		CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICECMYK);
	m_pCurStates->m_ColorState.SetStrokeColor(pCS, GetNumbers(4));
}

void CSGPDF_SDK_StreamContentParser::Handle_LineTo()
{
	if (m_ParamCount != 2)
		return;

	AddPathPoint(GetNumber(1), GetNumber(0), FXPT_TYPE::LineTo, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_MoveTo()
{
	if (m_ParamCount != 2)
		return;

	AddPathPoint(GetNumber(1), GetNumber(0), FXPT_TYPE::MoveTo, false);
	ParsePathObject();
}

void CSGPDF_SDK_StreamContentParser::Handle_SetMiterLimit()
{
	m_pCurStates->m_GraphState.SetMiterLimit(GetNumber(0));
}

void CSGPDF_SDK_StreamContentParser::Handle_MarkPlace()
{
}

void CSGPDF_SDK_StreamContentParser::Handle_EndPath()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kNoFill, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_SaveGraphState()
{
	auto pStates = std::make_unique<CSGPDF_SDK_AllStates>();
	pStates->Copy(*m_pCurStates);
	m_StateStack.push_back(std::move(pStates));
}

void CSGPDF_SDK_StreamContentParser::Handle_RestoreGraphState()
{
	if (m_StateStack.empty())
		return;
	std::unique_ptr<CSGPDF_SDK_AllStates> pStates = std::move(m_StateStack.back());
	m_StateStack.pop_back();
	m_pCurStates->Copy(*pStates);
}

void CSGPDF_SDK_StreamContentParser::Handle_Rectangle()
{
	float x = GetNumber(3), y = GetNumber(2);
	float w = GetNumber(1), h = GetNumber(0);
	AddPathRect(x, y, w, h);
}

void CSGPDF_SDK_StreamContentParser::AddPathRect(float x, float y, float w, float h)
{
	AddPathPoint(x, y, FXPT_TYPE::MoveTo, false);
	AddPathPoint(x + w, y, FXPT_TYPE::LineTo, false);
	AddPathPoint(x + w, y + h, FXPT_TYPE::LineTo, false);
	AddPathPoint(x, y + h, FXPT_TYPE::LineTo, false);
	AddPathPoint(x, y, FXPT_TYPE::LineTo, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetRGBColor_Fill()
{
	if (m_ParamCount != 3)
		return;

	RetainPtr<CSGPDF_SDK_ColorSpace> pCS = CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICERGB);
	m_pCurStates->m_ColorState.SetFillColor(pCS, GetNumbers(3));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetRGBColor_Stroke()
{
	if (m_ParamCount != 3)
		return;

	RetainPtr<CSGPDF_SDK_ColorSpace> pCS = CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICERGB);
	m_pCurStates->m_ColorState.SetStrokeColor(pCS, GetNumbers(3));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetRenderIntent()
{
}

void CSGPDF_SDK_StreamContentParser::Handle_CloseStrokePath()
{
	Handle_ClosePath();
	AddPathObject(CFX_FillRenderOptions::FillType::kNoFill, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_StrokePath()
{
	AddPathObject(CFX_FillRenderOptions::FillType::kNoFill, true);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetColor_Fill()
{
	int nargs = std::min(m_ParamCount, 4U);
	m_pCurStates->m_ColorState.SetFillColor(nullptr, GetNumbers(nargs));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetColor_Stroke()
{
	int nargs = std::min(m_ParamCount, 4U);
	m_pCurStates->m_ColorState.SetStrokeColor(nullptr, GetNumbers(nargs));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetColorPS_Fill()
{
	CSGPDF_SDK_Object* pLastParam = GetObject(0);
	if (!pLastParam)
		return;

	if (!pLastParam->IsName())
	{
		m_pCurStates->m_ColorState.SetFillColor(nullptr, GetColors());
		return;
	}

	// A valid |pLastParam| implies |m_ParamCount| > 0, so GetNamedColors() call
	// below is safe.
	RetainPtr<CSGPDF_SDK_Pattern> pPattern = FindPattern(GetString(0), false);
	if (pPattern)
		m_pCurStates->m_ColorState.SetFillPattern(pPattern, GetNamedColors());
}

void CSGPDF_SDK_StreamContentParser::Handle_SetColorPS_Stroke()
{
	CSGPDF_SDK_Object* pLastParam = GetObject(0);
	if (!pLastParam)
		return;

	if (!pLastParam->IsName())
	{
		m_pCurStates->m_ColorState.SetStrokeColor(nullptr, GetColors());
		return;
	}

	// A valid |pLastParam| implies |m_ParamCount| > 0, so GetNamedColors() call
	// below is safe.
	RetainPtr<CSGPDF_SDK_Pattern> pPattern = FindPattern(GetString(0), false);
	if (pPattern)
		m_pCurStates->m_ColorState.SetStrokePattern(pPattern, GetNamedColors());
}

void CSGPDF_SDK_StreamContentParser::Handle_ShadeFill()
{
	RetainPtr<CSGPDF_SDK_Pattern> pPattern = FindPattern(GetString(0), true);
	if (!pPattern)
		return;

	CSGPDF_SDK_ShadingPattern* pShading = pPattern->AsShadingPattern();
	if (!pShading)
		return;

	if (!pShading->IsShadingObject() || !pShading->Load())
		return;

	CFX_Matrix matrix = m_pCurStates->m_CTM * m_mtContentToUser;
	auto pObj = std::make_unique<CSGPDF_SDK_ShadingObject>(GetCurrentStreamIndex(),
		pShading, matrix);
	SetGraphicStates(pObj.get(), false, false, false);
	CFX_FloatRect bbox =
		pObj->m_ClipPath.HasRef() ? pObj->m_ClipPath.GetClipBox() : m_BBox;
	if (pShading->IsMeshShading())
		bbox.Intersect(GetShadingBBox(pShading, pObj->matrix()));
	pObj->SetRect(bbox);
	m_pObjectHolder->AppendPageObject(std::move(pObj));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetCharSpace()
{
	m_pCurStates->m_TextState.SetCharSpace(GetNumber(0));
}

void CSGPDF_SDK_StreamContentParser::Handle_MoveTextPoint()
{
	m_pCurStates->m_TextLinePos += CFX_PointF(GetNumber(1), GetNumber(0));
	m_pCurStates->m_TextPos = m_pCurStates->m_TextLinePos;
}

void CSGPDF_SDK_StreamContentParser::Handle_MoveTextPoint_SetLeading()
{
	Handle_MoveTextPoint();
	m_pCurStates->m_TextLeading = -GetNumber(0);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetFont()
{
	float fs = GetNumber(0);
	if (fs == 0)
	{
		constexpr float kDefaultFontSize = 0.0f;
		fs = kDefaultFontSize;
	}

	m_pCurStates->m_TextState.SetFontSize(fs);
	RetainPtr<CSGPDF_SDK_Font> pFont = FindFont(GetString(1));
	if (pFont)
		m_pCurStates->m_TextState.SetFont(pFont);
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_StreamContentParser::FindResourceHolder(
	const ByteString& type)
{
	if (!m_pResources)
		return nullptr;

	CSGPDF_SDK_Dictionary* pDict = m_pResources->GetDictFor(type);
	if (pDict)
		return pDict;

	if (m_pResources == m_pPageResources || !m_pPageResources)
		return nullptr;

	return m_pPageResources->GetDictFor(type);
}

CSGPDF_SDK_Object* CSGPDF_SDK_StreamContentParser::FindResourceObj(const ByteString& type,
	const ByteString& name)
{
	CSGPDF_SDK_Dictionary* pHolder = FindResourceHolder(type);
	return pHolder ? pHolder->GetDirectObjectFor(name) : nullptr;
}

RetainPtr<CSGPDF_SDK_Font> CSGPDF_SDK_StreamContentParser::FindFont(
	const ByteString& name)
{
	CSGPDF_SDK_Dictionary* pFontDict = ToDictionary(FindResourceObj("Font", name));
	if (!pFontDict)
	{
		m_bResourceMissing = true;
		return CSGPDF_SDK_Font::GetStockFont(m_pDocument.Get(),
			CFX_Font::kDefaultAnsiFontName);
	}
	RetainPtr<CSGPDF_SDK_Font> pFont =
		CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get())->GetFont(pFontDict);
	if (pFont && pFont->IsType3Font())
	{
		pFont->AsType3Font()->SetPageResources(m_pResources.Get());
		pFont->AsType3Font()->CheckType3FontMetrics();
	}
	return pFont;
}

RetainPtr<CSGPDF_SDK_ColorSpace> CSGPDF_SDK_StreamContentParser::FindColorSpace(
	const ByteString& name)
{
	if (name == "Pattern")
		return CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_PATTERN);

	if (name == "DeviceGray" || name == "DeviceCMYK" || name == "DeviceRGB")
	{
		ByteString defname = "Default";
		defname += name.Last(name.GetLength() - 7);
		const CSGPDF_SDK_Object* pDefObj = FindResourceObj("ColorSpace", defname);
		if (!pDefObj)
		{
			if (name == "DeviceGray")
				return CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICEGRAY);

			if (name == "DeviceRGB")
				return CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICERGB);

			return CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICECMYK);
		}
		return CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get())
			->GetColorSpace(pDefObj, nullptr);
	}
	const CSGPDF_SDK_Object* pCSObj = FindResourceObj("ColorSpace", name);
	if (!pCSObj)
	{
		m_bResourceMissing = true;
		return nullptr;
	}
	return CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get())
		->GetColorSpace(pCSObj, nullptr);
}

RetainPtr<CSGPDF_SDK_Pattern> CSGPDF_SDK_StreamContentParser::FindPattern(
	const ByteString& name,
	bool bShading)
{
	CSGPDF_SDK_Object* pPattern =
		FindResourceObj(bShading ? "Shading" : "Pattern", name);
	if (!pPattern || (!pPattern->IsDictionary() && !pPattern->IsStream()))
	{
		m_bResourceMissing = true;
		return nullptr;
	}
	return CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get())
		->GetPattern(pPattern, bShading, m_pCurStates->m_ParentMatrix);
}

void CSGPDF_SDK_StreamContentParser::AddTextObject(const ByteString* pStrs,
	float fInitKerning,
	const std::vector<float>& kernings,
	size_t nSegs)
{
	RetainPtr<CSGPDF_SDK_Font> pFont = m_pCurStates->m_TextState.GetFont();
	if (!pFont)
		return;

	if (fInitKerning != 0)
	{
		if (pFont->IsVertWriting())
			m_pCurStates->m_TextPos.y -= GetVerticalTextSize(fInitKerning);
		else
			m_pCurStates->m_TextPos.x -= GetHorizontalTextSize(fInitKerning);
	}
	if (nSegs == 0)
		return;

	const TextRenderingMode text_mode =
		pFont->IsType3Font() ? TextRenderingMode::MODE_FILL
		: m_pCurStates->m_TextState.GetTextMode();
	{
		auto pText = std::make_unique<CSGPDF_SDK_TextObject>(GetCurrentStreamIndex());
		m_pLastTextObject = pText.get();
		SetGraphicStates(m_pLastTextObject.Get(), true, true, true);
		if (TextRenderingModeIsStrokeMode(text_mode))
		{
			float* pCTM = pText->m_TextState.GetMutableCTM();
			pCTM[0] = m_pCurStates->m_CTM.a;
			pCTM[1] = m_pCurStates->m_CTM.c;
			pCTM[2] = m_pCurStates->m_CTM.b;
			pCTM[3] = m_pCurStates->m_CTM.d;
		}
		pText->SetSegments(pStrs, kernings, nSegs);
		pText->SetPosition(
			m_mtContentToUser.Transform(m_pCurStates->m_CTM.Transform(
				m_pCurStates->m_TextMatrix.Transform(CFX_PointF(
					m_pCurStates->m_TextPos.x,
					m_pCurStates->m_TextPos.y + m_pCurStates->m_TextRise)))));

		m_pCurStates->m_TextPos +=
			pText->CalcPositionData(m_pCurStates->m_TextHorzScale);
		if (TextRenderingModeIsClipMode(text_mode))
		{
			m_ClipTextList.push_back(
				std::unique_ptr<CSGPDF_SDK_TextObject>(pText->Clone()));
		}
		m_pObjectHolder->AppendPageObject(std::move(pText));
	}
	if (!kernings.empty() && kernings[nSegs - 1] != 0)
	{
		if (pFont->IsVertWriting())
			m_pCurStates->m_TextPos.y -= GetVerticalTextSize(kernings[nSegs - 1]);
		else
			m_pCurStates->m_TextPos.x -= GetHorizontalTextSize(kernings[nSegs - 1]);
	}
}

float CSGPDF_SDK_StreamContentParser::GetHorizontalTextSize(float fKerning) const
{
	return GetVerticalTextSize(fKerning) * m_pCurStates->m_TextHorzScale;
}

float CSGPDF_SDK_StreamContentParser::GetVerticalTextSize(float fKerning) const
{
	return fKerning * m_pCurStates->m_TextState.GetFontSize() / 1000;
}

int32_t CSGPDF_SDK_StreamContentParser::GetCurrentStreamIndex()
{
	auto it =
		std::upper_bound(m_StreamStartOffsets.begin(), m_StreamStartOffsets.end(),
			m_pSyntax->GetPos() + m_StartParseOffset);
	return (it - m_StreamStartOffsets.begin()) - 1;
}

void CSGPDF_SDK_StreamContentParser::Handle_ShowText()
{
	ByteString str = GetString(0);
	if (!str.IsEmpty())
		AddTextObject(&str, 0, std::vector<float>(), 1);
}

void CSGPDF_SDK_StreamContentParser::Handle_ShowText_Positioning()
{
	CSGPDF_SDK_Array* pArray = ToArray(GetObject(0));
	if (!pArray)
		return;

	size_t n = pArray->size();
	size_t nsegs = 0;
	for (size_t i = 0; i < n; i++)
	{
		const CSGPDF_SDK_Object* pDirectObject = pArray->GetDirectObjectAt(i);
		if (pDirectObject && pDirectObject->IsString())
			nsegs++;
	}
	if (nsegs == 0)
	{
		for (size_t i = 0; i < n; i++)
		{
			float fKerning = pArray->GetNumberAt(i);
			if (fKerning != 0)
				m_pCurStates->m_TextPos.x -= GetHorizontalTextSize(fKerning);
		}
		return;
	}
	std::vector<ByteString> strs(nsegs);
	std::vector<float> kernings(nsegs);
	size_t iSegment = 0;
	float fInitKerning = 0;
	for (size_t i = 0; i < n; i++)
	{
		CSGPDF_SDK_Object* pObj = pArray->GetDirectObjectAt(i);
		if (!pObj)
			continue;

		if (pObj->IsString())
		{
			ByteString str = pObj->GetString();
			if (str.IsEmpty())
				continue;
			strs[iSegment] = std::move(str);
			kernings[iSegment++] = 0;
		}
		else
		{
			float num = pObj->GetNumber();
			if (iSegment == 0)
				fInitKerning += num;
			else
				kernings[iSegment - 1] += num;
		}
	}
	AddTextObject(strs.data(), fInitKerning, kernings, iSegment);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetTextLeading()
{
	m_pCurStates->m_TextLeading = GetNumber(0);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetTextMatrix()
{
	m_pCurStates->m_TextMatrix =
		CFX_Matrix(GetNumber(5), GetNumber(4), GetNumber(3), GetNumber(2),
			GetNumber(1), GetNumber(0));
	OnChangeTextMatrix();
	m_pCurStates->m_TextPos = CFX_PointF();
	m_pCurStates->m_TextLinePos = CFX_PointF();
}

void CSGPDF_SDK_StreamContentParser::OnChangeTextMatrix()
{
	CFX_Matrix text_matrix(m_pCurStates->m_TextHorzScale, 0.0f, 0.0f, 1.0f, 0.0f,
		0.0f);
	text_matrix.Concat(m_pCurStates->m_TextMatrix);
	text_matrix.Concat(m_pCurStates->m_CTM);
	text_matrix.Concat(m_mtContentToUser);
	float* pTextMatrix = m_pCurStates->m_TextState.GetMutableMatrix();
	pTextMatrix[0] = text_matrix.a;
	pTextMatrix[1] = text_matrix.c;
	pTextMatrix[2] = text_matrix.b;
	pTextMatrix[3] = text_matrix.d;
}

void CSGPDF_SDK_StreamContentParser::Handle_SetTextRenderMode()
{
	TextRenderingMode mode;
	if (SetTextRenderingModeFromInt(GetInteger(0), &mode))
		m_pCurStates->m_TextState.SetTextMode(mode);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetTextRise()
{
	m_pCurStates->m_TextRise = GetNumber(0);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetWordSpace()
{
	m_pCurStates->m_TextState.SetWordSpace(GetNumber(0));
}

void CSGPDF_SDK_StreamContentParser::Handle_SetHorzScale()
{
	if (m_ParamCount != 1)
	{
		return;
	}
	m_pCurStates->m_TextHorzScale = GetNumber(0) / 100;
	OnChangeTextMatrix();
}

void CSGPDF_SDK_StreamContentParser::Handle_MoveToNextLine()
{
	m_pCurStates->m_TextLinePos.y -= m_pCurStates->m_TextLeading;
	m_pCurStates->m_TextPos = m_pCurStates->m_TextLinePos;
}

void CSGPDF_SDK_StreamContentParser::Handle_CurveTo_23()
{
	AddPathPoint(m_PathCurrentX, m_PathCurrentY, FXPT_TYPE::BezierTo, false);
	AddPathPoint(GetNumber(3), GetNumber(2), FXPT_TYPE::BezierTo, false);
	AddPathPoint(GetNumber(1), GetNumber(0), FXPT_TYPE::BezierTo, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_SetLineWidth()
{
	m_pCurStates->m_GraphState.SetLineWidth(GetNumber(0));
}

void CSGPDF_SDK_StreamContentParser::Handle_Clip()
{
	m_PathClipType = CFX_FillRenderOptions::FillType::kWinding;
}

void CSGPDF_SDK_StreamContentParser::Handle_EOClip()
{
	m_PathClipType = CFX_FillRenderOptions::FillType::kEvenOdd;
}

void CSGPDF_SDK_StreamContentParser::Handle_CurveTo_13()
{
	AddPathPoint(GetNumber(3), GetNumber(2), FXPT_TYPE::BezierTo, false);
	AddPathPoint(GetNumber(1), GetNumber(0), FXPT_TYPE::BezierTo, false);
	AddPathPoint(GetNumber(1), GetNumber(0), FXPT_TYPE::BezierTo, false);
}

void CSGPDF_SDK_StreamContentParser::Handle_NextLineShowText()
{
	Handle_MoveToNextLine();
	Handle_ShowText();
}

void CSGPDF_SDK_StreamContentParser::Handle_NextLineShowText_Space()
{
	m_pCurStates->m_TextState.SetWordSpace(GetNumber(2));
	m_pCurStates->m_TextState.SetCharSpace(GetNumber(1));
	Handle_NextLineShowText();
}

void CSGPDF_SDK_StreamContentParser::Handle_Invalid()
{
}

void CSGPDF_SDK_StreamContentParser::AddPathPoint(float x,
	float y,
	FXPT_TYPE type,
	bool close)
{
	// If the path point is the same move as the previous one and neither of them
	// closes the path, then just skip it.
	if (!close && type == FXPT_TYPE::MoveTo && !m_PathPoints.empty() &&
		!m_PathPoints.back().m_CloseFigure &&
		m_PathPoints.back().m_Type == type && m_PathCurrentX == x &&
		m_PathCurrentY == y)
	{
		return;
	}

	m_PathCurrentX = x;
	m_PathCurrentY = y;
	if (type == FXPT_TYPE::MoveTo && !close)
	{
		m_PathStartX = x;
		m_PathStartY = y;
		if (!m_PathPoints.empty() &&
			m_PathPoints.back().IsTypeAndOpen(FXPT_TYPE::MoveTo))
		{
			m_PathPoints.back().m_Point = CFX_PointF(x, y);
			return;
		}
	}
	else if (m_PathPoints.empty())
	{
		return;
	}
	m_PathPoints.push_back(FX_PATHPOINT(CFX_PointF(x, y), type, close));
}

void CSGPDF_SDK_StreamContentParser::AddPathObject(
	CFX_FillRenderOptions::FillType fill_type,
	bool bStroke)
{
	std::vector<FX_PATHPOINT> path_points;
	path_points.swap(m_PathPoints);
	CFX_FillRenderOptions::FillType path_clip_type = m_PathClipType;
	m_PathClipType = CFX_FillRenderOptions::FillType::kNoFill;

	if (path_points.empty())
		return;

	if (path_points.size() == 1)
	{
		if (path_clip_type != CFX_FillRenderOptions::FillType::kNoFill)
		{
			CSGPDF_SDK_Path path;
			path.AppendRect(0, 0, 0, 0);
			m_pCurStates->m_ClipPath.AppendPath(
				path, CFX_FillRenderOptions::FillType::kWinding, true);
		}
		return;
	}

	if (path_points.back().IsTypeAndOpen(FXPT_TYPE::MoveTo))
		path_points.pop_back();

	CSGPDF_SDK_Path path;
	for (const auto& point : path_points)
	{
		if (point.m_CloseFigure)
			path.AppendPointAndClose(point.m_Point, point.m_Type);
		else
			path.AppendPoint(point.m_Point, point.m_Type);
	}

	CFX_Matrix matrix = m_pCurStates->m_CTM * m_mtContentToUser;
	if (bStroke || fill_type != CFX_FillRenderOptions::FillType::kNoFill)
	{
		auto pPathObj = std::make_unique<CSGPDF_SDK_PathObject>(GetCurrentStreamIndex());
		pPathObj->set_stroke(bStroke);
		pPathObj->set_filltype(fill_type);
		pPathObj->path() = path;
		pPathObj->set_matrix(matrix);
		SetGraphicStates(pPathObj.get(), true, false, true);
		pPathObj->CalcBoundingBox();
		m_pObjectHolder->AppendPageObject(std::move(pPathObj));
	}
	if (path_clip_type != CFX_FillRenderOptions::FillType::kNoFill)
	{
		if (!matrix.IsIdentity())
			path.Transform(matrix);
		m_pCurStates->m_ClipPath.AppendPath(path, path_clip_type, true);
	}
}

uint32_t CSGPDF_SDK_StreamContentParser::Parse(
	const uint8_t* pData,
	uint32_t dwSize,
	uint32_t start_offset,
	uint32_t max_cost,
	const std::vector<uint32_t>& stream_start_offsets)
{
	DCHECK(start_offset < dwSize);

	// Parsing will be done from |pDataStart|, for at most |size_left| bytes.
	const uint8_t* pDataStart = pData + start_offset;
	uint32_t size_left = dwSize - start_offset;

	m_StartParseOffset = start_offset;

	if (m_ParsedSet->size() > kMaxFormLevel ||
		pdfium::Contains(*m_ParsedSet, pDataStart))
	{
		return size_left;
	}

	m_StreamStartOffsets = stream_start_offsets;

	pdfium::ScopedSetInsertion<const uint8_t*> scopedInsert(m_ParsedSet.Get(),
		pDataStart);

	uint32_t init_obj_count = m_pObjectHolder->GetPageObjectCount();
	CSGPDF_SDK_StreamParser syntax(pdfium::make_span(pDataStart, size_left),
		m_pDocument->GetByteStringPool());
	AutoNuller<UnownedPtr<CSGPDF_SDK_StreamParser>> auto_clearer(&m_pSyntax);
	m_pSyntax = &syntax;
	while (1)
	{
		uint32_t cost = m_pObjectHolder->GetPageObjectCount() - init_obj_count;
		if (max_cost && cost >= max_cost)
		{
			break;
		}
		switch (syntax.ParseNextElement())
		{
			case CSGPDF_SDK_StreamParser::EndOfData:
				return m_pSyntax->GetPos();
			case CSGPDF_SDK_StreamParser::Keyword:
				OnOperator(syntax.GetWord());
				ClearAllParams();
				break;
			case CSGPDF_SDK_StreamParser::Number:
				AddNumberParam(syntax.GetWord());
				break;
			case CSGPDF_SDK_StreamParser::Name:
			{
				auto word = syntax.GetWord();
				AddNameParam(word.Last(word.GetLength() - 1));
				break;
			}
			default:
				AddObjectParam(syntax.GetObject());
		}
	}
	return m_pSyntax->GetPos();
}

void CSGPDF_SDK_StreamContentParser::ParsePathObject()
{
	float params[6] = {};
	int nParams = 0;
	int last_pos = m_pSyntax->GetPos();
	while (1)
	{
		CSGPDF_SDK_StreamParser::SyntaxType type = m_pSyntax->ParseNextElement();
		bool bProcessed = true;
		switch (type)
		{
			case CSGPDF_SDK_StreamParser::EndOfData:
				return;
			case CSGPDF_SDK_StreamParser::Keyword:
			{
				ByteStringView strc = m_pSyntax->GetWord();
				int len = strc.GetLength();
				if (len == 1)
				{
					switch (strc[0])
					{
						case kPathOperatorSubpath:
							AddPathPoint(params[0], params[1], FXPT_TYPE::MoveTo, false);
							nParams = 0;
							break;
						case kPathOperatorLine:
							AddPathPoint(params[0], params[1], FXPT_TYPE::LineTo, false);
							nParams = 0;
							break;
						case kPathOperatorCubicBezier1:
							AddPathPoint(params[0], params[1], FXPT_TYPE::BezierTo, false);
							AddPathPoint(params[2], params[3], FXPT_TYPE::BezierTo, false);
							AddPathPoint(params[4], params[5], FXPT_TYPE::BezierTo, false);
							nParams = 0;
							break;
						case kPathOperatorCubicBezier2:
							AddPathPoint(m_PathCurrentX, m_PathCurrentY, FXPT_TYPE::BezierTo,
								false);
							AddPathPoint(params[0], params[1], FXPT_TYPE::BezierTo, false);
							AddPathPoint(params[2], params[3], FXPT_TYPE::BezierTo, false);
							nParams = 0;
							break;
						case kPathOperatorCubicBezier3:
							AddPathPoint(params[0], params[1], FXPT_TYPE::BezierTo, false);
							AddPathPoint(params[2], params[3], FXPT_TYPE::BezierTo, false);
							AddPathPoint(params[2], params[3], FXPT_TYPE::BezierTo, false);
							nParams = 0;
							break;
						case kPathOperatorClosePath:
							Handle_ClosePath();
							nParams = 0;
							break;
						default:
							bProcessed = false;
							break;
					}
				}
				else if (len == 2)
				{
					if (strc[0] == kPathOperatorRectangle[0] &&
						strc[1] == kPathOperatorRectangle[1])
					{
						AddPathRect(params[0], params[1], params[2], params[3]);
						nParams = 0;
					}
					else
					{
						bProcessed = false;
					}
				}
				else
				{
					bProcessed = false;
				}
				if (bProcessed)
				{
					last_pos = m_pSyntax->GetPos();
				}
				break;
			}
			case CSGPDF_SDK_StreamParser::Number:
			{
				if (nParams == 6)
					break;

				FX_Number number(m_pSyntax->GetWord());
				params[nParams++] = number.GetFloat();
				break;
			}
			default:
				bProcessed = false;
		}
		if (!bProcessed)
		{
			m_pSyntax->SetPos(last_pos);
			return;
		}
	}
}

// static
ByteStringView CSGPDF_SDK_StreamContentParser::FindKeyAbbreviationForTesting(
	ByteStringView abbr)
{
	return FindFullName(kInlineKeyAbbr, pdfium::size(kInlineKeyAbbr), abbr);
}

// static
ByteStringView CSGPDF_SDK_StreamContentParser::FindValueAbbreviationForTesting(
	ByteStringView abbr)
{
	return FindFullName(kInlineValueAbbr, pdfium::size(kInlineValueAbbr), abbr);
}

CSGPDF_SDK_StreamContentParser::ContentParam::ContentParam() = default;

CSGPDF_SDK_StreamContentParser::ContentParam::~ContentParam() = default;
