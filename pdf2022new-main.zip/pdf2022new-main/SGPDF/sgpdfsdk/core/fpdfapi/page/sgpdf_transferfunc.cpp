// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_transferfunc.h"

#include <utility>

#include "core/fpdfapi/page/sgpdf_transferfuncdib.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fxge/dib/cfx_dibbase.h"
#include "third_party/base/check.h"

CSGPDF_SDK_TransferFunc::CSGPDF_SDK_TransferFunc(
	CSGPDF_SDK_Document* pDoc,
	bool bIdentify,
	std::vector<uint8_t, FxAllocAllocator<uint8_t>> samples_r,
	std::vector<uint8_t, FxAllocAllocator<uint8_t>> samples_g,
	std::vector<uint8_t, FxAllocAllocator<uint8_t>> samples_b)
	: m_pPDFDoc(pDoc),
	m_bIdentity(bIdentify),
	m_SamplesR(std::move(samples_r)),
	m_SamplesG(std::move(samples_g)),
	m_SamplesB(std::move(samples_b))
{
	DCHECK(m_SamplesR.size() == kChannelSampleSize);
	DCHECK(m_SamplesG.size() == kChannelSampleSize);
	DCHECK(m_SamplesB.size() == kChannelSampleSize);
}

CSGPDF_SDK_TransferFunc::~CSGPDF_SDK_TransferFunc() = default;

FX_COLORREF CSGPDF_SDK_TransferFunc::TranslateColor(FX_COLORREF colorref) const
{
	return FXSYS_BGR(m_SamplesB[FXSYS_GetBValue(colorref)],
		m_SamplesG[FXSYS_GetGValue(colorref)],
		m_SamplesR[FXSYS_GetRValue(colorref)]);
}

RetainPtr<CFX_DIBBase> CSGPDF_SDK_TransferFunc::TranslateImage(
	const RetainPtr<CFX_DIBBase>& pSrc)
{
	RetainPtr<CSGPDF_SDK_TransferFunc> pHolder(this);
	return pdfium::MakeRetain<CSGPDF_SDK_TransferFuncDIB>(pSrc, pHolder);
}

pdfium::span<const uint8_t> CSGPDF_SDK_TransferFunc::GetSamplesR() const
{
	return m_SamplesR;
}

pdfium::span<const uint8_t> CSGPDF_SDK_TransferFunc::GetSamplesG() const
{
	return m_SamplesG;
}

pdfium::span<const uint8_t> CSGPDF_SDK_TransferFunc::GetSamplesB() const
{
	return m_SamplesB;
}
