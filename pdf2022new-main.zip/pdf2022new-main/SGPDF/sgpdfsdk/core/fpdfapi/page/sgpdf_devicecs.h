// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_DEVICECS_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_DEVICECS_H_

#include <set>

#include "core/fpdfapi/page/sgpdf_colorspace.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_DeviceCS final : public CSGPDF_SDK_ColorSpace {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;
  ~CSGPDF_SDK_DeviceCS() override;

  // CSGPDF_SDK_ColorSpace:
  bool GetRGB(pdfium::span<const float> pBuf,
              float* R,
              float* G,
              float* B) const override;
  void TranslateImageLine(uint8_t* pDestBuf,
                          const uint8_t* pSrcBuf,
                          int pixels,
                          int image_width,
                          int image_height,
                          bool bTransMask) const override;
  uint32_t v_Load(CSGPDF_SDK_Document* pDoc,
                  const CSGPDF_SDK_Array* pArray,
                  std::set<const CSGPDF_SDK_Object*>* pVisited) override;

 private:
  explicit CSGPDF_SDK_DeviceCS(int family);
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_DEVICECS_H_
