// Copyright 2020 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/page/sgpdf_function.h"

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_number.h"
#include "core/fxcrt/retain_ptr.h"
#include "testing/gtest/include/gtest/gtest.h"

TEST(CPDFFunction, BadFunctionType) {
  auto pDict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  pDict->SetNewFor<CSGPDF_SDK_Number>("FunctionType", -2);
  EXPECT_EQ(nullptr, CSGPDF_SDK_Function::Load(pDict.Get()));

  pDict->SetNewFor<CSGPDF_SDK_Number>("FunctionType", 5);
  EXPECT_EQ(nullptr, CSGPDF_SDK_Function::Load(pDict.Get()));
}

TEST(CPDFFunction, NoDomain) {
  auto pDict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  pDict->SetNewFor<CSGPDF_SDK_Number>("FunctionType", 0);
  EXPECT_EQ(nullptr, CSGPDF_SDK_Function::Load(pDict.Get()));
}

TEST(CPDFFunction, EmptyDomain) {
  auto pDict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  pDict->SetNewFor<CSGPDF_SDK_Number>("FunctionType", 0);
  pDict->SetNewFor<CSGPDF_SDK_Array>("Domain");
  EXPECT_EQ(nullptr, CSGPDF_SDK_Function::Load(pDict.Get()));
}

TEST(CPDFFunction, NoRange) {
  auto pDict = pdfium::MakeRetain<CSGPDF_SDK_Dictionary>();
  pDict->SetNewFor<CSGPDF_SDK_Number>("FunctionType", 0);

  CSGPDF_SDK_Array* pArray = pDict->SetNewFor<CSGPDF_SDK_Array>("Domain");
  pArray->AppendNew<CSGPDF_SDK_Number>(0);
  pArray->AppendNew<CSGPDF_SDK_Number>(10);
  EXPECT_EQ(nullptr, CSGPDF_SDK_Function::Load(pDict.Get()));
}
