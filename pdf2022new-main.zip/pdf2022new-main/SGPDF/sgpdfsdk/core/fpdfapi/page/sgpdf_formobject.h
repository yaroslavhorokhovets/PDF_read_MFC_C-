// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_FORMOBJECT_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_FORMOBJECT_H_

#include <memory>

#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fxcrt/fx_coordinates.h"

class CSGPDF_SDK_Form;

class CSGPDF_SDK_FormObject final : public CSGPDF_SDK_PageObject {
 public:
  CSGPDF_SDK_FormObject(int32_t content_stream,
                  std::unique_ptr<CSGPDF_SDK_Form> pForm,
                  const CFX_Matrix& matrix);
  ~CSGPDF_SDK_FormObject() override;

  // CSGPDF_SDK_PageObject:
  Type GetType() const override;
  void Transform(const CFX_Matrix& matrix) override;
  bool IsForm() const override;
  CSGPDF_SDK_FormObject* AsForm() override;
  const CSGPDF_SDK_FormObject* AsForm() const override;

  void CalcBoundingBox();
  const CSGPDF_SDK_Form* form() const { return m_pForm.get(); }
  const CFX_Matrix& form_matrix() const { return m_FormMatrix; }

 private:
  std::unique_ptr<CSGPDF_SDK_Form> const m_pForm;
  CFX_Matrix m_FormMatrix;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_FORMOBJECT_H_
