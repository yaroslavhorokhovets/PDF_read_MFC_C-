// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_textstate.h"

#include "core/fpdfapi/font/sgpdf_font.h"
#include "core/fpdfapi/page/sgpdf_docpagedata.h"

CSGPDF_SDK_TextState::CSGPDF_SDK_TextState() = default;

CSGPDF_SDK_TextState::~CSGPDF_SDK_TextState() = default;

void CSGPDF_SDK_TextState::Emplace()
{
	m_Ref.Emplace();
}

RetainPtr<CSGPDF_SDK_Font> CSGPDF_SDK_TextState::GetFont() const
{
	return m_Ref.GetObject()->m_pFont;
}

void CSGPDF_SDK_TextState::SetFont(const RetainPtr<CSGPDF_SDK_Font>& pFont)
{
	m_Ref.GetPrivateCopy()->SetFont(pFont);
}

float CSGPDF_SDK_TextState::GetFontSize() const
{
	return m_Ref.GetObject()->m_FontSize;
}

void CSGPDF_SDK_TextState::SetFontSize(float size)
{
	m_Ref.GetPrivateCopy()->m_FontSize = size;
}

const float* CSGPDF_SDK_TextState::GetMatrix() const
{
	return m_Ref.GetObject()->m_Matrix;
}

float* CSGPDF_SDK_TextState::GetMutableMatrix()
{
	return m_Ref.GetPrivateCopy()->m_Matrix;
}

float CSGPDF_SDK_TextState::GetCharSpace() const
{
	return m_Ref.GetObject()->m_CharSpace;
}

void CSGPDF_SDK_TextState::SetCharSpace(float sp)
{
	m_Ref.GetPrivateCopy()->m_CharSpace = sp;
}

float CSGPDF_SDK_TextState::GetWordSpace() const
{
	return m_Ref.GetObject()->m_WordSpace;
}

void CSGPDF_SDK_TextState::SetWordSpace(float sp)
{
	m_Ref.GetPrivateCopy()->m_WordSpace = sp;
}

float CSGPDF_SDK_TextState::GetFontSizeH() const
{
	return m_Ref.GetObject()->GetFontSizeH();
}

TextRenderingMode CSGPDF_SDK_TextState::GetTextMode() const
{
	return m_Ref.GetObject()->m_TextMode;
}

void CSGPDF_SDK_TextState::SetTextMode(TextRenderingMode mode)
{
	m_Ref.GetPrivateCopy()->m_TextMode = mode;
}

const float* CSGPDF_SDK_TextState::GetCTM() const
{
	return m_Ref.GetObject()->m_CTM;
}

float* CSGPDF_SDK_TextState::GetMutableCTM()
{
	return m_Ref.GetPrivateCopy()->m_CTM;
}

CSGPDF_SDK_TextState::TextData::TextData() = default;

CSGPDF_SDK_TextState::TextData::TextData(const TextData& that)
	: m_pFont(that.m_pFont),
	m_pDocument(that.m_pDocument),
	m_FontSize(that.m_FontSize),
	m_CharSpace(that.m_CharSpace),
	m_WordSpace(that.m_WordSpace),
	m_TextMode(that.m_TextMode)
{
	for (int i = 0; i < 4; ++i)
		m_Matrix[i] = that.m_Matrix[i];

	for (int i = 0; i < 4; ++i)
		m_CTM[i] = that.m_CTM[i];

	if (m_pDocument && m_pFont)
	{
		auto* pPageData = CSGPDF_SDK_DocPageData::FromDocument(m_pDocument.Get());
		m_pFont = pPageData->GetFont(m_pFont->GetFontDict());
	}
}

CSGPDF_SDK_TextState::TextData::~TextData() = default;

RetainPtr<CSGPDF_SDK_TextState::TextData> CSGPDF_SDK_TextState::TextData::Clone() const
{
	return pdfium::MakeRetain<CSGPDF_SDK_TextState::TextData>(*this);
}

void CSGPDF_SDK_TextState::TextData::SetFont(const RetainPtr<CSGPDF_SDK_Font>& pFont)
{
	m_pDocument = pFont ? pFont->GetDocument() : nullptr;
	m_pFont = pFont;
}

float CSGPDF_SDK_TextState::TextData::GetFontSizeH() const
{
	return fabs(FXSYS_sqrt2(m_Matrix[0], m_Matrix[2]) * m_FontSize);
}

bool SetTextRenderingModeFromInt(int iMode, TextRenderingMode* mode)
{
	if (iMode < 0 || iMode > 7)
		return false;
	*mode = static_cast<TextRenderingMode>(iMode);
	return true;
}

bool TextRenderingModeIsClipMode(const TextRenderingMode& mode)
{
	switch (mode)
	{
		case TextRenderingMode::MODE_FILL_CLIP:
		case TextRenderingMode::MODE_STROKE_CLIP:
		case TextRenderingMode::MODE_FILL_STROKE_CLIP:
		case TextRenderingMode::MODE_CLIP:
			return true;
		default:
			return false;
	}
}

bool TextRenderingModeIsStrokeMode(const TextRenderingMode& mode)
{
	switch (mode)
	{
		case TextRenderingMode::MODE_STROKE:
		case TextRenderingMode::MODE_FILL_STROKE:
		case TextRenderingMode::MODE_STROKE_CLIP:
		case TextRenderingMode::MODE_FILL_STROKE_CLIP:
			return true;
		default:
			return false;
	}
}
