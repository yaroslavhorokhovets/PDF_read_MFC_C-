// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_pageobject.h"

CSGPDF_SDK_PageObject::CSGPDF_SDK_PageObject(int32_t content_stream)
	: m_ContentStream(content_stream)
{
}

CSGPDF_SDK_PageObject::~CSGPDF_SDK_PageObject() = default;

bool CSGPDF_SDK_PageObject::IsText() const
{
	return false;
}

bool CSGPDF_SDK_PageObject::IsPath() const
{
	return false;
}

bool CSGPDF_SDK_PageObject::IsImage() const
{
	return false;
}

bool CSGPDF_SDK_PageObject::IsShading() const
{
	return false;
}

bool CSGPDF_SDK_PageObject::IsForm() const
{
	return false;
}

CSGPDF_SDK_TextObject* CSGPDF_SDK_PageObject::AsText()
{
	return nullptr;
}

const CSGPDF_SDK_TextObject* CSGPDF_SDK_PageObject::AsText() const
{
	return nullptr;
}

CSGPDF_SDK_PathObject* CSGPDF_SDK_PageObject::AsPath()
{
	return nullptr;
}

const CSGPDF_SDK_PathObject* CSGPDF_SDK_PageObject::AsPath() const
{
	return nullptr;
}

CSGPDF_SDK_ImageObject* CSGPDF_SDK_PageObject::AsImage()
{
	return nullptr;
}

const CSGPDF_SDK_ImageObject* CSGPDF_SDK_PageObject::AsImage() const
{
	return nullptr;
}

CSGPDF_SDK_ShadingObject* CSGPDF_SDK_PageObject::AsShading()
{
	return nullptr;
}

const CSGPDF_SDK_ShadingObject* CSGPDF_SDK_PageObject::AsShading() const
{
	return nullptr;
}

CSGPDF_SDK_FormObject* CSGPDF_SDK_PageObject::AsForm()
{
	return nullptr;
}

const CSGPDF_SDK_FormObject* CSGPDF_SDK_PageObject::AsForm() const
{
	return nullptr;
}

void CSGPDF_SDK_PageObject::CopyData(const CSGPDF_SDK_PageObject* pSrc)
{
	CopyStates(*pSrc);
	m_Rect = pSrc->m_Rect;
	m_bDirty = true;
}

void CSGPDF_SDK_PageObject::TransformClipPath(const CFX_Matrix& matrix)
{
	if (!m_ClipPath.HasRef())
		return;
	m_ClipPath.Transform(matrix);
	SetDirty(true);
}

void CSGPDF_SDK_PageObject::TransformGeneralState(const CFX_Matrix& matrix)
{
	if (!m_GeneralState.HasRef())
		return;
	m_GeneralState.GetMutableMatrix()->Concat(matrix);
	SetDirty(true);
}

FX_RECT CSGPDF_SDK_PageObject::GetBBox() const
{
	return GetRect().GetOuterRect();
}

FX_RECT CSGPDF_SDK_PageObject::GetTransformedBBox(const CFX_Matrix& matrix) const
{
	return matrix.TransformRect(GetRect()).GetOuterRect();
}
