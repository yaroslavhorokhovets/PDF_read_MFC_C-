// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_DOCPAGEDATA_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_DOCPAGEDATA_H_

#include <map>
#include <memory>
#include <set>

#include "core/fpdfapi/font/sgpdf_font.h"
#include "core/fpdfapi/page/sgpdf_colorspace.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/observed_ptr.h"
#include "core/fxcrt/retain_ptr.h"

class CFX_Font;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_FontEncoding;
class CSGPDF_SDK_IccProfile;
class CSGPDF_SDK_Image;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_Pattern;
class CSGPDF_SDK_Stream;
class CSGPDF_SDK_StreamAcc;

class CSGPDF_SDK_DocPageData : public CSGPDF_SDK_Document::PageDataIface,
                         public CSGPDF_SDK_Font::FormFactoryIface {
 public:
  static CSGPDF_SDK_DocPageData* FromDocument(const CSGPDF_SDK_Document* pDoc);

  CSGPDF_SDK_DocPageData();
  ~CSGPDF_SDK_DocPageData() override;

  // CSGPDF_SDK_Document::PageDataIface:
  void ClearStockFont() override;
  RetainPtr<CSGPDF_SDK_StreamAcc> GetFontFileStreamAcc(
      const CSGPDF_SDK_Stream* pFontStream) override;
  void MaybePurgeFontFileStreamAcc(const CSGPDF_SDK_Stream* pFontStream) override;

  // CSGPDF_SDK_Font::FormFactoryIFace:
  std::unique_ptr<CSGPDF_SDK_Font::FormIface> CreateForm(
      CSGPDF_SDK_Document* pDocument,
      CSGPDF_SDK_Dictionary* pPageResources,
      CSGPDF_SDK_Stream* pFormStream) override;

  bool IsForceClear() const { return m_bForceClear; }

  RetainPtr<CSGPDF_SDK_Font> AddFont(std::unique_ptr<CFX_Font> pFont, int charset);
  RetainPtr<CSGPDF_SDK_Font> GetFont(CSGPDF_SDK_Dictionary* pFontDict);
  RetainPtr<CSGPDF_SDK_Font> AddStandardFont(const ByteString& fontName,
                                       const CSGPDF_SDK_FontEncoding* pEncoding);
  RetainPtr<CSGPDF_SDK_Font> GetStandardFont(const ByteString& fontName,
                                       const CSGPDF_SDK_FontEncoding* pEncoding);
#if defined(OS_WIN)
  RetainPtr<CSGPDF_SDK_Font> AddWindowsFont(LOGFONTA* pLogFont);
#endif

  // Loads a colorspace.
  RetainPtr<CSGPDF_SDK_ColorSpace> GetColorSpace(const CSGPDF_SDK_Object* pCSObj,
                                           const CSGPDF_SDK_Dictionary* pResources);

  // Loads a colorspace in a context that might be while loading another
  // colorspace. |pVisited| is passed recursively to avoid circular calls
  // involving CSGPDF_SDK_ColorSpace::Load().
  RetainPtr<CSGPDF_SDK_ColorSpace> GetColorSpaceGuarded(
      const CSGPDF_SDK_Object* pCSObj,
      const CSGPDF_SDK_Dictionary* pResources,
      std::set<const CSGPDF_SDK_Object*>* pVisited);

  RetainPtr<CSGPDF_SDK_Pattern> GetPattern(CSGPDF_SDK_Object* pPatternObj,
                                     bool bShading,
                                     const CFX_Matrix& matrix);

  RetainPtr<CSGPDF_SDK_Image> GetImage(uint32_t dwStreamObjNum);
  void MaybePurgeImage(uint32_t dwStreamObjNum);

  RetainPtr<CSGPDF_SDK_IccProfile> GetIccProfile(const CSGPDF_SDK_Stream* pProfileStream);

 private:
  // Loads a colorspace in a context that might be while loading another
  // colorspace, or even in a recursive call from this method itself. |pVisited|
  // is passed recursively to avoid circular calls involving
  // CSGPDF_SDK_ColorSpace::Load() and |pVisitedInternal| is also passed recursively
  // to avoid circular calls with this method calling itself.
  RetainPtr<CSGPDF_SDK_ColorSpace> GetColorSpaceInternal(
      const CSGPDF_SDK_Object* pCSObj,
      const CSGPDF_SDK_Dictionary* pResources,
      std::set<const CSGPDF_SDK_Object*>* pVisited,
      std::set<const CSGPDF_SDK_Object*>* pVisitedInternal);

  size_t CalculateEncodingDict(int charset, CSGPDF_SDK_Dictionary* pBaseDict);
  CSGPDF_SDK_Dictionary* ProcessbCJK(
      CSGPDF_SDK_Dictionary* pBaseDict,
      int charset,
      ByteString basefont,
      std::function<void(wchar_t, wchar_t, CSGPDF_SDK_Array*)> Insert);
  void Clear(bool bForceRelease);

  bool m_bForceClear = false;

  // Specific destruction order may be required between maps.
  std::map<ByteString, RetainPtr<const CSGPDF_SDK_Stream>> m_HashProfileMap;
  std::map<const CSGPDF_SDK_Object*, ObservedPtr<CSGPDF_SDK_ColorSpace>> m_ColorSpaceMap;
  std::map<const CSGPDF_SDK_Stream*, RetainPtr<CSGPDF_SDK_StreamAcc>> m_FontFileMap;
  std::map<const CSGPDF_SDK_Stream*, ObservedPtr<CSGPDF_SDK_IccProfile>> m_IccProfileMap;
  std::map<const CSGPDF_SDK_Object*, ObservedPtr<CSGPDF_SDK_Pattern>> m_PatternMap;
  std::map<uint32_t, RetainPtr<CSGPDF_SDK_Image>> m_ImageMap;
  std::map<const CSGPDF_SDK_Dictionary*, ObservedPtr<CSGPDF_SDK_Font>> m_FontMap;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_DOCPAGEDATA_H_
