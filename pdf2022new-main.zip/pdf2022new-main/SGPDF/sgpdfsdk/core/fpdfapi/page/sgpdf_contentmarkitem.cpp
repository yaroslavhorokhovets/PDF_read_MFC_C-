// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_contentmarkitem.h"

#include <utility>

#include "core/fpdfapi/parser/sgpdf_dictionary.h"

CSGPDF_SDK_ContentMarkItem::CSGPDF_SDK_ContentMarkItem(ByteString name)
	: m_MarkName(std::move(name))
{
}

CSGPDF_SDK_ContentMarkItem::~CSGPDF_SDK_ContentMarkItem() = default;

const CSGPDF_SDK_Dictionary* CSGPDF_SDK_ContentMarkItem::GetParam() const
{
	switch (m_ParamType)
	{
		case kPropertiesDict:
			return m_pPropertiesHolder->GetDictFor(m_PropertyName);
		case kDirectDict:
			return m_pDirectDict.Get();
		case kNone:
		default:
			return nullptr;
	}
}

CSGPDF_SDK_Dictionary* CSGPDF_SDK_ContentMarkItem::GetParam()
{
	return const_cast<CSGPDF_SDK_Dictionary*>(
		static_cast<const CSGPDF_SDK_ContentMarkItem*>(this)->GetParam());
}

bool CSGPDF_SDK_ContentMarkItem::HasMCID() const
{
	const CSGPDF_SDK_Dictionary* pDict = GetParam();
	return pDict && pDict->KeyExist("MCID");
}

void CSGPDF_SDK_ContentMarkItem::SetDirectDict(RetainPtr<CSGPDF_SDK_Dictionary> pDict)
{
	m_ParamType = kDirectDict;
	m_pDirectDict = std::move(pDict);
}

void CSGPDF_SDK_ContentMarkItem::SetPropertiesHolder(
	CSGPDF_SDK_Dictionary* pHolder,
	const ByteString& property_name)
{
	m_ParamType = kPropertiesDict;
	m_pPropertiesHolder.Reset(pHolder);
	m_PropertyName = property_name;
}
