// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_TILINGPATTERN_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_TILINGPATTERN_H_

#include <memory>

#include "core/fpdfapi/page/sgpdf_pattern.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_Document;
class CSGPDF_SDK_Form;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_PageObject;

class CSGPDF_SDK_TilingPattern final : public CSGPDF_SDK_Pattern {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;
  ~CSGPDF_SDK_TilingPattern() override;

  // CSGPDF_SDK_Pattern:
  CSGPDF_SDK_TilingPattern* AsTilingPattern() override;

  std::unique_ptr<CSGPDF_SDK_Form> Load(CSGPDF_SDK_PageObject* pPageObj);

  bool colored() const { return m_bColored; }
  const CFX_FloatRect& bbox() const { return m_BBox; }
  float x_step() const { return m_XStep; }
  float y_step() const { return m_YStep; }

 private:
  CSGPDF_SDK_TilingPattern(CSGPDF_SDK_Document* pDoc,
                     CSGPDF_SDK_Object* pPatternObj,
                     const CFX_Matrix& parentMatrix);
  CSGPDF_SDK_TilingPattern(const CSGPDF_SDK_TilingPattern&) = delete;
  CSGPDF_SDK_TilingPattern& operator=(const CSGPDF_SDK_TilingPattern&) = delete;

  bool m_bColored;
  CFX_FloatRect m_BBox;
  float m_XStep;
  float m_YStep;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_TILINGPATTERN_H_
