// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_iccprofile.h"

#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fxcodec/icc/iccmodule.h"

namespace
{

	bool DetectSRGB(pdfium::span<const uint8_t> span)
	{
		static const char kSRGB[] = "sRGB IEC61966-2.1";
		return span.size() == 3144 && memcmp(&span[400], kSRGB, strlen(kSRGB)) == 0;
	}

}  // namespace

CSGPDF_SDK_IccProfile::CSGPDF_SDK_IccProfile(const CSGPDF_SDK_Stream* pStream,
	pdfium::span<const uint8_t> span)
	: m_bsRGB(DetectSRGB(span)), m_pStream(pStream)
{
	if (m_bsRGB)
	{
		m_nSrcComponents = 3;
		return;
	}

	m_Transform = IccModule::CreateTransformSRGB(span);
	if (m_Transform)
		m_nSrcComponents = m_Transform->components();
}

CSGPDF_SDK_IccProfile::~CSGPDF_SDK_IccProfile() = default;
