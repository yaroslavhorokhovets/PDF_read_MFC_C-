// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_IMAGEOBJECT_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_IMAGEOBJECT_H_

#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/retain_ptr.h"

class CFX_DIBitmap;
class CSGPDF_SDK_Image;

class CSGPDF_SDK_ImageObject final : public CSGPDF_SDK_PageObject {
 public:
  explicit CSGPDF_SDK_ImageObject(int32_t content_stream);
  CSGPDF_SDK_ImageObject();
  ~CSGPDF_SDK_ImageObject() override;

  // CSGPDF_SDK_PageObject
  Type GetType() const override;
  void Transform(const CFX_Matrix& matrix) override;
  bool IsImage() const override;
  CSGPDF_SDK_ImageObject* AsImage() override;
  const CSGPDF_SDK_ImageObject* AsImage() const override;

  void CalcBoundingBox();
  void SetImage(const RetainPtr<CSGPDF_SDK_Image>& pImage);
  RetainPtr<CSGPDF_SDK_Image> GetImage() const;
  RetainPtr<CFX_DIBitmap> GetIndependentBitmap() const;

  void set_matrix(const CFX_Matrix& matrix) { m_Matrix = matrix; }
  const CFX_Matrix& matrix() const { return m_Matrix; }

 private:
  void MaybePurgeCache();

  CFX_Matrix m_Matrix;
  RetainPtr<CSGPDF_SDK_Image> m_pImage;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_IMAGEOBJECT_H_
