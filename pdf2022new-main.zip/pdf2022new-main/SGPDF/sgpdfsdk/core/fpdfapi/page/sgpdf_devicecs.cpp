// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_devicecs.h"

#include <algorithm>

#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "core/fpdfapi/parser/sgpdf_stream_acc.h"
#include "core/fpdfapi/parser/sgpdf_string.h"
#include "core/fxcodec/fx_codec.h"
#include "core/fxge/dib/cfx_cmyk_to_srgb.h"
#include "third_party/base/check.h"
#include "third_party/base/notreached.h"
#include "third_party/base/stl_util.h"

namespace
{

	float NormalizeChannel(float fVal)
	{
		return pdfium::clamp(fVal, 0.0f, 1.0f);
	}

}  // namespace

CSGPDF_SDK_DeviceCS::CSGPDF_SDK_DeviceCS(int family) : CSGPDF_SDK_ColorSpace(nullptr, family)
{
	DCHECK(family == PDFCS_DEVICEGRAY || family == PDFCS_DEVICERGB ||
		family == PDFCS_DEVICECMYK);
	SetComponentsForStockCS(ComponentsForFamily(GetFamily()));
}

CSGPDF_SDK_DeviceCS::~CSGPDF_SDK_DeviceCS() = default;

uint32_t CSGPDF_SDK_DeviceCS::v_Load(CSGPDF_SDK_Document* pDoc,
	const CSGPDF_SDK_Array* pArray,
	std::set<const CSGPDF_SDK_Object*>* pVisited)
{
	// Unlike other classes that inherit from CSGPDF_SDK_ColorSpace, CSGPDF_SDK_DeviceCS is
	// never loaded by CSGPDF_SDK_ColorSpace.
	NOTREACHED();
	return 0;
}

bool CSGPDF_SDK_DeviceCS::GetRGB(pdfium::span<const float> pBuf,
	float* R,
	float* G,
	float* B) const
{
	switch (m_Family)
	{
		case PDFCS_DEVICEGRAY:
			*R = NormalizeChannel(pBuf[0]);
			*G = *R;
			*B = *R;
			return true;
		case PDFCS_DEVICERGB:
			*R = NormalizeChannel(pBuf[0]);
			*G = NormalizeChannel(pBuf[1]);
			*B = NormalizeChannel(pBuf[2]);
			return true;
		case PDFCS_DEVICECMYK:
			if (m_dwStdConversion)
			{
				float k = pBuf[3];
				*R = 1.0f - std::min(1.0f, pBuf[0] + k);
				*G = 1.0f - std::min(1.0f, pBuf[1] + k);
				*B = 1.0f - std::min(1.0f, pBuf[2] + k);
			}
			else
			{
				std::tie(*R, *G, *B) = AdobeCMYK_to_sRGB(
					NormalizeChannel(pBuf[0]), NormalizeChannel(pBuf[1]),
					NormalizeChannel(pBuf[2]), NormalizeChannel(pBuf[3]));
			}
			return true;
		default:
			NOTREACHED();
			return false;
	}
}

void CSGPDF_SDK_DeviceCS::TranslateImageLine(uint8_t* pDestBuf,
	const uint8_t* pSrcBuf,
	int pixels,
	int image_width,
	int image_height,
	bool bTransMask) const
{
	switch (m_Family)
	{
		case PDFCS_DEVICEGRAY:
			for (int i = 0; i < pixels; i++)
			{
				*pDestBuf++ = pSrcBuf[i];
				*pDestBuf++ = pSrcBuf[i];
				*pDestBuf++ = pSrcBuf[i];
			}
			break;
		case PDFCS_DEVICERGB:
			fxcodec::ReverseRGB(pDestBuf, pSrcBuf, pixels);
			break;
		case PDFCS_DEVICECMYK:
			if (bTransMask)
			{
				for (int i = 0; i < pixels; i++)
				{
					int k = 255 - pSrcBuf[3];
					pDestBuf[0] = ((255 - pSrcBuf[0]) * k) / 255;
					pDestBuf[1] = ((255 - pSrcBuf[1]) * k) / 255;
					pDestBuf[2] = ((255 - pSrcBuf[2]) * k) / 255;
					pDestBuf += 3;
					pSrcBuf += 4;
				}
			}
			else
			{
				for (int i = 0; i < pixels; i++)
				{
					if (m_dwStdConversion)
					{
						uint8_t k = pSrcBuf[3];
						pDestBuf[2] = 255 - std::min(255, pSrcBuf[0] + k);
						pDestBuf[1] = 255 - std::min(255, pSrcBuf[1] + k);
						pDestBuf[0] = 255 - std::min(255, pSrcBuf[2] + k);
					}
					else
					{
						std::tie(pDestBuf[2], pDestBuf[1], pDestBuf[0]) =
							AdobeCMYK_to_sRGB1(pSrcBuf[0], pSrcBuf[1], pSrcBuf[2],
								pSrcBuf[3]);
					}
					pSrcBuf += 4;
					pDestBuf += 3;
				}
			}
			break;
		default:
			NOTREACHED();
			break;
	}
}
