// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_PAGEOBJECT_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_PAGEOBJECT_H_

#include "core/fpdfapi/page/sgpdf_contentmarks.h"
#include "core/fpdfapi/page/sgpdf_graphicstates.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_FormObject;
class CSGPDF_SDK_ImageObject;
class CSGPDF_SDK_PathObject;
class CSGPDF_SDK_ShadingObject;
class CSGPDF_SDK_TextObject;

class CSGPDF_SDK_PageObject : public CSGPDF_SDK_GraphicStates {
 public:
  enum Type {
    TEXT = 1,
    PATH,
    IMAGE,
    SHADING,
    FORM,
  };

  static constexpr int32_t kNoContentStream = -1;

  explicit CSGPDF_SDK_PageObject(int32_t content_stream);
  CSGPDF_SDK_PageObject(const CSGPDF_SDK_PageObject& src) = delete;
  CSGPDF_SDK_PageObject& operator=(const CSGPDF_SDK_PageObject& src) = delete;
  ~CSGPDF_SDK_PageObject() override;

  virtual Type GetType() const = 0;
  virtual void Transform(const CFX_Matrix& matrix) = 0;
  virtual bool IsText() const;
  virtual bool IsPath() const;
  virtual bool IsImage() const;
  virtual bool IsShading() const;
  virtual bool IsForm() const;
  virtual CSGPDF_SDK_TextObject* AsText();
  virtual const CSGPDF_SDK_TextObject* AsText() const;
  virtual CSGPDF_SDK_PathObject* AsPath();
  virtual const CSGPDF_SDK_PathObject* AsPath() const;
  virtual CSGPDF_SDK_ImageObject* AsImage();
  virtual const CSGPDF_SDK_ImageObject* AsImage() const;
  virtual CSGPDF_SDK_ShadingObject* AsShading();
  virtual const CSGPDF_SDK_ShadingObject* AsShading() const;
  virtual CSGPDF_SDK_FormObject* AsForm();
  virtual const CSGPDF_SDK_FormObject* AsForm() const;

  void SetDirty(bool value) { m_bDirty = value; }
  bool IsDirty() const { return m_bDirty; }
  void TransformClipPath(const CFX_Matrix& matrix);
  void TransformGeneralState(const CFX_Matrix& matrix);

  void SetRect(const CFX_FloatRect& rect) { m_Rect = rect; }
  const CFX_FloatRect& GetRect() const { return m_Rect; }
  FX_RECT GetBBox() const;
  FX_RECT GetTransformedBBox(const CFX_Matrix& matrix) const;

  // Get what content stream the object was parsed from in its page. This number
  // is the index of the content stream in the "Contents" array, or 0 if there
  // is a single content stream. If the object is newly created,
  // |kNoContentStream| is returned.
  //
  // If the object is spread among more than one content stream, this is the
  // index of the last stream.
  int32_t GetContentStream() const { return m_ContentStream; }
  void SetContentStream(int32_t new_content_stream) {
    m_ContentStream = new_content_stream;
  }

  CSGPDF_SDK_ContentMarks m_ContentMarks;

 protected:
  void CopyData(const CSGPDF_SDK_PageObject* pSrcObject);

  CFX_FloatRect m_Rect;

 private:
  bool m_bDirty = false;
  int32_t m_ContentStream;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_PAGEOBJECT_H_
