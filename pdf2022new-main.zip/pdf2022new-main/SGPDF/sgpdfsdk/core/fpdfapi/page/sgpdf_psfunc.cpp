// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_psfunc.h"

#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/sgpdf_stream_acc.h"

CSGPDF_SDK_PSFunc::CSGPDF_SDK_PSFunc() : CSGPDF_SDK_Function(Type::kType4PostScript)
{
}

CSGPDF_SDK_PSFunc::~CSGPDF_SDK_PSFunc() = default;

bool CSGPDF_SDK_PSFunc::v_Init(const CSGPDF_SDK_Object* pObj,
	std::set<const CSGPDF_SDK_Object*>* pVisited)
{
	auto pAcc = pdfium::MakeRetain<CSGPDF_SDK_StreamAcc>(pObj->AsStream());
	pAcc->LoadAllDataFiltered();
	return m_PS.Parse(pAcc->GetSpan());
}

bool CSGPDF_SDK_PSFunc::v_Call(const float* inputs, float* results) const
{
	m_PS.Reset();
	for (uint32_t i = 0; i < m_nInputs; i++)
		m_PS.Push(inputs[i]);
	m_PS.Execute();
	if (m_PS.GetStackSize() < m_nOutputs)
		return false;
	for (uint32_t i = 0; i < m_nOutputs; i++)
		results[m_nOutputs - i - 1] = m_PS.Pop();
	return true;
}
