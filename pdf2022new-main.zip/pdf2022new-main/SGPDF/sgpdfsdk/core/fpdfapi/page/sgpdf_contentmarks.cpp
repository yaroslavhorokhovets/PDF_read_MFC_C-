// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_contentmarks.h"

#include <algorithm>
#include <utility>

#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "third_party/base/check.h"

CSGPDF_SDK_ContentMarks::CSGPDF_SDK_ContentMarks() = default;

CSGPDF_SDK_ContentMarks::~CSGPDF_SDK_ContentMarks() = default;

std::unique_ptr<CSGPDF_SDK_ContentMarks> CSGPDF_SDK_ContentMarks::Clone()
{
	auto result = std::make_unique<CSGPDF_SDK_ContentMarks>();
	if (m_pMarkData)
		result->m_pMarkData = pdfium::MakeRetain<MarkData>(*m_pMarkData);
	return result;
}

size_t CSGPDF_SDK_ContentMarks::CountItems() const
{
	return m_pMarkData ? m_pMarkData->CountItems() : 0;
}

bool CSGPDF_SDK_ContentMarks::ContainsItem(const CSGPDF_SDK_ContentMarkItem* pItem) const
{
	return m_pMarkData && m_pMarkData->ContainsItem(pItem);
}

CSGPDF_SDK_ContentMarkItem* CSGPDF_SDK_ContentMarks::GetItem(size_t index)
{
	return const_cast<CSGPDF_SDK_ContentMarkItem*>(
		static_cast<const CSGPDF_SDK_ContentMarks*>(this)->GetItem(index));
}

const CSGPDF_SDK_ContentMarkItem* CSGPDF_SDK_ContentMarks::GetItem(size_t index) const
{
	DCHECK(index < CountItems());
	return m_pMarkData->GetItem(index);
}

int CSGPDF_SDK_ContentMarks::GetMarkedContentID() const
{
	return m_pMarkData ? m_pMarkData->GetMarkedContentID() : -1;
}

void CSGPDF_SDK_ContentMarks::AddMark(ByteString name)
{
	EnsureMarkDataExists();
	m_pMarkData->AddMark(std::move(name));
}

void CSGPDF_SDK_ContentMarks::AddMarkWithDirectDict(ByteString name,
	CSGPDF_SDK_Dictionary* pDict)
{
	EnsureMarkDataExists();
	m_pMarkData->AddMarkWithDirectDict(std::move(name), pDict);
}

void CSGPDF_SDK_ContentMarks::AddMarkWithPropertiesHolder(
	const ByteString& name,
	CSGPDF_SDK_Dictionary* pDict,
	const ByteString& property_name)
{
	EnsureMarkDataExists();
	m_pMarkData->AddMarkWithPropertiesHolder(name, pDict, property_name);
}

bool CSGPDF_SDK_ContentMarks::RemoveMark(CSGPDF_SDK_ContentMarkItem* pMarkItem)
{
	return m_pMarkData && m_pMarkData->RemoveMark(pMarkItem);
}

void CSGPDF_SDK_ContentMarks::EnsureMarkDataExists()
{
	if (!m_pMarkData)
		m_pMarkData = pdfium::MakeRetain<MarkData>();
}

void CSGPDF_SDK_ContentMarks::DeleteLastMark()
{
	if (!m_pMarkData)
		return;

	m_pMarkData->DeleteLastMark();
	if (CountItems() == 0)
		m_pMarkData.Reset();
}

size_t CSGPDF_SDK_ContentMarks::FindFirstDifference(
	const CSGPDF_SDK_ContentMarks* other) const
{
	if (m_pMarkData == other->m_pMarkData)
		return CountItems();

	size_t min_len = std::min(CountItems(), other->CountItems());

	for (size_t i = 0; i < min_len; ++i)
	{
		if (GetItem(i) != other->GetItem(i))
			return i;
	}
	return min_len;
}

CSGPDF_SDK_ContentMarks::MarkData::MarkData() = default;

CSGPDF_SDK_ContentMarks::MarkData::MarkData(const MarkData& src)
	: m_Marks(src.m_Marks)
{
}

CSGPDF_SDK_ContentMarks::MarkData::~MarkData() = default;

size_t CSGPDF_SDK_ContentMarks::MarkData::CountItems() const
{
	return m_Marks.size();
}

bool CSGPDF_SDK_ContentMarks::MarkData::ContainsItem(
	const CSGPDF_SDK_ContentMarkItem* pItem) const
{
	for (const auto& pMark : m_Marks)
	{
		if (pMark == pItem)
			return true;
	}
	return false;
}

CSGPDF_SDK_ContentMarkItem* CSGPDF_SDK_ContentMarks::MarkData::GetItem(size_t index)
{
	return m_Marks[index].Get();
}

const CSGPDF_SDK_ContentMarkItem* CSGPDF_SDK_ContentMarks::MarkData::GetItem(
	size_t index) const
{
	return m_Marks[index].Get();
}

int CSGPDF_SDK_ContentMarks::MarkData::GetMarkedContentID() const
{
	for (const auto& pMark : m_Marks)
	{
		const CSGPDF_SDK_Dictionary* pDict = pMark->GetParam();
		if (pDict && pDict->KeyExist("MCID"))
			return pDict->GetIntegerFor("MCID");
	}
	return -1;
}

void CSGPDF_SDK_ContentMarks::MarkData::AddMark(ByteString name)
{
	auto pItem = pdfium::MakeRetain<CSGPDF_SDK_ContentMarkItem>(std::move(name));
	m_Marks.push_back(pItem);
}

void CSGPDF_SDK_ContentMarks::MarkData::AddMarkWithDirectDict(
	ByteString name,
	CSGPDF_SDK_Dictionary* pDict)
{
	auto pItem = pdfium::MakeRetain<CSGPDF_SDK_ContentMarkItem>(std::move(name));
	pItem->SetDirectDict(ToDictionary(pDict->Clone()));
	m_Marks.push_back(pItem);
}

void CSGPDF_SDK_ContentMarks::MarkData::AddMarkWithPropertiesHolder(
	const ByteString& name,
	CSGPDF_SDK_Dictionary* pDict,
	const ByteString& property_name)
{
	auto pItem = pdfium::MakeRetain<CSGPDF_SDK_ContentMarkItem>(name);
	pItem->SetPropertiesHolder(pDict, property_name);
	m_Marks.push_back(pItem);
}

bool CSGPDF_SDK_ContentMarks::MarkData::RemoveMark(CSGPDF_SDK_ContentMarkItem* pMarkItem)
{
	for (auto it = m_Marks.begin(); it != m_Marks.end(); ++it)
	{
		if (*it == pMarkItem)
		{
			m_Marks.erase(it);
			return true;
		}
	}
	return false;
}

void CSGPDF_SDK_ContentMarks::MarkData::DeleteLastMark()
{
	if (!m_Marks.empty())
		m_Marks.pop_back();
}
