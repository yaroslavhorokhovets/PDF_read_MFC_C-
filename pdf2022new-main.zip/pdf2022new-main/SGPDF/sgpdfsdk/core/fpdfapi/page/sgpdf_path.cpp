// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_path.h"

CSGPDF_SDK_Path::CSGPDF_SDK_Path() = default;

CSGPDF_SDK_Path::CSGPDF_SDK_Path(const CSGPDF_SDK_Path& that) : m_Ref(that.m_Ref)
{
}

CSGPDF_SDK_Path::~CSGPDF_SDK_Path() = default;

const std::vector<FX_PATHPOINT>& CSGPDF_SDK_Path::GetPoints() const
{
	return m_Ref.GetObject()->GetPoints();
}

void CSGPDF_SDK_Path::ClosePath()
{
	m_Ref.GetPrivateCopy()->ClosePath();
}

CFX_PointF CSGPDF_SDK_Path::GetPoint(int index) const
{
	return m_Ref.GetObject()->GetPoint(index);
}

CFX_FloatRect CSGPDF_SDK_Path::GetBoundingBox() const
{
	return m_Ref.GetObject()->GetBoundingBox();
}

CFX_FloatRect CSGPDF_SDK_Path::GetBoundingBox(float line_width,
	float miter_limit) const
{
	return m_Ref.GetObject()->GetBoundingBox(line_width, miter_limit);
}

bool CSGPDF_SDK_Path::IsRect() const
{
	return m_Ref.GetObject()->IsRect();
}

void CSGPDF_SDK_Path::Transform(const CFX_Matrix& matrix)
{
	m_Ref.GetPrivateCopy()->Transform(matrix);
}

void CSGPDF_SDK_Path::Append(const CFX_PathData* pData, const CFX_Matrix* pMatrix)
{
	m_Ref.GetPrivateCopy()->Append(pData, pMatrix);
}

void CSGPDF_SDK_Path::AppendFloatRect(const CFX_FloatRect& rect)
{
	m_Ref.GetPrivateCopy()->AppendFloatRect(rect);
}

void CSGPDF_SDK_Path::AppendRect(float left, float bottom, float right, float top)
{
	m_Ref.GetPrivateCopy()->AppendRect(left, bottom, right, top);
}

void CSGPDF_SDK_Path::AppendPoint(const CFX_PointF& point, FXPT_TYPE type)
{
	CFX_PathData data;
	data.AppendPoint(point, type);
	Append(&data, nullptr);
}

void CSGPDF_SDK_Path::AppendPointAndClose(const CFX_PointF& point, FXPT_TYPE type)
{
	CFX_PathData data;
	data.AppendPointAndClose(point, type);
	Append(&data, nullptr);
}
