// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_STITCHFUNC_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_STITCHFUNC_H_

#include <memory>
#include <set>
#include <vector>

#include "core/fpdfapi/page/sgpdf_function.h"

class CSGPDF_SDK_StitchFunc final : public CSGPDF_SDK_Function {
 public:
  CSGPDF_SDK_StitchFunc();
  ~CSGPDF_SDK_StitchFunc() override;

  // CSGPDF_SDK_Function
  bool v_Init(const CSGPDF_SDK_Object* pObj,
              std::set<const CSGPDF_SDK_Object*>* pVisited) override;
  bool v_Call(const float* inputs, float* results) const override;

  const std::vector<std::unique_ptr<CSGPDF_SDK_Function>>& GetSubFunctions() const {
    return m_pSubFunctions;
  }
  float GetBound(size_t i) const { return m_bounds[i]; }
  float GetEncode(size_t i) const { return m_encode[i]; }

 private:
  std::vector<std::unique_ptr<CSGPDF_SDK_Function>> m_pSubFunctions;
  std::vector<float> m_bounds;
  std::vector<float> m_encode;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_STITCHFUNC_H_
