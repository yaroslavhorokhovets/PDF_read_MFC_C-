// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_pattern.h"

#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "third_party/base/check.h"

CSGPDF_SDK_Pattern::CSGPDF_SDK_Pattern(CSGPDF_SDK_Document* pDoc,
	CSGPDF_SDK_Object* pObj,
	const CFX_Matrix& parentMatrix)
	: m_pDocument(pDoc), m_pPatternObj(pObj), m_ParentMatrix(parentMatrix)
{
	DCHECK(m_pDocument);
	DCHECK(m_pPatternObj);
}

CSGPDF_SDK_Pattern::~CSGPDF_SDK_Pattern() = default;

CSGPDF_SDK_TilingPattern* CSGPDF_SDK_Pattern::AsTilingPattern()
{
	return nullptr;
}

CSGPDF_SDK_ShadingPattern* CSGPDF_SDK_Pattern::AsShadingPattern()
{
	return nullptr;
}

void CSGPDF_SDK_Pattern::SetPatternToFormMatrix()
{
	const CSGPDF_SDK_Dictionary* pDict = pattern_obj()->GetDict();
	m_Pattern2Form = pDict->GetMatrixFor("Matrix") * m_ParentMatrix;
}
