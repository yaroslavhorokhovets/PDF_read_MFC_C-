// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_ALLSTATES_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_ALLSTATES_H_

#include "core/fpdfapi/page/sgpdf_graphicstates.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_system.h"

class CSGPDF_SDK_Array;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_StreamContentParser;

class CSGPDF_SDK_AllStates final : public CSGPDF_SDK_GraphicStates {
 public:
  CSGPDF_SDK_AllStates();
  ~CSGPDF_SDK_AllStates() override;

  void Copy(const CSGPDF_SDK_AllStates& src);
  void ProcessExtGS(CSGPDF_SDK_Dictionary* pGS, CSGPDF_SDK_StreamContentParser* pParser);
  void SetLineDash(const CSGPDF_SDK_Array* pArray, float phase, float scale);

  CFX_Matrix m_TextMatrix;
  CFX_Matrix m_CTM;
  CFX_Matrix m_ParentMatrix;
  CFX_PointF m_TextPos;
  CFX_PointF m_TextLinePos;
  float m_TextLeading = 0.0f;
  float m_TextRise = 0.0f;
  float m_TextHorzScale = 1.0f;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_ALLSTATES_H_
