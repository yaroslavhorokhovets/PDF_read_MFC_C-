// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/page/sgpdf_transparency.h"

CSGPDF_SDK_Transparency::CSGPDF_SDK_Transparency() = default;

CSGPDF_SDK_Transparency::CSGPDF_SDK_Transparency(const CSGPDF_SDK_Transparency& other) = default;
