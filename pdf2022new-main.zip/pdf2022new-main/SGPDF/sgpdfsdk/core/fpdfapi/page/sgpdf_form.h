// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_FORM_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_FORM_H_

#include <memory>
#include <set>
#include <utility>

#include "core/fpdfapi/font/sgpdf_font.h"
#include "core/fpdfapi/page/sgpdf_pageobjectholder.h"

class CFX_Matrix;
class CSGPDF_SDK_AllStates;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_ImageObject;
class CSGPDF_SDK_Stream;
class CSGPDF_SDK_Type3Char;

class CSGPDF_SDK_Form final : public CSGPDF_SDK_PageObjectHolder,
                        public CSGPDF_SDK_Font::FormIface {
 public:
  // Helper method to choose the first non-null resources dictionary.
  static CSGPDF_SDK_Dictionary* ChooseResourcesDict(CSGPDF_SDK_Dictionary* pResources,
                                              CSGPDF_SDK_Dictionary* pParentResources,
                                              CSGPDF_SDK_Dictionary* pPageResources);

  CSGPDF_SDK_Form(CSGPDF_SDK_Document* pDocument,
            CSGPDF_SDK_Dictionary* pPageResources,
            CSGPDF_SDK_Stream* pFormStream);
  CSGPDF_SDK_Form(CSGPDF_SDK_Document* pDocument,
            CSGPDF_SDK_Dictionary* pPageResources,
            CSGPDF_SDK_Stream* pFormStream,
            CSGPDF_SDK_Dictionary* pParentResources);
  ~CSGPDF_SDK_Form() override;

  // CSGPDF_SDK_Font::FormIface:
  void ParseContentForType3Char(CSGPDF_SDK_Type3Char* pType3Char) override;
  bool HasPageObjects() const override;
  CFX_FloatRect CalcBoundingBox() const override;
  Optional<std::pair<RetainPtr<CFX_DIBitmap>, CFX_Matrix>>
  GetBitmapAndMatrixFromSoleImageOfForm() const override;

  void ParseContent();
  void ParseContent(const CSGPDF_SDK_AllStates* pGraphicStates,
                    const CFX_Matrix* pParentMatrix,
                    std::set<const uint8_t*>* pParsedSet);

  const CSGPDF_SDK_Stream* GetStream() const;

 private:
  void ParseContentInternal(const CSGPDF_SDK_AllStates* pGraphicStates,
                            const CFX_Matrix* pParentMatrix,
                            CSGPDF_SDK_Type3Char* pType3Char,
                            std::set<const uint8_t*>* pParsedSet);

  std::unique_ptr<std::set<const uint8_t*>> m_ParsedSet;
  RetainPtr<CSGPDF_SDK_Stream> const m_pFormStream;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_FORM_H_
