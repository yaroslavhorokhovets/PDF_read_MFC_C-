// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_COLOR_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_COLOR_H_

#include <memory>
#include <vector>

#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_ColorSpace;
class CSGPDF_SDK_Pattern;
class PatternValue;

class CSGPDF_SDK_Color {
 public:
  CSGPDF_SDK_Color();
  CSGPDF_SDK_Color(const CSGPDF_SDK_Color& that);

  ~CSGPDF_SDK_Color();

  CSGPDF_SDK_Color& operator=(const CSGPDF_SDK_Color& that);

  bool IsNull() const { return m_Buffer.empty() && !m_pValue; }
  bool IsPattern() const;
  void SetColorSpace(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS);
  void SetValueForNonPattern(const std::vector<float>& values);
  void SetValueForPattern(const RetainPtr<CSGPDF_SDK_Pattern>& pPattern,
                          const std::vector<float>& values);
  uint32_t CountComponents() const;
  bool IsColorSpaceRGB() const;
  bool GetRGB(int* R, int* G, int* B) const;

  // Should only be called if IsPattern() returns true.
  CSGPDF_SDK_Pattern* GetPattern() const;

 protected:
  bool IsPatternInternal() const;

  std::vector<float> m_Buffer;             // Used for non-pattern colorspaces.
  std::unique_ptr<PatternValue> m_pValue;  // Used for pattern colorspaces.
  RetainPtr<CSGPDF_SDK_ColorSpace> m_pCS;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_COLOR_H_
