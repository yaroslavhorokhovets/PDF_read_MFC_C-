// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_CONTENTMARKITEM_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_CONTENTMARKITEM_H_

#include "core/fxcrt/fx_string.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_Dictionary;

class CSGPDF_SDK_ContentMarkItem final : public Retainable {
 public:
  enum ParamType { kNone, kPropertiesDict, kDirectDict };

  explicit CSGPDF_SDK_ContentMarkItem(ByteString name);
  ~CSGPDF_SDK_ContentMarkItem() override;

  const ByteString& GetName() const { return m_MarkName; }
  ParamType GetParamType() const { return m_ParamType; }
  const CSGPDF_SDK_Dictionary* GetParam() const;
  CSGPDF_SDK_Dictionary* GetParam();
  const ByteString& GetPropertyName() const { return m_PropertyName; }
  bool HasMCID() const;

  void SetDirectDict(RetainPtr<CSGPDF_SDK_Dictionary> pDict);
  void SetPropertiesHolder(CSGPDF_SDK_Dictionary* pHolder,
                           const ByteString& property_name);

 private:
  ParamType m_ParamType = kNone;
  ByteString m_MarkName;
  ByteString m_PropertyName;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pPropertiesHolder;
  RetainPtr<CSGPDF_SDK_Dictionary> m_pDirectDict;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_CONTENTMARKITEM_H_
