// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_PAGEMODULE_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_PAGEMODULE_H_

#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_Document;
class CSGPDF_SDK_ColorSpace;
class CSGPDF_SDK_DeviceCS;
class CSGPDF_SDK_PatternCS;

class CSGPDF_SDK_PageModule {
 public:
  // Per-process singleton managed by callers.
  static void Create();
  static void Destroy();
  static CSGPDF_SDK_PageModule* GetInstance();

  RetainPtr<CSGPDF_SDK_ColorSpace> GetStockCS(int family);
  void ClearStockFont(CSGPDF_SDK_Document* pDoc);

 private:
  CSGPDF_SDK_PageModule();
  ~CSGPDF_SDK_PageModule();

  RetainPtr<CSGPDF_SDK_DeviceCS> m_StockGrayCS;
  RetainPtr<CSGPDF_SDK_DeviceCS> m_StockRGBCS;
  RetainPtr<CSGPDF_SDK_DeviceCS> m_StockCMYKCS;
  RetainPtr<CSGPDF_SDK_PatternCS> m_StockPatternCS;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_PAGEMODULE_H_
