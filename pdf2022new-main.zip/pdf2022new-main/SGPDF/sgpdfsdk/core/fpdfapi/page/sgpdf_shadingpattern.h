// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_SHADINGPATTERN_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_SHADINGPATTERN_H_

#include <memory>
#include <vector>

#include "core/fpdfapi/page/sgpdf_colorspace.h"
#include "core/fpdfapi/page/sgpdf_pattern.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"

// Values used in PDFs except for |kInvalidShading| and |kMaxShading|.
// Do not change.
enum ShadingType {
  kInvalidShading = 0,
  kFunctionBasedShading = 1,
  kAxialShading = 2,
  kRadialShading = 3,
  kFreeFormGouraudTriangleMeshShading = 4,
  kLatticeFormGouraudTriangleMeshShading = 5,
  kCoonsPatchMeshShading = 6,
  kTensorProductPatchMeshShading = 7,
  kMaxShading = 8
};

class CFX_Matrix;
class CSGPDF_SDK_ColorSpace;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_Function;
class CSGPDF_SDK_Object;

class CSGPDF_SDK_ShadingPattern final : public CSGPDF_SDK_Pattern {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;
  ~CSGPDF_SDK_ShadingPattern() override;

  // CSGPDF_SDK_Pattern:
  CSGPDF_SDK_ShadingPattern* AsShadingPattern() override;

  bool IsMeshShading() const {
    return m_ShadingType == kFreeFormGouraudTriangleMeshShading ||
           m_ShadingType == kLatticeFormGouraudTriangleMeshShading ||
           m_ShadingType == kCoonsPatchMeshShading ||
           m_ShadingType == kTensorProductPatchMeshShading;
  }
  bool Load();

  ShadingType GetShadingType() const { return m_ShadingType; }
  bool IsShadingObject() const { return m_bShading; }
  const CSGPDF_SDK_Object* GetShadingObject() const;
  RetainPtr<CSGPDF_SDK_ColorSpace> GetCS() const { return m_pCS; }
  const std::vector<std::unique_ptr<CSGPDF_SDK_Function>>& GetFuncs() const {
    return m_pFunctions;
  }

 private:
  CSGPDF_SDK_ShadingPattern(CSGPDF_SDK_Document* pDoc,
                      CSGPDF_SDK_Object* pPatternObj,
                      bool bShading,
                      const CFX_Matrix& parentMatrix);
  CSGPDF_SDK_ShadingPattern(const CSGPDF_SDK_ShadingPattern&) = delete;
  CSGPDF_SDK_ShadingPattern& operator=(const CSGPDF_SDK_ShadingPattern&) = delete;

  // Constraints in PDF 1.7 spec, 4.6.3 Shading Patterns, pages 308-331.
  bool Validate() const;
  bool ValidateFunctions(uint32_t nExpectedNumFunctions,
                         uint32_t nExpectedNumInputs,
                         uint32_t nExpectedNumOutputs) const;

  ShadingType m_ShadingType = kInvalidShading;
  const bool m_bShading;
  RetainPtr<CSGPDF_SDK_ColorSpace> m_pCS;
  std::vector<std::unique_ptr<CSGPDF_SDK_Function>> m_pFunctions;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_SHADINGPATTERN_H_
