// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_tilingpattern.h"

#include "core/fpdfapi/page/sgpdf_allstates.h"
#include "core/fpdfapi/page/sgpdf_form.h"
#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_object.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "third_party/base/check.h"

CSGPDF_SDK_TilingPattern::CSGPDF_SDK_TilingPattern(CSGPDF_SDK_Document* pDoc,
	CSGPDF_SDK_Object* pPatternObj,
	const CFX_Matrix& parentMatrix)
	: CSGPDF_SDK_Pattern(pDoc, pPatternObj, parentMatrix)
{
	DCHECK(document());
	m_bColored = pattern_obj()->GetDict()->GetIntegerFor("PaintType") == 1;
	SetPatternToFormMatrix();
}

CSGPDF_SDK_TilingPattern::~CSGPDF_SDK_TilingPattern() = default;

CSGPDF_SDK_TilingPattern* CSGPDF_SDK_TilingPattern::AsTilingPattern()
{
	return this;
}

std::unique_ptr<CSGPDF_SDK_Form> CSGPDF_SDK_TilingPattern::Load(CSGPDF_SDK_PageObject* pPageObj)
{
	const CSGPDF_SDK_Dictionary* pDict = pattern_obj()->GetDict();
	m_bColored = pDict->GetIntegerFor("PaintType") == 1;
	m_XStep = static_cast<float>(fabs(pDict->GetNumberFor("XStep")));
	m_YStep = static_cast<float>(fabs(pDict->GetNumberFor("YStep")));

	CSGPDF_SDK_Stream* pStream = pattern_obj()->AsStream();
	if (!pStream)
		return nullptr;

	const CFX_Matrix& matrix = parent_matrix();
	auto form = std::make_unique<CSGPDF_SDK_Form>(document(), nullptr, pStream);

	CSGPDF_SDK_AllStates allStates;
	allStates.m_ColorState.Emplace();
	allStates.m_GraphState.Emplace();
	allStates.m_TextState.Emplace();
	allStates.m_GeneralState = pPageObj->m_GeneralState;
	form->ParseContent(&allStates, &matrix, nullptr);
	m_BBox = pDict->GetRectFor("BBox");
	return form;
}
