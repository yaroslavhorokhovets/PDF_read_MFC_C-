// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_PATTERN_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_PATTERN_H_

#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/observed_ptr.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Document;
class CSGPDF_SDK_Object;
class CSGPDF_SDK_ShadingPattern;
class CSGPDF_SDK_TilingPattern;

class CSGPDF_SDK_Pattern : public Retainable, public Observable {
 public:
  // Values used in PDFs. Do not change.
  enum PatternType { kTiling = 1, kShading = 2 };

  ~CSGPDF_SDK_Pattern() override;

  virtual CSGPDF_SDK_TilingPattern* AsTilingPattern();
  virtual CSGPDF_SDK_ShadingPattern* AsShadingPattern();

  // All the getters that return pointers return non-NULL pointers.
  CSGPDF_SDK_Document* document() const { return m_pDocument.Get(); }
  CSGPDF_SDK_Object* pattern_obj() const { return m_pPatternObj.Get(); }
  const CFX_Matrix& pattern_to_form() const { return m_Pattern2Form; }
  const CFX_Matrix& parent_matrix() const { return m_ParentMatrix; }

 protected:
  CSGPDF_SDK_Pattern(CSGPDF_SDK_Document* pDoc,
               CSGPDF_SDK_Object* pObj,
               const CFX_Matrix& parentMatrix);

  void SetPatternToFormMatrix();

 private:
  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  RetainPtr<CSGPDF_SDK_Object> const m_pPatternObj;
  CFX_Matrix m_Pattern2Form;
  const CFX_Matrix m_ParentMatrix;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_PATTERN_H_
