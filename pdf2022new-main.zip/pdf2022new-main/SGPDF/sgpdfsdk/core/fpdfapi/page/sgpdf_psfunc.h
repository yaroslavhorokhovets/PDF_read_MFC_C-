// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_PSFUNC_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_PSFUNC_H_

#include <set>

#include "core/fpdfapi/page/sgpdf_function.h"
#include "core/fpdfapi/page/sgpdf_psengine.h"

class CSGPDF_SDK_Object;

class CSGPDF_SDK_PSFunc final : public CSGPDF_SDK_Function {
 public:
  CSGPDF_SDK_PSFunc();
  ~CSGPDF_SDK_PSFunc() override;

  // CSGPDF_SDK_Function
  bool v_Init(const CSGPDF_SDK_Object* pObj,
              std::set<const CSGPDF_SDK_Object*>* pVisited) override;
  bool v_Call(const float* inputs, float* results) const override;

 private:
  mutable CSGPDF_SDK_PSEngine m_PS;  // Pre-initialized scratch space for v_Call().
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_PSFUNC_H_
