// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_COLORSTATE_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_COLORSTATE_H_

#include <vector>

#include "core/fpdfapi/page/sgpdf_color.h"
#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/shared_copy_on_write.h"
#include "core/fxge/dib/fx_dib.h"

class CSGPDF_SDK_Color;
class CSGPDF_SDK_ColorSpace;
class CSGPDF_SDK_Pattern;

class CSGPDF_SDK_ColorState {
 public:
  CSGPDF_SDK_ColorState();
  CSGPDF_SDK_ColorState(const CSGPDF_SDK_ColorState& that);
  ~CSGPDF_SDK_ColorState();

  void Emplace();
  void SetDefault();

  FX_COLORREF GetFillColorRef() const;
  void SetFillColorRef(FX_COLORREF colorref);

  FX_COLORREF GetStrokeColorRef() const;
  void SetStrokeColorRef(FX_COLORREF colorref);

  const CSGPDF_SDK_Color* GetFillColor() const;
  CSGPDF_SDK_Color* GetMutableFillColor();
  bool HasFillColor() const;

  const CSGPDF_SDK_Color* GetStrokeColor() const;
  CSGPDF_SDK_Color* GetMutableStrokeColor();
  bool HasStrokeColor() const;

  void SetFillColor(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS,
                    const std::vector<float>& values);
  void SetStrokeColor(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS,
                      const std::vector<float>& values);
  void SetFillPattern(const RetainPtr<CSGPDF_SDK_Pattern>& pattern,
                      const std::vector<float>& values);
  void SetStrokePattern(const RetainPtr<CSGPDF_SDK_Pattern>& pattern,
                        const std::vector<float>& values);

  bool HasRef() const { return !!m_Ref; }

 private:
  class ColorData final : public Retainable {
   public:
    CONSTRUCT_VIA_MAKE_RETAIN;

    RetainPtr<ColorData> Clone() const;

    void SetDefault();

    FX_COLORREF m_FillColorRef = 0;
    FX_COLORREF m_StrokeColorRef = 0;
    CSGPDF_SDK_Color m_FillColor;
    CSGPDF_SDK_Color m_StrokeColor;

   private:
    ColorData();
    ColorData(const ColorData& src);
    ~ColorData() override;
  };

  void SetColor(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS,
                const std::vector<float>& values,
                CSGPDF_SDK_Color* color,
                FX_COLORREF* colorref);
  void SetPattern(const RetainPtr<CSGPDF_SDK_Pattern>& pPattern,
                  const std::vector<float>& values,
                  CSGPDF_SDK_Color* color,
                  FX_COLORREF* colorref);

  SharedCopyOnWrite<ColorData> m_Ref;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_COLORSTATE_H_
