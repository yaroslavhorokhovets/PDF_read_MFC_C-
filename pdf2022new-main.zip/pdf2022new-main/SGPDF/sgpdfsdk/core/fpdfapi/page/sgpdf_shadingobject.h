// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_SHADINGOBJECT_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_SHADINGOBJECT_H_

#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/retain_ptr.h"

class CSGPDF_SDK_ShadingPattern;

class CSGPDF_SDK_ShadingObject final : public CSGPDF_SDK_PageObject {
 public:
  CSGPDF_SDK_ShadingObject(int32_t content_stream,
                     CSGPDF_SDK_ShadingPattern* pattern,
                     const CFX_Matrix& matrix);
  ~CSGPDF_SDK_ShadingObject() override;

  // CSGPDF_SDK_PageObject:
  Type GetType() const override;
  void Transform(const CFX_Matrix& matrix) override;
  bool IsShading() const override;
  CSGPDF_SDK_ShadingObject* AsShading() override;
  const CSGPDF_SDK_ShadingObject* AsShading() const override;

  void CalcBoundingBox();

  const CSGPDF_SDK_ShadingPattern* pattern() const { return m_pShading.Get(); }
  const CFX_Matrix& matrix() const { return m_Matrix; }

 private:
  RetainPtr<CSGPDF_SDK_ShadingPattern> m_pShading;
  CFX_Matrix m_Matrix;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_SHADINGOBJECT_H_
