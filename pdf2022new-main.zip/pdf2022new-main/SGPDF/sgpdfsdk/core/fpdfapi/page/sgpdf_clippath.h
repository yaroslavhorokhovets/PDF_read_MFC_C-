// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_CLIPPATH_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_CLIPPATH_H_

#include <memory>
#include <utility>
#include <vector>

#include "core/fpdfapi/page/sgpdf_path.h"
#include "core/fxcrt/fx_coordinates.h"
#include "core/fxcrt/shared_copy_on_write.h"
#include "core/fxge/cfx_fillrenderoptions.h"

class CSGPDF_SDK_TextObject;

class CSGPDF_SDK_ClipPath {
 public:
  CSGPDF_SDK_ClipPath();
  CSGPDF_SDK_ClipPath(const CSGPDF_SDK_ClipPath& that);
  CSGPDF_SDK_ClipPath& operator=(const CSGPDF_SDK_ClipPath& that);
  ~CSGPDF_SDK_ClipPath();

  void Emplace() { m_Ref.Emplace(); }
  void SetNull() { m_Ref.SetNull(); }

  bool HasRef() const { return !!m_Ref; }
  bool operator==(const CSGPDF_SDK_ClipPath& that) const {
    return m_Ref == that.m_Ref;
  }
  bool operator!=(const CSGPDF_SDK_ClipPath& that) const { return !(*this == that); }

  size_t GetPathCount() const;
  CSGPDF_SDK_Path GetPath(size_t i) const;
  CFX_FillRenderOptions::FillType GetClipType(size_t i) const;
  size_t GetTextCount() const;
  CSGPDF_SDK_TextObject* GetText(size_t i) const;
  CFX_FloatRect GetClipBox() const;
  void AppendPath(CSGPDF_SDK_Path path,
                  CFX_FillRenderOptions::FillType type,
                  bool bAutoMerge);
  void AppendTexts(std::vector<std::unique_ptr<CSGPDF_SDK_TextObject>>* pTexts);
  void CopyClipPath(const CSGPDF_SDK_ClipPath& that);
  void Transform(const CFX_Matrix& matrix);

 private:
  class PathData final : public Retainable {
   public:
    CONSTRUCT_VIA_MAKE_RETAIN;

    RetainPtr<PathData> Clone() const;

    using PathAndTypeData =
        std::pair<CSGPDF_SDK_Path, CFX_FillRenderOptions::FillType>;

    std::vector<PathAndTypeData> m_PathAndTypeList;
    std::vector<std::unique_ptr<CSGPDF_SDK_TextObject>> m_TextList;

   private:
    PathData();
    PathData(const PathData& that);
    ~PathData() override;
  };

  SharedCopyOnWrite<PathData> m_Ref;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_CLIPPATH_H_
