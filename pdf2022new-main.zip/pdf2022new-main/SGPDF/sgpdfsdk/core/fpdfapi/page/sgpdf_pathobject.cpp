// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_pathobject.h"

CSGPDF_SDK_PathObject::CSGPDF_SDK_PathObject(int32_t content_stream)
	: CSGPDF_SDK_PageObject(content_stream)
{
}

CSGPDF_SDK_PathObject::CSGPDF_SDK_PathObject() : CSGPDF_SDK_PathObject(kNoContentStream)
{
}

CSGPDF_SDK_PathObject::~CSGPDF_SDK_PathObject() = default;

CSGPDF_SDK_PageObject::Type CSGPDF_SDK_PathObject::GetType() const
{
	return PATH;
}

void CSGPDF_SDK_PathObject::Transform(const CFX_Matrix& matrix)
{
	m_Matrix.Concat(matrix);
	CalcBoundingBox();
	SetDirty(true);
}

bool CSGPDF_SDK_PathObject::IsPath() const
{
	return true;
}

CSGPDF_SDK_PathObject* CSGPDF_SDK_PathObject::AsPath()
{
	return this;
}

const CSGPDF_SDK_PathObject* CSGPDF_SDK_PathObject::AsPath() const
{
	return this;
}

void CSGPDF_SDK_PathObject::CalcBoundingBox()
{
	if (!m_Path.HasRef())
		return;
	CFX_FloatRect rect;
	float width = m_GraphState.GetLineWidth();
	if (m_bStroke && width != 0)
	{
		rect = m_Path.GetBoundingBox(width, m_GraphState.GetMiterLimit());
	}
	else
	{
		rect = m_Path.GetBoundingBox();
	}
	rect = m_Matrix.TransformRect(rect);

	if (width == 0 && m_bStroke)
		rect.Inflate(0.5f, 0.5f);
	SetRect(rect);
}
