// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "core/fpdfapi/page/sgpdf_streamcontentparser.h"
#include "testing/gtest/include/gtest/gtest.h"

TEST(cpdf_streamcontentparser, PDF_FindKeyAbbreviation) {
  EXPECT_EQ(ByteStringView("BitsPerComponent"),
            CSGPDF_SDK_StreamContentParser::FindKeyAbbreviationForTesting(
                ByteStringView("BPC")));
  EXPECT_EQ(ByteStringView("Width"),
            CSGPDF_SDK_StreamContentParser::FindKeyAbbreviationForTesting(
                ByteStringView("W")));
  EXPECT_EQ(ByteStringView(""),
            CSGPDF_SDK_StreamContentParser::FindKeyAbbreviationForTesting(
                ByteStringView("")));
  EXPECT_EQ(ByteStringView(""),
            CSGPDF_SDK_StreamContentParser::FindKeyAbbreviationForTesting(
                ByteStringView("NoInList")));
  // Prefix should not match.
  EXPECT_EQ(ByteStringView(""),
            CSGPDF_SDK_StreamContentParser::FindKeyAbbreviationForTesting(
                ByteStringView("WW")));
}

TEST(cpdf_streamcontentparser, PDF_FindValueAbbreviation) {
  EXPECT_EQ(ByteStringView("DeviceGray"),
            CSGPDF_SDK_StreamContentParser::FindValueAbbreviationForTesting(
                ByteStringView("G")));
  EXPECT_EQ(ByteStringView("DCTDecode"),
            CSGPDF_SDK_StreamContentParser::FindValueAbbreviationForTesting(
                ByteStringView("DCT")));
  EXPECT_EQ(ByteStringView(""),
            CSGPDF_SDK_StreamContentParser::FindValueAbbreviationForTesting(
                ByteStringView("")));
  EXPECT_EQ(ByteStringView(""),
            CSGPDF_SDK_StreamContentParser::FindValueAbbreviationForTesting(
                ByteStringView("NoInList")));
  // Prefix should not match.
  EXPECT_EQ(ByteStringView(""),
            CSGPDF_SDK_StreamContentParser::FindValueAbbreviationForTesting(
                ByteStringView("II")));
}
