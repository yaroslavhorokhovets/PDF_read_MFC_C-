// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_patterncs.h"

#include "core/fpdfapi/page/sgpdf_docpagedata.h"
#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_document.h"
#include "third_party/base/notreached.h"

CSGPDF_SDK_PatternCS::CSGPDF_SDK_PatternCS(CSGPDF_SDK_Document* pDoc)
	: CSGPDF_SDK_ColorSpace(pDoc, PDFCS_PATTERN)
{
}

CSGPDF_SDK_PatternCS::~CSGPDF_SDK_PatternCS() = default;

void CSGPDF_SDK_PatternCS::InitializeStockPattern()
{
	SetComponentsForStockCS(1);
}

uint32_t CSGPDF_SDK_PatternCS::v_Load(CSGPDF_SDK_Document* pDoc,
	const CSGPDF_SDK_Array* pArray,
	std::set<const CSGPDF_SDK_Object*>* pVisited)
{
	const CSGPDF_SDK_Object* pBaseCS = pArray->GetDirectObjectAt(1);
	if (pBaseCS == m_pArray)
		return 0;

	auto* pDocPageData = CSGPDF_SDK_DocPageData::FromDocument(pDoc);
	m_pBaseCS = pDocPageData->GetColorSpaceGuarded(pBaseCS, nullptr, pVisited);
	if (!m_pBaseCS)
		return 1;

	if (m_pBaseCS->GetFamily() == PDFCS_PATTERN)
		return 0;

	if (m_pBaseCS->CountComponents() > kMaxPatternColorComps)
		return 0;

	return m_pBaseCS->CountComponents() + 1;
}

bool CSGPDF_SDK_PatternCS::GetRGB(pdfium::span<const float> pBuf,
	float* R,
	float* G,
	float* B) const
{
	NOTREACHED();
	return false;
}

CSGPDF_SDK_PatternCS* CSGPDF_SDK_PatternCS::AsPatternCS()
{
	return this;
}

const CSGPDF_SDK_PatternCS* CSGPDF_SDK_PatternCS::AsPatternCS() const
{
	return this;
}

bool CSGPDF_SDK_PatternCS::GetPatternRGB(const PatternValue& value,
	float* R,
	float* G,
	float* B) const
{
	if (m_pBaseCS && m_pBaseCS->GetRGB(value.GetComps(), R, G, B))
		return true;

	*R = 0.75f;
	*G = 0.75f;
	*B = 0.75f;
	return false;
}
