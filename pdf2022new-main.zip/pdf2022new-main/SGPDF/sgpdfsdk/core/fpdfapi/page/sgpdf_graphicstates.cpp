// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_graphicstates.h"

CSGPDF_SDK_GraphicStates::CSGPDF_SDK_GraphicStates() = default;

CSGPDF_SDK_GraphicStates::~CSGPDF_SDK_GraphicStates() = default;

void CSGPDF_SDK_GraphicStates::DefaultStates()
{
	m_ColorState.Emplace();
	m_ColorState.SetDefault();
}

void CSGPDF_SDK_GraphicStates::CopyStates(const CSGPDF_SDK_GraphicStates& src)
{
	m_ClipPath = src.m_ClipPath;
	m_GraphState = src.m_GraphState;
	m_ColorState = src.m_ColorState;
	m_TextState = src.m_TextState;
	m_GeneralState = src.m_GeneralState;
}
