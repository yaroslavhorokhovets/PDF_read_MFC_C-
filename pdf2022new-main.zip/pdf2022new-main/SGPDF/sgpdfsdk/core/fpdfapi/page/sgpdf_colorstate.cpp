// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_colorstate.h"

#include "core/fpdfapi/page/sgpdf_colorspace.h"
#include "core/fpdfapi/page/sgpdf_pattern.h"
#include "core/fpdfapi/page/sgpdf_tilingpattern.h"
#include "core/fxge/dib/fx_dib.h"
#include "third_party/base/check.h"

CSGPDF_SDK_ColorState::CSGPDF_SDK_ColorState() = default;

CSGPDF_SDK_ColorState::CSGPDF_SDK_ColorState(const CSGPDF_SDK_ColorState& that)
	: m_Ref(that.m_Ref)
{
}

CSGPDF_SDK_ColorState::~CSGPDF_SDK_ColorState() = default;

void CSGPDF_SDK_ColorState::Emplace()
{
	m_Ref.Emplace();
}

void CSGPDF_SDK_ColorState::SetDefault()
{
	m_Ref.GetPrivateCopy()->SetDefault();
}

FX_COLORREF CSGPDF_SDK_ColorState::GetFillColorRef() const
{
	return m_Ref.GetObject()->m_FillColorRef;
}

void CSGPDF_SDK_ColorState::SetFillColorRef(FX_COLORREF colorref)
{
	m_Ref.GetPrivateCopy()->m_FillColorRef = colorref;
}

FX_COLORREF CSGPDF_SDK_ColorState::GetStrokeColorRef() const
{
	return m_Ref.GetObject()->m_StrokeColorRef;
}

void CSGPDF_SDK_ColorState::SetStrokeColorRef(FX_COLORREF colorref)
{
	m_Ref.GetPrivateCopy()->m_StrokeColorRef = colorref;
}

const CSGPDF_SDK_Color* CSGPDF_SDK_ColorState::GetFillColor() const
{
	const ColorData* pData = m_Ref.GetObject();
	return pData ? &pData->m_FillColor : nullptr;
}

CSGPDF_SDK_Color* CSGPDF_SDK_ColorState::GetMutableFillColor()
{
	return &m_Ref.GetPrivateCopy()->m_FillColor;
}

bool CSGPDF_SDK_ColorState::HasFillColor() const
{
	const CSGPDF_SDK_Color* pColor = GetFillColor();
	return pColor && !pColor->IsNull();
}

const CSGPDF_SDK_Color* CSGPDF_SDK_ColorState::GetStrokeColor() const
{
	const ColorData* pData = m_Ref.GetObject();
	return pData ? &pData->m_StrokeColor : nullptr;
}

CSGPDF_SDK_Color* CSGPDF_SDK_ColorState::GetMutableStrokeColor()
{
	return &m_Ref.GetPrivateCopy()->m_StrokeColor;
}

bool CSGPDF_SDK_ColorState::HasStrokeColor() const
{
	const CSGPDF_SDK_Color* pColor = GetStrokeColor();
	return pColor && !pColor->IsNull();
}

void CSGPDF_SDK_ColorState::SetFillColor(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS,
	const std::vector<float>& values)
{
	ColorData* pData = m_Ref.GetPrivateCopy();
	SetColor(pCS, values, &pData->m_FillColor, &pData->m_FillColorRef);
}

void CSGPDF_SDK_ColorState::SetStrokeColor(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS,
	const std::vector<float>& values)
{
	ColorData* pData = m_Ref.GetPrivateCopy();
	SetColor(pCS, values, &pData->m_StrokeColor, &pData->m_StrokeColorRef);
}

void CSGPDF_SDK_ColorState::SetFillPattern(const RetainPtr<CSGPDF_SDK_Pattern>& pPattern,
	const std::vector<float>& values)
{
	ColorData* pData = m_Ref.GetPrivateCopy();
	SetPattern(pPattern, values, &pData->m_FillColor, &pData->m_FillColorRef);
}

void CSGPDF_SDK_ColorState::SetStrokePattern(const RetainPtr<CSGPDF_SDK_Pattern>& pPattern,
	const std::vector<float>& values)
{
	ColorData* pData = m_Ref.GetPrivateCopy();
	SetPattern(pPattern, values, &pData->m_StrokeColor, &pData->m_StrokeColorRef);
}

void CSGPDF_SDK_ColorState::SetColor(const RetainPtr<CSGPDF_SDK_ColorSpace>& pCS,
	const std::vector<float>& values,
	CSGPDF_SDK_Color* color,
	FX_COLORREF* colorref)
{
	DCHECK(color);
	DCHECK(colorref);

	if (pCS)
		color->SetColorSpace(pCS);
	else if (color->IsNull())
		color->SetColorSpace(CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICEGRAY));

	if (color->CountComponents() > values.size())
		return;

	if (!color->IsPattern())
		color->SetValueForNonPattern(values);
	int R;
	int G;
	int B;
	*colorref = color->GetRGB(&R, &G, &B) ? FXSYS_BGR(B, G, R) : 0xFFFFFFFF;
}

void CSGPDF_SDK_ColorState::SetPattern(const RetainPtr<CSGPDF_SDK_Pattern>& pPattern,
	const std::vector<float>& values,
	CSGPDF_SDK_Color* color,
	FX_COLORREF* colorref)
{
	DCHECK(color);
	DCHECK(colorref);

	color->SetValueForPattern(pPattern, values);
	int R;
	int G;
	int B;
	bool ret = color->GetRGB(&R, &G, &B);
	if (CSGPDF_SDK_TilingPattern* pTilingPattern = pPattern->AsTilingPattern())
	{
		if (!ret && pTilingPattern->colored())
		{
			*colorref = 0x00BFBFBF;
			return;
		}
	}
	*colorref = ret ? FXSYS_BGR(B, G, R) : 0xFFFFFFFF;
}

CSGPDF_SDK_ColorState::ColorData::ColorData() = default;

CSGPDF_SDK_ColorState::ColorData::ColorData(const ColorData& src)
	: m_FillColorRef(src.m_FillColorRef),
	m_StrokeColorRef(src.m_StrokeColorRef),
	m_FillColor(src.m_FillColor),
	m_StrokeColor(src.m_StrokeColor)
{
}

CSGPDF_SDK_ColorState::ColorData::~ColorData() = default;

void CSGPDF_SDK_ColorState::ColorData::SetDefault()
{
	m_FillColorRef = 0;
	m_StrokeColorRef = 0;
	m_FillColor.SetColorSpace(CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICEGRAY));
	m_StrokeColor.SetColorSpace(CSGPDF_SDK_ColorSpace::GetStockCS(PDFCS_DEVICEGRAY));
}

RetainPtr<CSGPDF_SDK_ColorState::ColorData> CSGPDF_SDK_ColorState::ColorData::Clone()
const
{
	return pdfium::MakeRetain<CSGPDF_SDK_ColorState::ColorData>(*this);
}
