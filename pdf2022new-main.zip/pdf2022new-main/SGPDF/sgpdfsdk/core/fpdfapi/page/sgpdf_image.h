// Copyright 2016 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_IMAGE_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_IMAGE_H_

#include "core/fxcrt/fx_system.h"
#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"
#include "third_party/base/span.h"

class CFX_DIBBase;
class CFX_DIBitmap;
class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Document;
class CSGPDF_SDK_Page;
class CSGPDF_SDK_Stream;
class PauseIndicatorIface;
class IFX_SeekableReadStream;

class CSGPDF_SDK_Image final : public Retainable {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  static bool IsValidJpegComponent(int32_t comps);
  static bool IsValidJpegBitsPerComponent(int32_t bpc);

  void ConvertStreamToIndirectObject();

  CSGPDF_SDK_Dictionary* GetDict() const;
  CSGPDF_SDK_Stream* GetStream() const { return m_pStream.Get(); }
  const CSGPDF_SDK_Dictionary* GetOC() const { return m_pOC.Get(); }
  CSGPDF_SDK_Document* GetDocument() const { return m_pDocument.Get(); }

  int32_t GetPixelHeight() const { return m_Height; }
  int32_t GetPixelWidth() const { return m_Width; }

  bool IsInline() const { return m_bIsInline; }
  bool IsMask() const { return m_bIsMask; }
  bool IsInterpol() const { return m_bInterpolate; }

  RetainPtr<CFX_DIBBase> LoadDIBBase() const;

  void SetImage(const RetainPtr<CFX_DIBitmap>& pBitmap);
  void SetJpegImage(const RetainPtr<IFX_SeekableReadStream>& pFile);
  void SetJpegImageInline(const RetainPtr<IFX_SeekableReadStream>& pFile);

  void ResetCache(CSGPDF_SDK_Page* pPage);

  // Returns whether to Continue() or not.
  bool StartLoadDIBBase(const CSGPDF_SDK_Dictionary* pFormResource,
                        const CSGPDF_SDK_Dictionary* pPageResource,
                        bool bStdCS,
                        uint32_t GroupFamily,
                        bool bLoadMask);

  // Returns whether to Continue() or not.
  bool Continue(PauseIndicatorIface* pPause);

  RetainPtr<CFX_DIBBase> DetachBitmap();
  RetainPtr<CFX_DIBBase> DetachMask();

  RetainPtr<CFX_DIBBase> m_pDIBBase;
  RetainPtr<CFX_DIBBase> m_pMask;
  uint32_t m_MatteColor = 0;

 private:
  explicit CSGPDF_SDK_Image(CSGPDF_SDK_Document* pDoc);
  CSGPDF_SDK_Image(CSGPDF_SDK_Document* pDoc, RetainPtr<CSGPDF_SDK_Stream> pStream);
  CSGPDF_SDK_Image(CSGPDF_SDK_Document* pDoc, uint32_t dwStreamObjNum);
  ~CSGPDF_SDK_Image() override;

  void FinishInitialization(CSGPDF_SDK_Dictionary* pStreamDict);
  RetainPtr<CSGPDF_SDK_Dictionary> InitJPEG(pdfium::span<uint8_t> src_span);

  RetainPtr<CSGPDF_SDK_Dictionary> CreateXObjectImageDict(int width, int height);

  int32_t m_Height = 0;
  int32_t m_Width = 0;
  bool m_bIsInline = false;
  bool m_bIsMask = false;
  bool m_bInterpolate = false;
  UnownedPtr<CSGPDF_SDK_Document> const m_pDocument;
  RetainPtr<CSGPDF_SDK_Stream> m_pStream;
  RetainPtr<const CSGPDF_SDK_Dictionary> m_pOC;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_IMAGE_H_
