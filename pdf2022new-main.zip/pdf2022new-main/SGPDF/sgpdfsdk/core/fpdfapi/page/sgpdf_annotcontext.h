// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_ANNOTCONTEXT_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_ANNOTCONTEXT_H_

#include <memory>

#include "core/fxcrt/retain_ptr.h"
#include "core/fxcrt/unowned_ptr.h"

class CSGPDF_SDK_Dictionary;
class CSGPDF_SDK_Form;
class CSGPDF_SDK_Stream;
class IPDF_Page;

class CSGPDF_SDK_AnnotContext {
 public:
  CSGPDF_SDK_AnnotContext(CSGPDF_SDK_Dictionary* pAnnotDict, IPDF_Page* pPage);
  ~CSGPDF_SDK_AnnotContext();

  void SetForm(CSGPDF_SDK_Stream* pStream);
  bool HasForm() const { return !!m_pAnnotForm; }
  CSGPDF_SDK_Form* GetForm() const { return m_pAnnotForm.get(); }

  // Never nullptr.
  CSGPDF_SDK_Dictionary* GetAnnotDict() const { return m_pAnnotDict.Get(); }

  // Never nullptr.
  IPDF_Page* GetPage() const { return m_pPage.Get(); }

 private:
  std::unique_ptr<CSGPDF_SDK_Form> m_pAnnotForm;
  RetainPtr<CSGPDF_SDK_Dictionary> const m_pAnnotDict;
  UnownedPtr<IPDF_Page> const m_pPage;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_ANNOTCONTEXT_H_
