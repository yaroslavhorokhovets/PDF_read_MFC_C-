// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#ifndef CORE_FPDFAPI_PAGE_CSGPDF_SDK_ICCPROFILE_H_
#define CORE_FPDFAPI_PAGE_CSGPDF_SDK_ICCPROFILE_H_

#include <memory>

#include "core/fxcrt/observed_ptr.h"
#include "core/fxcrt/retain_ptr.h"
#include "third_party/base/span.h"

class CSGPDF_SDK_Stream;

namespace fxcodec {
class CLcmsCmm;
}  // namespace fxcodec

class CSGPDF_SDK_IccProfile final : public Retainable, public Observable {
 public:
  CONSTRUCT_VIA_MAKE_RETAIN;

  const CSGPDF_SDK_Stream* GetStream() const { return m_pStream.Get(); }
  bool IsValid() const { return IsSRGB() || IsSupported(); }
  bool IsSRGB() const { return m_bsRGB; }
  bool IsSupported() const { return !!m_Transform; }
  fxcodec::CLcmsCmm* transform() { return m_Transform.get(); }
  uint32_t GetComponents() const { return m_nSrcComponents; }

 private:
  CSGPDF_SDK_IccProfile(const CSGPDF_SDK_Stream* pStream, pdfium::span<const uint8_t> span);
  ~CSGPDF_SDK_IccProfile() override;

  const bool m_bsRGB;
  uint32_t m_nSrcComponents = 0;
  RetainPtr<const CSGPDF_SDK_Stream> const m_pStream;
  std::unique_ptr<fxcodec::CLcmsCmm> m_Transform;
};

#endif  // CORE_FPDFAPI_PAGE_CSGPDF_SDK_ICCPROFILE_H_
