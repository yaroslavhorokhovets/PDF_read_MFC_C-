// Copyright 2017 SGPDF Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_function.h"

#include <vector>

#include "core/fpdfapi/page/sgpdf_expintfunc.h"
#include "core/fpdfapi/page/sgpdf_psfunc.h"
#include "core/fpdfapi/page/sgpdf_sampledfunc.h"
#include "core/fpdfapi/page/sgpdf_stitchfunc.h"
#include "core/fpdfapi/parser/sgpdf_array.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fpdfapi/parser/fpdf_parser_utility.h"
#include "core/fxcrt/fx_safe_types.h"
#include "third_party/base/stl_util.h"

namespace
{

	CSGPDF_SDK_Function::Type IntegerToFunctionType(int iType)
	{
		switch (iType)
		{
			case 0:
			case 2:
			case 3:
			case 4:
				return static_cast<CSGPDF_SDK_Function::Type>(iType);
			default:
				return CSGPDF_SDK_Function::Type::kTypeInvalid;
		}
	}

}  // namespace

// static
std::unique_ptr<CSGPDF_SDK_Function> CSGPDF_SDK_Function::Load(
	const CSGPDF_SDK_Object* pFuncObj)
{
	std::set<const CSGPDF_SDK_Object*> visited;
	return Load(pFuncObj, &visited);
}

// static
std::unique_ptr<CSGPDF_SDK_Function> CSGPDF_SDK_Function::Load(
	const CSGPDF_SDK_Object* pFuncObj,
	std::set<const CSGPDF_SDK_Object*>* pVisited)
{
	if (!pFuncObj)
		return nullptr;

	if (pdfium::Contains(*pVisited, pFuncObj))
		return nullptr;
	pdfium::ScopedSetInsertion<const CSGPDF_SDK_Object*> insertion(pVisited, pFuncObj);

	int iType = -1;
	if (const CSGPDF_SDK_Stream* pStream = pFuncObj->AsStream())
		iType = pStream->GetDict()->GetIntegerFor("FunctionType");
	else if (const CSGPDF_SDK_Dictionary* pDict = pFuncObj->AsDictionary())
		iType = pDict->GetIntegerFor("FunctionType");

	std::unique_ptr<CSGPDF_SDK_Function> pFunc;
	Type type = IntegerToFunctionType(iType);
	if (type == Type::kType0Sampled)
		pFunc = std::make_unique<CSGPDF_SDK_SampledFunc>();
	else if (type == Type::kType2ExponentialInterpolation)
		pFunc = std::make_unique<CSGPDF_SDK_ExpIntFunc>();
	else if (type == Type::kType3Stitching)
		pFunc = std::make_unique<CSGPDF_SDK_StitchFunc>();
	else if (type == Type::kType4PostScript)
		pFunc = std::make_unique<CSGPDF_SDK_PSFunc>();

	if (!pFunc || !pFunc->Init(pFuncObj, pVisited))
		return nullptr;

	return pFunc;
}

CSGPDF_SDK_Function::CSGPDF_SDK_Function(Type type) : m_Type(type)
{
}

CSGPDF_SDK_Function::~CSGPDF_SDK_Function() = default;

bool CSGPDF_SDK_Function::Init(const CSGPDF_SDK_Object* pObj,
	std::set<const CSGPDF_SDK_Object*>* pVisited)
{
	const CSGPDF_SDK_Stream* pStream = pObj->AsStream();
	const CSGPDF_SDK_Dictionary* pDict =
		pStream ? pStream->GetDict() : pObj->AsDictionary();

	const CSGPDF_SDK_Array* pDomains = pDict->GetArrayFor("Domain");
	if (!pDomains)
		return false;

	m_nInputs = pDomains->size() / 2;
	if (m_nInputs == 0)
		return false;

	size_t nInputs = m_nInputs * 2;
	m_Domains = ReadArrayElementsToVector(pDomains, nInputs);

	const CSGPDF_SDK_Array* pRanges = pDict->GetArrayFor("Range");
	m_nOutputs = pRanges ? pRanges->size() / 2 : 0;

	// Ranges are required for type 0 and type 4 functions. A non-zero
	// |m_nOutputs| here implied Ranges meets the requirements.
	bool bRangeRequired =
		m_Type == Type::kType0Sampled || m_Type == Type::kType4PostScript;
	if (bRangeRequired && m_nOutputs == 0)
		return false;

	if (m_nOutputs > 0)
	{
		size_t nOutputs = m_nOutputs * 2;
		m_Ranges = ReadArrayElementsToVector(pRanges, nOutputs);
	}

	uint32_t old_outputs = m_nOutputs;
	if (!v_Init(pObj, pVisited))
		return false;

	if (!m_Ranges.empty() && m_nOutputs > old_outputs)
	{
		FX_SAFE_SIZE_T nOutputs = m_nOutputs;
		nOutputs *= 2;
		m_Ranges.resize(nOutputs.ValueOrDie());
	}
	return true;
}

bool CSGPDF_SDK_Function::Call(const float* inputs,
	uint32_t ninputs,
	float* results,
	int* nresults) const
{
	if (m_nInputs != ninputs)
		return false;

	*nresults = m_nOutputs;
	std::vector<float> clamped_inputs(m_nInputs);
	for (uint32_t i = 0; i < m_nInputs; i++)
	{
		clamped_inputs[i] =
			pdfium::clamp(inputs[i], m_Domains[i * 2], m_Domains[i * 2 + 1]);
	}
	if (!v_Call(clamped_inputs.data(), results))
		return false;

	if (m_Ranges.empty())
		return true;

	for (uint32_t i = 0; i < m_nOutputs; i++)
	{
		results[i] =
			pdfium::clamp(results[i], m_Ranges[i * 2], m_Ranges[i * 2 + 1]);
	}
	return true;
}

// See PDF Reference 1.7, page 170.
float CSGPDF_SDK_Function::Interpolate(float x,
	float xmin,
	float xmax,
	float ymin,
	float ymax) const
{
	float divisor = xmax - xmin;
	return ymin + (divisor ? (x - xmin) * (ymax - ymin) / divisor : 0);
}

const CSGPDF_SDK_SampledFunc* CSGPDF_SDK_Function::ToSampledFunc() const
{
	return m_Type == Type::kType0Sampled
		? static_cast<const CSGPDF_SDK_SampledFunc*>(this)
		: nullptr;
}

const CSGPDF_SDK_ExpIntFunc* CSGPDF_SDK_Function::ToExpIntFunc() const
{
	return m_Type == Type::kType2ExponentialInterpolation
		? static_cast<const CSGPDF_SDK_ExpIntFunc*>(this)
		: nullptr;
}

const CSGPDF_SDK_StitchFunc* CSGPDF_SDK_Function::ToStitchFunc() const
{
	return m_Type == Type::kType3Stitching
		? static_cast<const CSGPDF_SDK_StitchFunc*>(this)
		: nullptr;
}
