// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_pagemodule.h"

#include "core/fpdfapi/font/sgpdf_fontglobals.h"
#include "core/fpdfapi/page/sgpdf_colorspace.h"
#include "core/fpdfapi/page/sgpdf_devicecs.h"
#include "core/fpdfapi/page/sgpdf_patterncs.h"
#include "third_party/base/check.h"

namespace
{

	CSGPDF_SDK_PageModule* g_PageModule = nullptr;

}  // namespace

// static
void CSGPDF_SDK_PageModule::Create()
{
	DCHECK(!g_PageModule);
	g_PageModule = new CSGPDF_SDK_PageModule();
}

// static
void CSGPDF_SDK_PageModule::Destroy()
{
	DCHECK(g_PageModule);
	delete g_PageModule;
	g_PageModule = nullptr;
}

// static
CSGPDF_SDK_PageModule* CSGPDF_SDK_PageModule::GetInstance()
{
	DCHECK(g_PageModule);
	return g_PageModule;
}

CSGPDF_SDK_PageModule::CSGPDF_SDK_PageModule()
	: m_StockGrayCS(pdfium::MakeRetain<CSGPDF_SDK_DeviceCS>(PDFCS_DEVICEGRAY)),
	m_StockRGBCS(pdfium::MakeRetain<CSGPDF_SDK_DeviceCS>(PDFCS_DEVICERGB)),
	m_StockCMYKCS(pdfium::MakeRetain<CSGPDF_SDK_DeviceCS>(PDFCS_DEVICECMYK)),
	m_StockPatternCS(pdfium::MakeRetain<CSGPDF_SDK_PatternCS>(nullptr))
{
	m_StockPatternCS->InitializeStockPattern();
	CSGPDF_SDK_FontGlobals::Create();
	CSGPDF_SDK_FontGlobals::GetInstance()->LoadEmbeddedMaps();
}

CSGPDF_SDK_PageModule::~CSGPDF_SDK_PageModule()
{
	CSGPDF_SDK_FontGlobals::Destroy();
}

RetainPtr<CSGPDF_SDK_ColorSpace> CSGPDF_SDK_PageModule::GetStockCS(int family)
{
	if (family == PDFCS_DEVICEGRAY)
		return m_StockGrayCS;
	if (family == PDFCS_DEVICERGB)
		return m_StockRGBCS;
	if (family == PDFCS_DEVICECMYK)
		return m_StockCMYKCS;
	if (family == PDFCS_PATTERN)
		return m_StockPatternCS;
	return nullptr;
}

void CSGPDF_SDK_PageModule::ClearStockFont(CSGPDF_SDK_Document* pDoc)
{
	CSGPDF_SDK_FontGlobals::GetInstance()->Clear(pDoc);
}
