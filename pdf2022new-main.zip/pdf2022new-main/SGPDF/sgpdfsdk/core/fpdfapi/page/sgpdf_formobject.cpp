// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_formobject.h"

#include <utility>

#include "core/fpdfapi/page/sgpdf_form.h"

CSGPDF_SDK_FormObject::CSGPDF_SDK_FormObject(int32_t content_stream,
	std::unique_ptr<CSGPDF_SDK_Form> pForm,
	const CFX_Matrix& matrix)
	: CSGPDF_SDK_PageObject(content_stream),
	m_pForm(std::move(pForm)),
	m_FormMatrix(matrix)
{
}

CSGPDF_SDK_FormObject::~CSGPDF_SDK_FormObject() = default;

void CSGPDF_SDK_FormObject::Transform(const CFX_Matrix& matrix)
{
	m_FormMatrix.Concat(matrix);
	CalcBoundingBox();
}

bool CSGPDF_SDK_FormObject::IsForm() const
{
	return true;
}

CSGPDF_SDK_FormObject* CSGPDF_SDK_FormObject::AsForm()
{
	return this;
}

const CSGPDF_SDK_FormObject* CSGPDF_SDK_FormObject::AsForm() const
{
	return this;
}

CSGPDF_SDK_PageObject::Type CSGPDF_SDK_FormObject::GetType() const
{
	return FORM;
}

void CSGPDF_SDK_FormObject::CalcBoundingBox()
{
	SetRect(m_FormMatrix.TransformRect(m_pForm->CalcBoundingBox()));
}
