// (c)2022 Secured Globe, Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Original code copyright 2014 Foxit Software Inc. http://www.foxitsoftware.com

#include "core/fpdfapi/page/sgpdf_form.h"

#include <algorithm>

#include "core/fpdfapi/page/sgpdf_contentparser.h"
#include "core/fpdfapi/page/sgpdf_imageobject.h"
#include "core/fpdfapi/page/sgpdf_pageobject.h"
#include "core/fpdfapi/page/sgpdf_pageobjectholder.h"
#include "core/fpdfapi/parser/sgpdf_dictionary.h"
#include "core/fpdfapi/parser/sgpdf_stream.h"
#include "core/fxge/dib/cfx_dibitmap.h"
#include "third_party/base/check.h"

// static
CSGPDF_SDK_Dictionary* CSGPDF_SDK_Form::ChooseResourcesDict(
	CSGPDF_SDK_Dictionary* pResources,
	CSGPDF_SDK_Dictionary* pParentResources,
	CSGPDF_SDK_Dictionary* pPageResources)
{
	if (pResources)
		return pResources;
	return pParentResources ? pParentResources : pPageResources;
}

CSGPDF_SDK_Form::CSGPDF_SDK_Form(CSGPDF_SDK_Document* pDoc,
	CSGPDF_SDK_Dictionary* pPageResources,
	CSGPDF_SDK_Stream* pFormStream)
	: CSGPDF_SDK_Form(pDoc, pPageResources, pFormStream, nullptr)
{
}

CSGPDF_SDK_Form::CSGPDF_SDK_Form(CSGPDF_SDK_Document* pDoc,
	CSGPDF_SDK_Dictionary* pPageResources,
	CSGPDF_SDK_Stream* pFormStream,
	CSGPDF_SDK_Dictionary* pParentResources)
	: CSGPDF_SDK_PageObjectHolder(
		pDoc,
		pFormStream->GetDict(),
		pPageResources,
		ChooseResourcesDict(pFormStream->GetDict()->GetDictFor("Resources"),
			pParentResources,
			pPageResources)),
	m_pFormStream(pFormStream)
{
	LoadTransparencyInfo();
}

CSGPDF_SDK_Form::~CSGPDF_SDK_Form() = default;

void CSGPDF_SDK_Form::ParseContent()
{
	ParseContentInternal(nullptr, nullptr, nullptr, nullptr);
}

void CSGPDF_SDK_Form::ParseContent(const CSGPDF_SDK_AllStates* pGraphicStates,
	const CFX_Matrix* pParentMatrix,
	std::set<const uint8_t*>* pParsedSet)
{
	ParseContentInternal(pGraphicStates, pParentMatrix, nullptr, pParsedSet);
}

void CSGPDF_SDK_Form::ParseContentForType3Char(CSGPDF_SDK_Type3Char* pType3Char)
{
	ParseContentInternal(nullptr, nullptr, pType3Char, nullptr);
}

void CSGPDF_SDK_Form::ParseContentInternal(const CSGPDF_SDK_AllStates* pGraphicStates,
	const CFX_Matrix* pParentMatrix,
	CSGPDF_SDK_Type3Char* pType3Char,
	std::set<const uint8_t*>* pParsedSet)
{
	if (GetParseState() == ParseState::kParsed)
		return;

	if (GetParseState() == ParseState::kNotParsed)
	{
		if (!pParsedSet)
		{
			if (!m_ParsedSet)
				m_ParsedSet = std::make_unique<std::set<const uint8_t*>>();
			pParsedSet = m_ParsedSet.get();
		}
		StartParse(std::make_unique<CSGPDF_SDK_ContentParser>(
			this, pGraphicStates, pParentMatrix, pType3Char, pParsedSet));
	}

	DCHECK(GetParseState() == ParseState::kParsing);
	ContinueParse(nullptr);
}

bool CSGPDF_SDK_Form::HasPageObjects() const
{
	return GetPageObjectCount() != 0;
}

CFX_FloatRect CSGPDF_SDK_Form::CalcBoundingBox() const
{
	if (GetPageObjectCount() == 0)
		return CFX_FloatRect();

	float left = 1000000.0f;
	float right = -1000000.0f;
	float bottom = 1000000.0f;
	float top = -1000000.0f;
	for (const auto& pObj : *this)
	{
		const auto& rect = pObj->GetRect();
		left = std::min(left, rect.left);
		right = std::max(right, rect.right);
		bottom = std::min(bottom, rect.bottom);
		top = std::max(top, rect.top);
	}
	return CFX_FloatRect(left, bottom, right, top);
}

const CSGPDF_SDK_Stream* CSGPDF_SDK_Form::GetStream() const
{
	return m_pFormStream.Get();
}

Optional<std::pair<RetainPtr<CFX_DIBitmap>, CFX_Matrix>>
CSGPDF_SDK_Form::GetBitmapAndMatrixFromSoleImageOfForm() const
{
	if (GetPageObjectCount() != 1)
		return {};

	CSGPDF_SDK_ImageObject* pImageObject = (*begin())->AsImage();
	if (!pImageObject)
		return {};

	return { {pImageObject->GetIndependentBitmap(), pImageObject->matrix()} };
}
